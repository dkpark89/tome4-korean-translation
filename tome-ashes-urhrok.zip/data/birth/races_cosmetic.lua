-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

local reset = function(actor) actor.moddable_tile_base_alter = nil end
local set = function(actor) if actor.moddable_tile then actor.moddable_tile_base_alter = function(actor, base) return base:gsub('^base_', 'demonic_') end end end

for _, nrace in ipairs{"Human", "Elf", "Halfling", "Dwarf", "Yeek", "Orc", "Yeti", {"Giant", "Ogre"}} do
	local nsubrace = nil
	if type(nrace) == "table" then nrace, nsubrace = unpack(nrace) end
	local race = getBirthDescriptor("race", nrace)
	local subrace = nil
	if nsubrace then subrace = getBirthDescriptor("subrace", nsubrace) end
	if race and (not nsubrace or subrace) then
		local item = subrace or race
		item.cosmetic_unlock.cosmetic_red_skin = {
			{name="Red Skin [donator only]", donator=true, on_actor=set, reset=reset},
		}
		item.cosmetic_unlock.cosmetic_doomhorns = {
			{priority=2, name="Demonic Horns 1 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_01", male="horns_01"} end end},
			{priority=2, name="Demonic Horns 2 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_02", male="horns_02"} end end},
			{priority=2, name="Demonic Horns 3 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_03", male="horns_03"} end end},
			{priority=2, name="Demonic Horns 4 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_04", male="horns_04"} end end},
			{priority=2, name="Demonic Horns 5 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_05", male="horns_05"} end end},
		}
	end
end
