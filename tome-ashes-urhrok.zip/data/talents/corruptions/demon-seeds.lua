-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

local Dialog = require "engine.ui.Dialog"
local Object = require "mod.class.Object"

newTalent{
	name = "Flame Bolts", short_name = "DEMON_SEED_FIRE_BOLTS",
	type = {"corruption/demon-seeds",1},
	points = 5,
	range = 5,
	radius = 5,
	proj_speed = 7,
	mode = "passive",
	target = function(self, t) return {type="ball", range=self:getTalentRange(t), radius=self:getTalentRadius(t), talent=t} end,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 18, 120) end,
	callbackOnMeleeAttack = function(self, t, _, hitted)
		if not hitted or not rng.percent(self:getTalentLevel(t) * 5 + 20) then return end

		local tg = self:getTalentTarget(t)
		local tgts = {}
		local grids = self:project(tg, self.x, self.y, function(px, py)
			local actor = game.level.map(px, py, Map.ACTOR)
			if actor and self:reactionToward(actor) < 0 then
				tgts[#tgts+1] = actor
			end
		end)

		local nb = 1+math.ceil(self:getTalentLevel(t)/2)
		while nb > 0 and #tgts > 0 do
			local actor = rng.tableRemove(tgts)
			local tg2 = {type="bolt", range=self:getTalentRange(t), talent=t, display={particle="bolt_fire", trail="firetrail"}}
			self:projectile(tg2, actor.x, actor.y, DamageType.FIRE, self:spellCrit(t.getDamage(self, t)), {type="flame"})
		end

		game:playSoundNear(self, "talents/fire")
	end,
	info = function(self, t)
		local damage = t.getDamage(self, t)
		return ([[Randomly (%d%% chances) hurls up to %d flame bolts dealing %0.2f fire damage to foes in sight when you hit in melee.
		The damage will increase with your Spellpower.]]):
		format(self:getTalentLevel(t) * 5 + 20, 1+math.ceil(self:getTalentLevel(t) / 2), damDesc(self, DamageType.FIRE, damage))
	end,
}

local what = {physical=true, mental=true, magical=true}
newTalent{
	name = "Fiery Cleansing", short_name = "DEMON_SEED_FIERY_CLEANSING",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = function(self, t) return self:combatTalentLimit(t, 10, 30, 15) end,
	vim = 15,
	no_energy = true,
	tactical = {
		DEFEND = 3,
		CURE = function(self, t, target)
			local nb = 0
			for eff_id, p in pairs(self.tmp) do
				local e = self.tempeffect_def[eff_id]
				if what[e.type] and e.status == "detrimental" then
					nb = nb + 1
				end
			end
			return nb
		end
	},
	getNb = function(self, t) return self:combatTalentScale(t, 2, 5) end,
	on_pre_use = function(self, t) return self.life > self.max_life * 0.1 end,
	action = function(self, t)
		self:takeHit(self.max_life * 0.1, self)

		local target = self
		local effs = {}
		local force = {}
		local known = false

		-- Go through all temporary effects
		for eff_id, p in pairs(target.tmp) do
			local e = target.tempeffect_def[eff_id]
			if what[e.type] and e.status == "detrimental" and e.subtype["cross tier"] then
				force[#force+1] = {"effect", eff_id}
			elseif what[e.type] and e.status == "detrimental" then
				effs[#effs+1] = {"effect", eff_id}
			end
		end

		-- Cross tier effects are always removed and not part of the random game, otherwise it is a huge nerf to wild infusion
		for i = 1, #force do
			local eff = force[i]
			if eff[1] == "effect" then
				target:removeEffect(eff[2])
				known = true
			end
		end

		for i = 1, t.getNb(self, t) do
			if #effs == 0 then break end
			local eff = rng.tableRemove(effs)

			if eff[1] == "effect" then
				target:removeEffect(eff[2])
				known = true
			end
		end
		if known then
			game.logSeen(self, "%s is cured!", self.name:capitalize())
		end

		if core.shader.active(4) then
			self:addParticles(Particles.new("shader_shield_temp", 1, {toback=true , size_factor=1.5, y=-0.3, img="healred", life=25}, {type="healing", time_factor=2000, beamsCount=20, noup=2.0, beamColor1=colors.hex1alpha"c52505FF", beamColor2=colors.hex1alpha"f69566FF"}))
			self:addParticles(Particles.new("shader_shield_temp", 1, {toback=false, size_factor=1.5, y=-0.3, img="healred", life=25}, {type="healing", time_factor=2000, beamsCount=20, noup=1.0, beamColor1=colors.hex1alpha"c52505FF", beamColor2=colors.hex1alpha"f69566FF"}))
			game.level.map:particleEmitter(self.x, self.y, 1, "shader_ring_rotating", {rotation=0, radius=1.2, life=30, y=0.2, img="flamesshockwave"}, {type="firearcs"})
		end

		game:playSoundNear(self, "talents/fire")
		return true
	end,
	info = function(self, t)
		return ([[Deals 10%% of your total life to cleanse your afflictions, removing up to %d physical, mental or magical detrimental effects.]]):
		format(t.getNb(self, t))
	end,
}

newTalent{
	name = "Farstrike", short_name = "DEMON_SEED_FARSTRIKE",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = 2,
	vim = 2,
	tactical = { ATTACK = 2 },
	requires_target = true,
	range = function(self, t) return 2 + math.floor(self:combatTalentLimit(t, 8, 1, 6)) end,
	getDamage = function(self, t) return self:combatTalentWeaponDamage(t, 0.8, 2) end,
	action = function(self, t)
		local tg = {type="hit", range=self:getTalentRange(t), talent=t}
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		local _ _, x, y = self:canProject(tg, x, y)
		local target = game.level.map(x, y, Map.ACTOR)

		if not target then return end
		
		self:attackTarget(target, nil, t.getDamage(self, t), true)
		return true
	end,
	info = function(self, t)
		local range = self:getTalentRange(t)
		return ([[You send your weapon flying to the target, dealing %d%% weapon damage.]]):
		format(t.getDamage(self, t)*100)
	end,
}

newTalent{
	name = "Corrosive Slashes", short_name = "DEMON_SEED_CORROSIVE_SLASHES",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = 10,
	sustain_vim = 5,
	tactical = { BUFF = 2 },
	mode = "sustained",
	getDamage = function(self, t) return self:combatTalentWeaponDamage(t, 0.8, 2) end,
	getArmorPen = function(self, t) return self:combatTalentScale(t, 15, 65) end,
	callbackOnMeleeAttack = function(self, t, target, hitted, crit, weapon, damtype, mult, dam)
		if hitted then game.level.map:particleEmitter(target.x, target.y, 1, "corrosive_slashes") end
	end,
	activate = function(self, t)
		local ret = {}
		self:talentTemporaryValue(ret, "combat_apr", t.getArmorPen(self, t))
		self:talentTemporaryValue(ret, "force_melee_damtype", DamageType.ACID)
		return ret
	end,
	deactivate = function(self, t, p)
		return true
	end,
	info = function(self, t)
		return ([[You cover your weapon in acid, turning all melee damage into acid.
		All melee attacks also gain %d armor penetration.]]):
		format(t.getArmorPen(self, t))
	end,
}

newTalent{
	name = "Acidic Bath", short_name = "DEMON_SEED_ACIDIC_BATH",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = 15,
	vim = 12,
	tactical = { ATTACKAREA = 1, HEAL = 1 },
	requires_target = true,
	range = 4,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 5, 700) / 10 end,
	getDuration = function(self, t) return self:combatTalentScale(t, 4, 10, 0.5) end,
	getAffinity = function(self, t) return self:combatTalentScale(t, 50, 100, 0.5) end,
	action = function(self, t)
		local duration = t.getDuration(self, t)
		local dam = t.getDamage(self, t)
		-- Add a lasting map effect
		game.level.map:addEffect(self,
			self.x, self.y, duration,
			DamageType.ACID, dam,
			self:getTalentRange(t),
			5, nil,
			{type="vapour"},
			nil, nil
		)
		self:setEffect(self.EFF_ACIDIC_BATH, duration, {res=40, aff=t.getAffinity(self, t)})
		game:playSoundNear(self, "talents/cloud")
		return true
	end,
	info = function(self, t)
		return ([[You spawn a pool of acid in radius 4 around you for %d turns, dealing %0.2f acid damage to all creatures, including you.
		You also gain 40%% acid resistance and %d%% acid affinity.
		The damage scales with your Spellpower.]]):
		format(t.getDuration(self, t), damDesc(self, DamageType.ACID, t.getDamage(self, t)), t.getAffinity(self, t))
	end,
}

newTalent{
	name = "Blighted Path", short_name = "DEMON_SEED_BLIGHTED_PATH",
	type = {"corruption/demon-seeds",1},
	points = 5, no_sustain_autoreset = true,
	mode = "sustained",
	cooldown = 10,
	range = 1,
	no_energy = true,
	no_npc_use = true,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 50, 400) / 9 end,
	getVim = function(self, t) return self:combatTalentScale(t, 3, 10, 0.5) end,
	getMaxCharges = function(self, t) return 4 + math.floor(self:getTalentLevel(t)) * 2 end,
	iconOverlay = function(self, t, p)
		local val = p.charges or 0
		if val <= 0 then return "" end
		return tostring(math.ceil(val)), "buff_font_small"
	end,
	callbackOnMove = function(self, t, moved, force, ox, oy)
		if not moved or force or (self.x == ox and self.y == oy) then return end
		local p = self:isTalentActive(t.id)
		if not p then return end
		p.charges = util.bound(p.charges + 1, 0, t.getMaxCharges(self, t))
	end,
	activate = function(self, t)
		return {
			charges = 0,
		}
	end,
	deactivate = function(self, t, p)
		if self:attr("save_cleanup") then return true end
		if not p.charges or p.charges < 1 then return true end

		local d = Dialog:listPopup("Blighted Path", "Select a use for the "..p.charges.." charge(s):", {
			{kind="attack", name=("Attack for #DARK_GREEN#%0.2f blight damage"):format(damDesc(self, DamageType.BLIGHT, t.getDamage(self, t) * p.charges))},
			{kind="vim", name=("Restore #904010#%0.2f vim"):format(t.getVim(self, t) * p.charges)},
		}, 300, 150, function(sel)
			if not sel then self:talentDialogReturn(false) return end
			self:talentDialogReturn(sel.kind)
		end)
		local kind = self:talentDialog(d)
		if not kind then return nil end

		if kind == "attack" then
			local tg = {type="bolt", range=self:getTalentRange(t), talent=t, display={particle="bolt_slime"}}
			local x, y = self:getTarget(tg)
			if not x or not y then return nil end
			self:projectile(tg, x, y, DamageType.BLIGHT, self:spellCrit(t.getDamage(self, t) * p.charges), {type="slime"})
			game:playSoundNear(self, "talents/slime")
		elseif kind == "vim" then
			self:incVim(t.getVim(self, t) * p.charges)
		end

		return true
	end,
	info = function(self, t)
		return ([[Each time you walk or move you gain a blight charge. You can store up to %d charges.
		When you de-activate the talent you can use the charges to restore %0.2f vim per charges or deal %0.2f blight damage per charge to a target in melee range.
		The damage scales with your Spellpower.]]):
		format(t.getMaxCharges(self, t), t.getVim(self, t), damDesc(self, DamageType.BLIGHT, t.getDamage(self, t)))
	end,
}

newTalent{
	name = "Corrupt Light", short_name = "DEMON_SEED_CORRUPT_LIGHT",
	type = {"corruption/demon-seeds",1},
	points = 5,
	vim = 5,
	cooldown = 15,
	range = 0,
	radius = function(self, t) return math.floor(self:combatTalentScale(t, 2.7, 5.3)) end,
	direct_hit = true,
	tactical = { DISABLE = 2, BUFF = 2, },
	requires_target = true,
	target = function(self, t)
		return {type="ball", radius=self:getTalentRadius(t), talent=t}
	end,
	getDuration = function(self, t) return self:combatTalentScale(t, 4, 10, 0.5) end,
	action = function(self, t)
		local tg = self:getTalentTarget(t)
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		local nb = 0
		self:project(tg, x, y, function(px, py)
			if game.level.map.lites(px, py) then
				game.level.map.remembers(px, py, false)
				game.level.map.lites(px, py, false)
				nb = nb + 1
			end
		end, nil, {type="dark"})
		if nb > 0 then
			local power = math.sqrt(nb) * 6
			self:setEffect(self.EFF_DEMON_SEED_CORRUPT_LIGHT, 5, {power=power})
		end
		self:move(self.x, self.y, true)
		game:playSoundNear(self, "talents/breath")
		return true
	end,
	info = function(self, t)
		return ([[Weave darkness in a radius of %d. All lited grids extinguished contribute to your power by increasing all your damage done for %d turns.
		Damage increase depends on the number of grids extinguished.]]):
		format(self:getTalentRadius(t), t.getDuration(self, t))
	end,
}

newTalent{
	name = "Shadowmeld", short_name = "DEMON_SEED_SHADOWMELD",
	type = {"corruption/demon-seeds",1},
	points = 5,
	mode = "sustained",
	sustain_vim = 15,
	cooldown = 10,
	tactical = { BUFF = 10, },
	no_energy = true,
	on_pre_use = function(self, t) return self.x and game.level and not game.level.map.lites(self.x, self.y) end,
	getStealth = function(self, t) return self:combatTalentSpellDamage(t, 3, 150) end,
	callbackOnMove = function(self, t, moved, force, ox, oy)
		if not moved or force then return end
		self:forceUseTalent(t.id, {ignore_energy=true})
	end,
	activate = function(self, t)
		local ret = {}
		self:talentTemporaryValue(ret, "stealth", t.getStealth(self, t))
		self:talentTemporaryValue(ret, "lite", -1000)
		if self.updateMainShader then self:updateMainShader() end
		return ret
	end,
	deactivate = function(self, t, p)
		return true
	end,
	info = function(self, t)
		return ([[Whenever you are on an unlit grid you can meld with the shadows, gaining %d stealth power.
		Your equiped lite does not count and will be turned off when activating.
		Moving will cancel the effect.
		Stealth power depends on Spellpower.]]):
		format(t.getStealth(self, t))
	end,
}

newTalent{
	name = "Blood Shield", short_name = "DEMON_SEED_BLOOD_SHIELD",
	type = {"corruption/demon-seeds",1},
	points = 5,
	mode = "sustained",
	drain_vim = 2,
	cooldown = 10,
	tactical = { BUFF = 10, },
	no_energy = true,
	getPercent = function(self, t) return self:combatTalentScale(t, 100, 220) end,
	on_pre_use = function(self, t, silent) if not self:hasShield() then if not silent then game.logPlayer(self, "You require a weapon and a shield to use this talent.") end return false end return true end,
	callbackOnMeleeHit = function(self, t, src, dam)
		if not src.x then return end
		local block = self:combatShieldBlock()
		if not block then return end

		DamageType:get(DamageType.SHADOWFLAME).projector(src, src.x, src.y, DamageType.SHADOWFLAME, block * 0.35 * t.getPercent(self, t) / 100)
	end,
	activate = function(self, t)
		local block = self:combatShieldBlock()
		if not block then return end

		local ret = {}
		self:talentTemporaryValue(ret, "flat_damage_armor", {all=block * 0.15})
		local h2x, h2y = self:attachementSpot("hand2", true) if h2x then ret.particle = self:addParticles(Particles.new("blood_shield", 1, {x=h2x, y=h2y-0.1})) end
		return ret
	end,
	deactivate = function(self, t, p)
		self:removeParticles(p.particle)
		return true
	end,
	info = function(self, t)
		return ([[By channeling doom forces in your shield you constantly apply 15%% of its block value as a flat damage reduction against all damage.
		Whenever you are hit in melee your shield retaliates automatically for %d%% of its block value as fire and darkness damage.]]):
		format(0.35 * t.getPercent(self, t))
	end,
}

newTalent{
	name = "Silence", short_name = "DEMON_SEED_SILENCE",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = 20,
	vim = 10,
	range = 7,
	direct_hit = true,
	requires_target = true,
	tactical = { DISABLE = { silence = 3 } },
	getDuration = function(self, t) return math.floor(self:combatTalentScale(t, 5, 9)) end,
	action = function(self, t)
		local tg = {type="hit", range=self:getTalentRange(t), talent=t}
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		self:project(tg, x, y, DamageType.SILENCE, {power_check = self:combatSpellpower(), dur=t.getDuration(self, t)}, {type="mind"})
		return true
	end,
	info = function(self, t)
		return ([[Corrupt the target, silencing it for %d turns.]]):
		format(t.getDuration(self, t))
	end,
}

newTalent{
	name = "Fiery Portal", short_name = "DEMON_SEED_FIERY_PORTAL",
	type = {"corruption/demon-seeds",1},
	points = 5,
	cooldown = function(self, t) return math.floor(self:combatTalentLimit(t, 15, 30, 20)) end,
	vim = 20,
	range = 10,
	direct_hit = true,
	requires_target = true,
	tactical = { ESCAPE = 1, CLOSEIN = 1 },
	getDuration = function(self, t) return math.floor(self:combatTalentScale(t, 3, 7)) end,
	action = function(self, t)
		local tg = {type="hit", range=self:getTalentRange(t), talent=t}
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		local _ _, _, _, x, y = self:canProject(tg, x, y)
		if not self:canMove(x, y) then return nil end

		local oe = game.level.map(x, y, Map.TERRAIN)
		if not oe or oe.special then return end
		if not oe or oe:attr("temporary") or game.level.map:checkEntity(x, y, Map.TERRAIN, "block_move") then return end

		local oo = game.level.map(self.x, self.y, Map.TERRAIN)
		if not oo or oo.special then return end
		if not oo or oo:attr("temporary") or game.level.map:checkEntity(self.x, self.y, Map.TERRAIN, "block_move") then return end

		local function make_portal(oe, x, y, tx, ty)
			local o = Object.new{
				type = "portal", subtype = "demonic",
				name = "fiery portal",
				on_added = function(self, level, x, y)
					local ps = self.add_displays[#self.add_displays-1]:addParticles(require("engine.Particles").new("farportal_vortex", 1, {rot=3, size=42, vortex="shockbolt/terrain/planar_demon_vortex"})) ps.dy = -0.05
					-- Why the hell do I need to divide by 2 ??????
					local ps = self.add_displays[#self.add_displays-1]:addParticles(require("engine.Particles").new("fiery_portal_link", 1, {tx=(self.tx-self.x)/2, ty=(self.ty-self.y)/2})) ps.dy = -0.05
				end,
				display = '>', color_r=255, color_g=255, color_b=0,
				notice = true,
				always_remember = true,
				temporary = 4 + self:getTalentLevel(t),
				x = x, y = y, old_feat = oe,
				tx = tx, ty = ty,
				act = function(self)
					self:useEnergy()
					self.temporary = self.temporary - 1
					if self.temporary <= 0 then
						game.level.map(self.x, self.y, engine.Map.TERRAIN, self.old_feat)
						game.level:removeEntity(self)
						game.level.map:updateMap(self.x, self.y)
						game.nicer_tiles:updateAround(game.level, self.x, self.y)
					end
				end,
				summoner_gain_exp = true,
				summoner = self,
				on_move = function(self, x, y, who)
					if not who then return end
					if who.__fiery_portaling then return end
					who.__fiery_portaling = true
					who:move(self.tx, self.ty, true)
					if config.settings.tome.smooth_move > 0 then
						who:resetMoveAnim()
						who:setMoveAnim(x, y, 9, 5)
					end
					who.__fiery_portaling = nil
				end,
			}
			o.image = oe.image
			if oe.add_mos then o.add_mos = table.clone(oe.add_mos, true) end
			if oe.add_displays then o.add_displays = table.clone(oe.add_displays) else o.add_displays = {} end
			o.add_displays[#o.add_displays+1] = Object.new{z=4, image="terrain/planar_demon_portal_ground_down.png", display_x=0, display_y=0, display_w=1, display_h=1}
			o.add_displays[#o.add_displays+1] = Object.new{z=16, image="terrain/planar_demon_portal_ground_up.png", display_x=-0, display_y=0, display_w=1, display_h=1}

			if core.shader.active(4) then
				game.level.map:particleEmitter(x, y, 1, "shader_ring_rotating", {rotation=0, radius=1, life=30, img="flamesgeneric"}, {type="firesurge"})
			else
				game.level.map:particleEmitter(x, y, 1, "demon_teleport")
			end

			return o
		end

		local pe = make_portal(oe, x, y, self.x, self.y)
		game.level:addEntity(pe)
		game.level.map(x, y, Map.TERRAIN, pe)
		pe:on_added(game.level, x, y)

		local po = make_portal(oo, self.x, self.y, x, y)
		game.level:addEntity(po)
		game.level.map(self.x, self.y, Map.TERRAIN, po)
		po:on_added(game.level, self.x, self.y)
		po:on_move(self.x, self.y, self)

		return true
	end,
	info = function(self, t)
		return ([[Create two interlinked portals for %d turns.]]):
		format(t.getDuration(self, t))
	end,
}

newTalent{
	name = "Doom Tendrils", short_name = "DEMON_SEED_DOOM_TENDRILS",
	type = {"corruption/demon-seeds",1},
	points = 5,
	mode = "sustained",
	sustain_vim = 20,
	cooldown = 10,
	tactical = { BUFF = 10, },
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 10, 210) / 5 end,
	callbackOnAct = function(self, t)
		self:project({type="ball", radius=2, selffire=false}, self.x, self.y, function(px, py)
			local target = game.level.map(px, py, Map.ACTOR)
			if not target or self:reactionToward(target) >= 0 then return end
			
			local dam = DamageType:get(DamageType.FIRE).projector(self, px, py, DamageType.FIRE, self:spellCrit(t.getDamage(self, t)))
			if dam and dam > 0 and target:canBe("pin") then
				target:setEffect(target.EFF_PINNED, 2, {apply_power=self:combatSpellpower()})
			end
		end)
	end,
	activate = function(self, t)
		local ret = {}
		ret.particle = self:addParticles(Particles.new("doom_tendrils", 1))
		return ret
	end,
	deactivate = function(self, t, p)
		self:removeParticles(p.particle)
		return true
	end,
	info = function(self, t)
		return ([[You turn into a pillar of doom, sprouting flame tendrils in radius 2 around you.
		All foes hit by the tendrils take %0.2f fire damage per turn.
		If the creature suffers damage from the fire it is pinned to the ground.]]):
		format(damDesc(self, DamageType.FIRE, t.getDamage(self, t)))
	end,
}

newTalent{
	name = "Doomed Nature", short_name = "DEMON_SEED_DOOMED_NATURE",
	type = {"corruption/demon-seeds",1},
	points = 5,
	vim = 10,
	cooldown = 15,
	tactical = { DISABLE = 2, },
	range = 7,
	direct_hit = true,
	requires_target = true,
	tactical = { DISABLE = 2 },
	getChance = function(self, t) return math.floor(self:combatTalentScale(t, 20, 50)) end,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 20, 200) end,
	action = function(self, t)
		local tg = {type="hit", range=self:getTalentRange(t), talent=t}
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		self:project(tg, x, y, function(px, py)
			local target = game.level.map(px, py, Map.ACTOR)
			if not target then return end
			target:setEffect(target.EFF_DEMON_SEED_DOOMED_NATURE, 5, {apply_power=self:combatSpellpower(), chance=t.getChance(self, t), dam=dam, src=self})
			game.level.map:particleEmitter(px, py, 1, "circle", {shader=true, oversize=1, a=150, appear=8, limit_life=14, speed=0, base_rot=180, img="doomed_nature", radius=0})
		end)
		return true
	end,
	info = function(self, t)
		return ([[You curse a target for 5 turns to sever its connection to Nature.
		Each time it tries to use a natural power it has %d%% chances to fail and instead trigger a fireball of radius 1 doing %0.2f fire damage.
		The damage increases with you Spellpower stat.]]):
		format(t.getChance(self, t), damDesc(self, DamageType.FIRE, t.getDamage(self, t)))
	end,
}

newTalent{
	name = "Acid Burst", short_name = "DEMON_SEED_ACID_BURST",
	type = {"corruption/demon-seeds",1},
	points = 5,
	mode = "passive",
	target = function(self, t)
		return {type="ball", range=0, radius=3}
	end,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 15, 80) end,
	getDuration = function(self, t) return math.floor(self:combatTalentScale(t, 3, 7)) end,
	callbackOnBlock = function(self, t)
		if self.turn_procs.demon_acid_burst then return end
		self.turn_procs.demon_acid_burst = true
		local tg = self:getTalentTarget(t)
		local _ _, _, _, x, y = self:canProject(tg, self.x, self.y)
		-- Add a lasting map effect
		game.level.map:addEffect(self,
			x, y, t.getDuration(self, t),
			DamageType.ACID, t.getDamage(self, t),
			3,
			5, nil,
			{type="vapour"},
			nil, false
		)
		game:playSoundNear(self, "talents/cloud")
	end,
	info = function(self, t)
		return ([[Whenever you block an attack with your shield, you release a cloud of acidic vapour, dealing %d damage in an area of radius 3 over %d turns.
		The damage will increase with your spellpower.]]):
		format(damDesc(self, DamageType.ACID, t.getDamage(self,t)), t.getDuration(self,t))
	end,
}

newTalent{
	name = "Corrosive Cone", short_name = "DEMON_SEED_ACID_CONE",
	type = {"corruption/demon-seeds",1},
	points = 5,
	radius = 5,
	mode = "passive",
	target = function(self, t) return {type="cone", range=self:getTalentRange(t), radius=self:getTalentRadius(t), talent=t, cone_angle = 45, force_target=target} end,
	getDamage = function(self, t) return self:combatTalentSpellDamage(t, 20, 160) end,
	callbackOnMeleeAttack = function(self, t, target, hitted, critted)
		if not hitted or not critted then return end
		if not target.x or not target.y then return end

		local tg = self:getTalentTarget(t)

		self:project(tg, target.x, target.y, DamageType.DIG, 100)
		self:project(tg, target.x, target.y, DamageType.ACID, self:spellCrit(t.getDamage(self, t)))
		game.level.map:particleEmitter(self.x, self.y, tg.radius, "breath_acid", {radius=tg.radius, tx=target.x-self.x, ty=target.y-self.y, cone_angle = 45})

		game:playSoundNear(self, "talents/breath")
	end,
	info = function(self, t)
		local damage = t.getDamage(self, t)
		return ([[When you deal a critical strike in melee, you send out a cone of acid, dealing %d damage to all enemies and melting walls you hit.
		The damage will increase with your Spellpower.]]):
		format(damDesc(self, DamageType.ACID, damage))
	end,
}

newTalent{
	name = "Armoured Leviathan", short_name = "DEMON_SEED_ARMOURED_LEVIATHAN",
	type = {"corruption/demon-seeds",1},
	points = 5,
	vim = 10,
	cooldown = 21,
	range = 10,
	direct_hit = true,
	requires_target = true,
	tactical = { BUFF = 2 },
	getDuration = function(self, t) return math.floor(self:combatTalentScale(t, 3, 7)) end,
	on_pre_use = function(self, t, silent) if not self:hasShield() then if not silent then game.logPlayer(self, "You require a weapon and a shield to use this talent.") end return false end return true end,
	action = function(self, t)
		local block = self:combatShieldBlock()
		if not block then return end

		self:setEffect(self.EFF_DEMON_SEED_ARMOURED_LEVIATHAN, t.getDuration(self, t), {power=block*0.1})
		return true
	end,
	info = function(self, t)
		return ([[You enchant your shield to grant you power for %d turns.
		While the effect last your Strength and Magic stats are increased by 10%% of your shield block value.]]):
		format(t.getDuration(self, t))
	end,
}

newTalent{
	name = "Flash Block", short_name = "DEMON_SEED_FLASH_BLOCK",
	type = {"corruption/demon-seeds",1},
	points = 5,
	vim = 5,
	cooldown = function(self, t) return math.floor(self:combatTalentLimit(t, 5, 12, 7)) end,
	range = 1,
	requires_target = true,
	no_energy = true,
	tactical = { ATTACK = 3, DEFEND = 3 },
	on_pre_use = function(self, t, silent)
		if not self:hasShield() then if not silent then game.logPlayer(self, "You require a weapon and a shield to use this talent.") end return false end
		if self:isTalentCoolingDown(self.T_BLOCK) then return false end
		return true
	end,
	action = function(self, t)
		self:forceUseTalent(self.T_BLOCK, {ignore_energy=true})
		local h2x, h2y = self:attachementSpot("hand2", true)
		if not h2x then h2x, h2y = 0, 0 end
		self:addParticles(Particles.new("circle", 1, {zdepth=6, shader=true, oversize=1.6, speed=0, base_rot=180, a=190, appear=8, limit_life=8, img="flash_block", radius=0, x=-h2x, y=h2y}))
		return true
	end,
	info = function(self, t)
		return ([[In a fiery display of speed you raise your shield to block instantly.]]):
		format()
	end,
}

newTalent{
	name = "Blackice", short_name = "DEMON_SEED_BLACKICE",
	type = {"corruption/demon-seeds",1},
	points = 5,
	vim = 6,
	range = 5,
	requires_target = true,
	no_energy = true,
	tactical = { ATTACK = 3, DEFEND = 3 },
	getStack = function(self, t) return math.floor(self:combatTalentScale(t, 1, 5)) end,
	getRes = function(self, t) return 10 + self:combatTalentSpellDamage(t, 2, 500) / 10 end,
	callbackOnKill = function(self, t, target, death_note)
		if not target.x or not self.x or not death_note or not death_note.damtype or death_note.damtype == DamageType.FIRE or core.fov.distance(self.x, self.y, target.x, target.y) > 1 then return end
		self:setEffect(self.EFF_BLACKICE, 20, {max_stacks=t.getStack(self, t)})
	end,
	on_pre_use = function(self, t, silent)
		if not self:hasEffect(self.EFF_BLACKICE) then return false end
		return true
	end,
	action = function(self, t)
		local eff = self:hasEffect(self.EFF_BLACKICE)
		if not eff then return end

		local tg = {type="hit", range=self:getTalentRange(t), talent=t}
		local x, y = self:getTarget(tg)
		if not x or not y then return nil end
		local _ _, x, y = self:canProject(tg, x, y)
		local target = game.level.map(x, y, Map.ACTOR)

		if not target then return end

		eff.stacks = eff.stacks - 1
		if eff.stacks <= 0 then self:removeEffect(self.EFF_BLACKICE) end

		target:setEffect(target.EFF_BLACKICE_DET, 7, {apply_power=self:combatSpellpower(), power=t.getRes(self, t)})

		return true
	end,
	info = function(self, t)
		return ([[Each time your kill a creature with non-fire damage in melee range you gain a blackice charge for 20 turns (stacking to %d).
		At any moment you can use a charge to infect a creature with blackice, reducing its fire resistance by %d%% for 7 turns.]]):
		format(t.getStack(self, t), t.getRes(self, t))
	end,
}
