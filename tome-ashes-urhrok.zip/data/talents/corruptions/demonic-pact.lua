-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

local Dialog = require "engine.ui.Dialog"
local Stats = require "engine.interface.ActorStats"

demon_seeds_effects = {
	["fire imp"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_FIRE_BOLTS] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.resists = {[DamageType.FIRE] = 10 + math.ceil(lvl/2)}
			o.object_tinker.wielder.flat_damage_armor = {[DamageType.FIRE] = math.ceil(lvl/2)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_FIERY_CLEANSING] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen_when_hit = 1
		end,
	},
	["wretchling"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_CORROSIVE_SLASHES] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.resists = {[DamageType.ACID] = 10 + math.ceil(lvl/2)}
			o.object_tinker.wielder.flat_damage_armor = {[DamageType.ACID] = math.ceil(lvl/2)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_ACIDIC_BATH] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen_when_hit = 1
		end,
	},
	["quasit"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_FARSTRIKE] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.resists = {[DamageType.PHYSICAL] = 10 + math.ceil(lvl/2)}
			o.object_tinker.wielder.flat_damage_armor = {[DamageType.PHYSICAL] = math.ceil(lvl/2)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_RUSH] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen_when_hit = 2
		end,
	},
	["water imp"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_FROST_GRAB] = math.ceil(lvl/10)}
			o.object_tinker.wielder.mana_regen = 0.5
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.resists_pen = {[DamageType.DARKNESS] = 5 + math.ceil(lvl/2.5)}
			o.object_tinker.wielder.flat_damage_armor = {[DamageType.DARKNESS] = math.ceil(lvl/2)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_BLACKICE] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen_when_hit = 2
		end,
	},
	["dolleg"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.talent_level = math.ceil(lvl/10)
			o.on_tinker = function(self, o, who)
				if not o.combat then return true end
				o.combat.talent_on_hit = o.combat.talent_on_hit or {}
				o.combat.talent_on_hit.T_BLOOD_GRASP = {level=self.talent_level, chance=20}
			end
			o.on_untinker = function(self, o, who)
				if not o.combat or not o.combat.talent_on_hit then return true end
				o.combat.talent_on_hit.T_BLOOD_GRASP = nil
			end
			o.special_desc = function(self) return "20% chance to trigger a Blood Grasp cast of level "..self.talent_level end
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.resists = {[DamageType.BLIGHT] = 10 + math.ceil(lvl/2)}
			o.object_tinker.wielder.flat_damage_armor = {[DamageType.BLIGHT] = math.ceil(lvl/2)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_BLIGHTED_PATH] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 1
		end,
	},
	["dúathedlen"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_CORRUPT_LIGHT] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.esp = { demon = 1 }
			if lvl > 20 then o.object_tinker.wielder.esp.humanoid = 1 end
			if lvl >= 50 then o.object_tinker.wielder.esp = nil o.object_tinker.wielder.esp_all = 1 end
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_SHADOWMELD] = math.ceil(lvl/10)}
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 1
		end,
	},
	["uruivellas"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DISARM] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_BATTLE_CALL] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.global_speed_add = 0.1 + math.ceil(lvl/5) / 100
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 2
		end,
	},
	["thaurhereg"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.talent_level = math.ceil(lvl/10)
			o.on_tinker = function(self, o, who)
				if not o.combat then return true end
				o.combat.talent_on_hit = o.combat.talent_on_hit or {}
				o.combat.talent_on_hit.T_DEMON_SEED_SILENCE = {level=self.talent_level, chance=25}
			end
			o.on_untinker = function(self, o, who)
				if not o.combat or not o.combat.talent_on_hit then return true end
				o.combat.talent_on_hit.T_DEMON_SEED_SILENCE = nil
			end
			o.special_desc = function(self) return "25% chance to trigger a Silence cast of level "..self.talent_level end
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_BLOOD_SHIELD] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.silence_immune = math.ceil(math.scale(lvl, 1, 50, 25, 100)) / 100
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 2
		end,
	},
	["daelach"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_DOOM_TENDRILS] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_FIERY_PORTAL] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.stun_immune = math.ceil(math.scale(lvl, 1, 50, 25, 100)) / 100
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 3
		end,
	},
	["wretch titan"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_ACID_CONE] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_ACID_BURST] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.ignore_direct_crits = math.ceil(math.scale(lvl, 1, 50, 10, 35))
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_on_melee = 3
		end,
	},
	["champion of Urh'Rok"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_DOOMED_NATURE] = math.ceil(lvl/10)}
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_ARMOURED_LEVIATHAN] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			local stats = math.ceil(lvl / 10)*2.5
			o.object_tinker.wielder.max_life = 2.5 * lvl
			o.object_tinker.wielder.inc_stats = { [Stats.STAT_MAG] = stats, [Stats.STAT_STR] = stats }
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen = 1
		end,
	},
	["forge-giant"] = {
		MAINHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_INFERNO] = math.ceil(lvl/10)}
			o.object_tinker.wielder.mana_regen = 0.5
		end,
		OFFHAND = function(self, t, o, host, lvl)
			o.object_tinker.wielder.learn_talent = {[self.T_DEMON_SEED_FLASH_BLOCK] = math.ceil(lvl/10)}
		end,
		BODY = function(self, t, o, host, lvl)
			o.object_tinker.wielder.reduce_detrimental_status_effects_time = 40
			o.special_desc = function(self) return "Reduces duration of detrimental effects by 40%" end
		end,
		FINGER = function(self, t, o, host, lvl)
			o.object_tinker.wielder.vim_regen = 1
		end,
	},
}

local seeds = {
	[1] = {"fire imp", "wretchling"},
	[2] = {"quasit", "water imp"},
	[3] = {"dolleg", "dúathedlen"},
	[4] = {"uruivellas", "thaurhereg"},
	[5] = {"daelach", "wretch titan"},
	[6] = {"forge-giant", "champion of Urh'Rok"},
}
demon_seeds_tiers = seeds

local demons = nil

availableDemonSeed = function(self, t)
	local list = {}
	self:inventoryApplyAll(function(inven, item, o) if o.tinker and o.tinker.is_tinker == "demon-seed" then
		if inven.worn and (not o.tinker.demon.dead or o.tinker.demon.dead_by_unsummon) and game.level and not game.level:hasEntity(o.tinker.demon) then
			list[#list+1] = {name=("%s (%d/%d life, level %d)"):format(o.tinker.demon.name, o.tinker.demon.life, o.tinker.demon.max_life, o.tinker.demon.level), demon=o.tinker.demon}
		end
	end end)
	return #list > 0, list
end

createSeed = function(self, t, host, force_first)
	if not demons then
		local t = mod.class.NPC:loadList{"/data/general/npcs/minor-demon.lua", "/data/general/npcs/major-demon.lua", "/data/general/npcs/aquatic_demon.lua"}
		demons = {}
		for i, d in ipairs(t) do
			if d.name then demons[d.name] = d end
		end
	end

	local mlvl = util.bound(math.floor(self:getTalentLevel(t)), 1, 6)
	local lvl = mlvl
	if rng.percent(75) then lvl = rng.range(1, mlvl) end

	local slot = rng.table(table.keys(self.tinker_restrict_slots))
	local kind
	-- slot = "MAINHAND"
	if force_first then slot = "MAINHAND" end

	if host.type == "demon" then
		kind = host.name
		if not demons[kind] then kind = rng.table(seeds[lvl]) end
	else
		kind = rng.table(seeds[lvl])
	end
	-- kind = "dolleg"
	if force_first then kind = "fire imp" end
	if not demons[kind] then return end

	local hlevel = util.bound(host.level, 1, 50)

	local found = false
	self:inventoryApplyAll(function(inven, item, o) if o.type == "seed" and o.subtype == "demon" and o.demon then
		print("Testing superior demon", o.demon.name, o.demon.level, "against trying to make", kind, hlevel)
		if o.demon.name == kind and o.on_slot == slot and o.demon.level >= hlevel then
			game.logPlayer(self, "#RED#You fail to extract a demon seed [%s] (level %d, %s) because you already have one of this kind with a same or higher level.", kind, hlevel, slot:lower())
			found = true
		end
	end end)
	if found then return end

	local demon = demons[kind]
	if demon then
		demon = demon:cloneFull()
		demon.start_level = hlevel
		demon.level_range = {hlevel, hlevel}
		demon:resolve()
		demon:resolve(nil, true)
		demon.make_escort = nil
		demon.summon = nil
		demon:forceLevelup(hlevel)
		demon.levelup = function() end
		demon.forceLevelup = function() end
		if demon.level > hlevel then
			local diff = demon.level - hlevel
			demon.generic_damage_penalty = 50 * diff / demon.level
			demon.max_life = 30 * diff / demon.level
			demon.life = demon.max_life
			demon.level = hlevel
		end
	end

	local o = mod.class.Object.new{
		power_source = {arcane=true},
		type = "seed", subtype = "demon",
		identified=true, no_unique_lore = true,
		name = "demon seed ["..kind.."] (level "..hlevel..", "..slot:lower()..")", display = '*', color=colors.RED, unique=true,
		image = (demon or host).image, add_mos = (demon or host).add_mos,
		desc = [[The seed of a demon.]],
		cost = 0, encumber = 0,
		is_tinker = "demon-seed",
		rarity = false,
		on_slot = slot,
		material_level = lvl,
		demon = demon,
		object_tinker = { wielder = {} },
		tinker_allow_attach = function(self) if self.demon.dead and not self.demon.dead_by_unsummon then return "demon is dead" end end,
		special_desc = function(self) return ("Demon status: %s."):format((not self.demon.dead or self.demon.dead_by_unsummon) and ("alive (%d%% life)"):format(100*self.demon.life/self.demon.max_life) or "dead (does not provide benefits)") end,
	}
	if demon_seeds_effects[kind] and demon_seeds_effects[kind][slot] then
		demon_seeds_effects[kind][slot](self, t, o, host, hlevel)
	end

	local attach_inven, attach_item, free = self:findTinkerSpot(o)
	local worn, base_o = false, nil
	if attach_inven and attach_item and free then
		worn, base_o = self:doWearTinker(nil, nil, o, attach_inven, attach_item, nil, false)
	end
	
	if not worn then
		self:addObject("INVEN", o)
		self:sortInven()		
		game.logPlayer(self, "#CRIMSON#You extract a %s and add it to your inventory.", o:getName{do_color=true})
	else
		game.logPlayer(self, "#CRIMSON#You extract a %s and bind it to your %s.", o:getName{do_color=true}, base_o:getName{do_color=true})
	end
	if self.player then world:gainAchievement("ASHES_SEED_500", self) end
end

newTalent{
	name = "Demon Seed",
	type = {"corruption/demonic-pact", 1},
	require = {
		stat = { mag=function(level) return 12 + (level-1) * 2 end },
		level = function(level) return 0 + (level-1) * 6  end,
	},
	points = 5,
	vim = 5,
	stamina = 8,
	cooldown = 8,
	range = 1,
	no_npc_use = true,
	requires_target = true,
	tactical = { ATTACK = 2, DISABLE = { daze = 1 } },
	getDam = function(self, t) return self:combatTalentWeaponDamage(t, 0.6, 1.4, self:getTalentLevel(self.T_SHIELD_EXPERTISE)), self:combatTalentWeaponDamage(t, 0.6, 1.6) end,
	getDazeDuration = function(self, t) return math.floor(self:combatTalentScale(t, 2.5, 4.5)) end,
	on_pre_use = function(self, t, silent) if not self:hasShield() then if not silent then game.logPlayer(self, "You require a weapon and a shield to use this talent.") end return false end return true end,
	createSeed = createSeed,
	on_learn = function(self, t)
		local lvl = self:getTalentLevelRaw(t)
		if lvl == 1 then
			self.can_tinker = self.can_tinker or {}
			self.can_tinker["demon-seed"] = 1
			self.tinker_restrict_slots = { MAINHAND=1 }
		end
	end,
	on_unlearn = function(self, t)
		local lvl = self:getTalentLevelRaw(t)
		if lvl == 0 then
			self.can_tinker["demon-seed"] = nil
			self.tinker_restrict_slots.MAINHAND = nil
		end
	end,
	action = function(self, t)
		local shield, shield_combat = self:hasShield()
		if not shield then return nil end

		local tg = {type="hit", range=1}
		local x, y, target = self:getTarget(tg)
		if not x or not y or not target then return nil end
		if core.fov.distance(self.x, self.y, x, y) > 1 then return nil end

		local shielddam, weapondam = t.getDam(self, t)

		local hit = self:attackTarget(target, DamageType.BLIGHT, weapondam, true)

		if hit then
			-- We dont want the player to end up with a demon seed!
			local chance = 100
			if target.rank <= 2 then chance = 5
			elseif target.rank <= 3 then chance = 20
			elseif target.rank <= 3.5 then chance = 50
			end
			if config.settings.cheat then chance = 100 end

			-- First time it always works
			if not self:attr("used_demon_seed") then chance = 100 end

			if rng.percent(chance) and self.player and not target.demonic_summon and target.exp_worth > 0 and not game.party:hasMember(target) then
				if target.dead then
					createSeed(self, t, target, not self:attr("used_demon_seed"))
					game.level.map:particleEmitter(x, y, tg.radius, "circle", {oversize=0.7, a=90, limit_life=8, shader=true, appear=8, speed=2, img="blood_circle", radius=self:getTalentRadius(t)})
					self:attr("used_demon_seed", 1)
				else
					target:setEffect(target.EFF_DEMON_SEED, 1, {src=self, power=self:getTalentLevel(t), force_first=not self:attr("used_demon_seed")})
					game.level.map:particleEmitter(x, y, tg.radius, "circle", {oversize=0.7, a=90, limit_life=8, shader=true, appear=8, speed=2, img="blood_circle", radius=self:getTalentRadius(t)})
					self:attr("used_demon_seed", 1)
				end
			end

			local speed, hit2 = self:attackTargetWith(target, shield_combat, nil, shielddam) 
			if hit2 and target:canBe("stun") then target:setEffect(target.EFF_DAZED, t.getDazeDuration(self, t), {apply_power=self:combatSpellpower()}) end
		end

		game.level.map:particleEmitter(x, y, 1, "circle", {shader=true, oversize=1, a=120, appear=8, limit_life=14, speed=0, base_rot=180, img="demon_seed", radius=0})

		return true
	end,
	info = function(self, t)
		local shield, weapon = t.getDam(self, t)
		return ([[Strike a blow with your weapon for %d%% blight damage.
		If the attack hits a demonic seed tries to take hold inside your foe and you follow up with a shield strike dealing %d%% damage and dazing your target for %d turns.
		The seed requires a powerful host to nourish it and can only take hold in creatures that are worth experience and that are not summoned demons.
		The chance for the seed to take hold is based on the creatures rank:
		Normal:  5%%
		Elite:  20%%
		Rare or Unique:  50%%
		Boss:  100%%
		When the host dies the seed fills with the vim of the dying creature and turns into a specific demon seed that can be used to summon that demon
		A demonic seed will only be created if you do not already have a seed of this demon/slot of a superior level.
		Higher talent levels allow for more powerful demon types. ]])
		:format(weapon * 100, shield * 100, t.getDazeDuration(self, t))
	end,
}

local function listPopup(title, text, list, w, h, fct)
	local chars = {}
	for i = 1, #list do list[i].name = Dialog:makeKeyChar(i)..") "..list[i].name chars[Dialog:makeKeyChar(i)] = i end

	local d = Dialog.new(title, 1, 1)
	local desc = require("engine.ui.Textzone").new{width=w, auto_height=true, text=text, scrollbar=true}
	local l = require("engine.ui.List").new{width=w, height=h-16 - desc.h, list=list, fct=function() d.key:triggerVirtual("ACCEPT") end}
	d:loadUI{
		{left = 3, top = 3, ui=desc},
		{left = 3, top = 3 + desc.h + 3, ui=require("engine.ui.Separator").new{dir="vertical", size=w - 12}},
		{left = 3, bottom = 3, ui=l},
	}
	d.key:addBind("EXIT", function() if fct then fct() end game:unregisterDialog(d) end)
	d.key:addBind("ACCEPT", function() if list[l.sel].fct then list[l.sel].fct(list[l.sel]) return end if fct then fct(list[l.sel]) end game:unregisterDialog(d) end)
	d.key:addCommands{
		__TEXTINPUT = function(c)
			print("====", c, chars[c])
			if chars[c] then
				l.sel = chars[c]
				d.key:triggerVirtual("ACCEPT")
			end
		end,
	}
	d.on_register = function(self) game:onTickEnd(function() self.key:unicodeInput(true) end) end
	d:setFocus(l)
	d:setupUI(true, true)
	game:registerDialog(d)
	return d
end


newTalent{
	name = "Bind Demon",
	type = {"corruption/demonic-pact", 2},
	require = corrs_req2,
	no_unlearn_last = true,
	points = 5,
	vim = 25,
	cooldown = 30,
	getDur = function(self, t) return math.ceil(self:combatTalentScale(t, 4, 12)) end,
	onDemonDies = function(self, t) game:onTickEnd(function()
		for _, inven in ipairs{"MAINHAND", "OFFHAND", "BODY", "FINGER"} do
			local inven = self:getInven(inven)
			for i = 1, #inven do
				local o = inven[i]
				if o and o.tinker and o.tinker.is_tinker == "demon-seed" and o.tinker.demon then
					local demon = o.tinker.demon
					if demon.dead and not demon.dead_by_unsummon then						
						self:doTakeoffTinker(o, o.tinker)
					end
				end
			end
		end
	end) end,
	on_learn = function(self, t)
		local lvl = self:getTalentLevelRaw(t)
		if lvl == 1 then
			-- self.tinker_restrict_slots = {MAINHAND = 1}
			if not self.tinker_restrict_slots then self.tinker_restrict_slots = {} end
		elseif lvl == 2 then
			self.tinker_restrict_slots.FINGER = 1
		elseif lvl == 3 then
			self.tinker_restrict_slots.OFFHAND = 1
		elseif lvl == 4 then
			self.tinker_restrict_slots.FINGER = 2
		elseif lvl == 5 then
			self.tinker_restrict_slots.BODY = 1
		end
	end,
	on_unlearn = function(self, t)
		local lvl = self:getTalentLevelRaw(t)
		if lvl == 0 then
			-- self.tinker_restrict_slots = {}
			if table.keys(self.tinker_restrict_slots) == 0 then self.tinker_restrict_slots = nil end
		elseif lvl == 1 then
			self.tinker_restrict_slots.FINGER = nil
		elseif lvl == 2 then
			self.tinker_restrict_slots.OFFHAND = nil
		elseif lvl == 3 then
			self.tinker_restrict_slots.FINGER = 1
		elseif lvl == 4 then
			self.tinker_restrict_slots.BODY = nil
		end
	end,
	on_pre_use = availableDemonSeed,
	action = function(self, t)
		local _, list = availableDemonSeed(self, t)
		if #list == 0 then return nil end

		local demon
		if #list == 1 then
			demon = list[1].demon
		else
			demon = self:talentDialog(listPopup("Summon demon", "Which seed to use:", list, 500, 400, function(d)
				if not d then return end
				self:talentDialogReturn(d.demon)
			end))
			if not demon then return nil end
		end

		local tg = {type="bolt", nowarning=true, range=self:getTalentRange(t), nolock=true, talent=t}
		local tx, ty, target = self:getTarget(tg)
		if not tx or not ty then return nil end
		local _ _, _, _, tx, ty = self:canProject(tg, tx, ty)
		target = game.level.map(tx, ty, Map.ACTOR)
		if target == self then target = nil end

		-- Find space
		local x, y = util.findFreeGrid(tx, ty, 5, true, {[Map.ACTOR]=true})
		if not x then
			game.logPlayer(self, "Not enough space to summon!")
			return
		end

		demon.summon_time = t.getDur(self, t)
		demon.ai_target = {actor=target}

		setupDemonSummon(self, demon, x, y)
		game:playSoundNear(self, "talents/spell_generic")
		return true
	end,
	info = function(self, t)
		return ([[Your knowledge of demonic forces grows, allowing you to bind more seeds to you and to summon demons.
		You channel your arcane corruption through a demon seed to temporarily summon the corresponding demon for %d turns.
		Summoned demons can regen their life and resummoning them keeps the life they had when they were last used.
		If the demon dies it will not be available for summoning anymore.

		As you learn to bind more easily you can also use more seeds:
		At level 2 it lets you bind a seed to your first ring.
		At level 3 it lets you bind a seed to your shield.
		At level 4 it lets you bind a seed to your second ring.
		At level 5 it lets you bind a seed to your main body armour.
		]]):
		format(t.getDur(self, t))
	end,
}

newTalent{
	name = "Twisted Portal",
	type = {"corruption/demonic-pact", 3},
	require = corrs_req3,
	points = 5,
	vim = 15,
	cooldown = 9,
	getDur = function(self, t) return math.ceil(self:combatTalentScale(t, 2, 5)) end,
	tactical = { ESCAPE = 2 },
	requires_target = function(self, t) return self:getTalentLevel(t) >= 4 end,
	getRange = function(self, t) return self:combatLimit(self:combatTalentSpellDamage(t, 10, 15), 40, 4, 0, 13.4, 9.4) end, -- Limit to range 40
	getRadius = function(self, t) return math.floor(self:combatTalentLimit(t, 0, 7, 3)) end, -- Limit to radius 0	
	is_teleport = true,
	on_pre_use = availableDemonSeed,
	action = function(self, t)
		local _, list = availableDemonSeed(self, t)
		if #list == 0 then return nil end

		local x, y = self.x, self.y
		local rad = t.getRange(self, t)
		local radius = t.getRadius(self, t)
		game.logPlayer(self, "Select a teleport location...")
		local tg = {type="ball", nolock=true, pass_terrain=true, nowarning=true, range=rad, radius=radius, requires_knowledge=false}
		x, y = self:getTarget(tg)
		if not x then return nil end
		-- Target code does not restrict the self coordinates to the range, it lets the project function do it
		-- but we cant ...
		local _ _, x, y = self:canProject(tg, x, y)
		rad = radius

		-- Check LOS
		if not self:hasLOS(x, y) and rng.percent(35 + (game.level.map.attrs(self.x, self.y, "control_teleport_fizzle") or 0)) then
			game.logPlayer(self, "The targetted phase door fizzles and works randomly!")
			x, y = self.x, self.y
			rad = t.getRange(self, t)
		end

		local ox, oy = self.x, self.y
		game.level.map:particleEmitter(self.x, self.y, 1, "demon_teleport")
		self:teleportRandom(x, y, rad)
		game.level.map:particleEmitter(self.x, self.y, 1, "demon_teleport")

		if not game.level.map(ox, oy, Map.ACTOR) then
			local demon = rng.table(list).demon
			demon.summon_time = t.getDur(self, t)
			demon.ai_target = {}
			setupDemonSummon(self, demon, ox, oy)
		end

		game:playSoundNear(self, "talents/teleport")
		return true
	end,
	info = function(self, t)
		local radius = t.getRadius(self, t)
		local range = t.getRange(self, t)
		return ([[Teleports you randomly within a small range of up to %d grids with %d precision.
		In the spot you left you will summon a random demon from your seeds for %d turns.
		If the target area is not in line of sight, there is a chance the spell will fizzle.
		This spell requires an unsummoned, alive, demon seed to work.
		The range will increase with your Spellpower.]]):format(range, radius, t.getDur(self, t))
	end,
}

newTalent{
	name = "Suffuse Life",
	type = {"corruption/demonic-pact", 4},
	require = corrs_req4,
	points = 5,
	mode = "passive",
	getVals = function(self, t) return
		self:combatTalentScale(t, 2, 10),
		100 or self:combatTalentScale(t, 10, 30),
		self:combatTalentScale(t, 3, 8)
	end,
	callbackOnKill = function(self, t, target)
		local healpct, rezchance, leech = t.getVals(self, t)

		-- Heal
		local list = {}
		self:inventoryApplyAll(function(inven, item, o) if o.tinker and o.tinker.is_tinker == "demon-seed" then
			if (not o.tinker.demon.dead or o.tinker.demon.dead_by_unsummon) and o.tinker.demon.life < o.tinker.demon.max_life then
				list[#list+1] = {name=o.tinker:getName{do_color=true}:toString(), demon=o.tinker.demon}
			end
		end end)
		if #list > 0 then
			local demon = rng.table(list).demon
			demon:heal(demon.max_life * healpct / 100)
			game.logPlayer(self, "#CRIMSON#Your %s is healed!", demon.name)
		end

		-- Rez
		if target.rank >= 3 and rng.percent(rezchance) then
			local list = {}
			self:inventoryApplyAll(function(inven, item, o) if o.is_tinker == "demon-seed" then
				if o.demon.dead and not o.demon.dead_by_unsummon then
					list[#list+1] = {name=o:getName{do_color=true}:toString(), demon=o.demon}
				end
			end end)
			if #list > 0 then
				local demon = rng.table(list).demon
				demon.dead = nil
				demon.life = demon.max_life * 0.15
				game.logPlayer(self, "#CRIMSON#Your %s is brought back to life!", demon.name)
				game.level.map:particleEmitter(self.x, self.y, 1, "circle", {oversize=1.3, a=230, grow=true, limit_life=22, y=-0.2, speed=0, base_rot=0, img="suffuse_life", radius=0})
			end
		end
	end,
	callbackOnDealDamage = function(self, t, val, target, dead, death_note)
		if self:getTalentLevel(t) < 5 then return end
		local healpct, rezchance, leech = t.getVals(self, t)

		self:heal(leech * val / 100, self)
	end,
	info = function(self, t)
		local healpct, rezchance, leech = t.getVals(self, t)
		return ([[You drain the life of your foes to replinish yours and those of your demon seeds.
		Each time you kill a creature a random worn demon seed with less than 100%% life will be healed for %d%% life.
		If the creature is an elite or more you also have %d%% chance to resurrect a dead demon seed.
		At level 5 you also start to leech energies to heal yourself, all damage you do heals you for %d%%.]]):
		format(healpct, rezchance, leech)
	end,
}
