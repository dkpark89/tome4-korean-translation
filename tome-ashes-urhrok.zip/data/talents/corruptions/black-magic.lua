-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newTalent{
	name = "Bleak Outcome",
	type = {"corruption/black-magic", 1},
	require = corrs_req1,
	points = 5,
	mode = "sustained",
	cooldown = 10,
	sustain_vim = 15,
	getStack = function(self, t) return math.ceil(self:combatTalentScale(t, 3, 9)) end,
	callbackOnDealDamage = function(self, t, val, target, dead, death_note)
		if dead or not death_note or not death_note.damtype or target == self then return end
		if death_note.damtype ~= DamageType.DARKNESS and death_note.damtype ~= DamageType.FIRE and death_note.damtype ~= DamageType.ACID and death_note.damtype ~= DamageType.BLIGHT then return end
		if self.turn_procs.bleak_outcome and self.turn_procs.bleak_outcome ~= target then return end

		target:setEffect(target.EFF_BLEAK_OUTCOME, 1, {src=self, max_stacks=t.getStack(self, t)})
		self.turn_procs.bleak_outcome = target
	end,
	activate = function(self, t)
		return {}
	end,
	deactivate = function(self, t, p)
		return true
	end,
	info = function(self, t)
		return ([[Your actions foreshadow a bleak outcome for your foes.
		Each time you deal darkness, fire, blight or acid damage you curse your foe with an effect that stacks up to %d times (this can affect only one creature per turn).
		The vim you get for killing the creature is increased by 100%% for every stack of Bleak Outcome.
		The vim's worth of a creature depends on your Willpower.]]):
		format(t.getStack(self, t))
	end,
}

newTalent{
	name = "Stripped Life",
	type = {"corruption/black-magic", 2},
	require = corrs_req2,
	points = 5,
	mode = "passive",
	getSpellpowerIncrease = function(self, t) return self:combatTalentScale(t, 8, 38, 0.75) end,
	info = function(self, t)
		return ([[When a creature dies with at least 5 stacks of Bleak Outcome you feast on every last bit of vim it had, increasing your own spellpower by %d for 6 turns.]])
		:format(t.getSpellpowerIncrease(self, t))
	end,
}

newTalent{
	name = "Grim Future",
	type = {"corruption/black-magic", 3},
	require = corrs_req3,
	points = 5,
	mode = "passive",
	radius = function(self, t) return self:combatTalentLimit(t, 8, 2, 7) end,
	cooldown = function(self, t) return self:combatTalentLimit(t, 6, 25, 15) end,
	callbackOnKill = function(self, t, target, death_note)
		if not target.x or not target:hasEffect(target.EFF_BLEAK_OUTCOME) or self:isTalentCoolingDown(t) then return end

		local affected = false
		self:project({type="ball", x=target.x, y=target.y, radius=self:getTalentRadius(t)}, target.x, target.y, function(px, py)
			local act = game.level.map(px, py, Map.ACTOR)
			if not act or target:reactionToward(act) < 0 then return end
			if act:canBe("stun") then
				act:setEffect(act.EFF_DAZED, 2, {apply_power=self:combatSpellpower()})
				if act:hasEffect(act.EFF_DAZED) then
					game.level.map:particleEmitter(px, py, 1, "circle", {shader=true, base_rot=180, oversize=1, a=80, appear=10, limit_life=20, speed=0, img="grim_future", radius=0})
					affected = true
				end
			end
		end)

		if affected then self:startTalentCooldown(t) end
	end,
	info = function(self, t)
		return ([[The future looks grim indeed... for your foes.
		When you kill a creature afflicted with Bleak Outcome all creatures allied to it in radius %d will be dazed for 2 turns.
		This effect will only trigger every %d turns (after a successful daze has been applied).]]):
		format(self:getTalentRadius(t), t.cooldown(self, t))
	end,
}

newTalent{
	name = "Ominous Shadow",
	type = {"corruption/black-magic", 4},
	require = corrs_req4,
	points = 5,
	vim = 4,
	cooldown = 2,
	direct_hit = true,
	requires_target = true,
	range = 10,
	no_energy = true,
	tactical = { BUFF = 1, ESCAPE = 2 },
	getStack = function(self, t) return math.ceil(self:combatTalentScale(t, 1, 6)) end,
	getInvisibilityPower = function(self, t) return self:combatTalentSpellDamage(t, 10, 50) end,
	callbackOnKill = function(self, t, target, death_note)
		if not target:hasEffect(target.EFF_BLEAK_OUTCOME) then return end
		self:setEffect(self.EFF_OMINOUS_SHADOW_CHARGES, 12, {max_stacks=t.getStack(self, t)})
	end,
	on_pre_use = function(self, t) return self:hasEffect(self.EFF_OMINOUS_SHADOW_CHARGES) end,
	action = function(self, t)
		self:setEffect(self.EFF_OMINOUS_SHADOW, 1, {power=t.getInvisibilityPower(self, t)})

		local eff = self:hasEffect(self.EFF_OMINOUS_SHADOW_CHARGES)
		eff.stacks = eff.stacks - 1
		if eff.stacks <= 0 then self:removeEffect(self.EFF_OMINOUS_SHADOW_CHARGES) end
		return true
	end,
	info = function(self, t)
		return ([[When a creature afflicted with Bleak Outcome dies you gain a charge of Ominous Shadow (up to %d) for 12 turns.
		Each charge can be used to become invisible (power %d) for 2 turns.]]):
		format(t.getStack(self, t), t.getInvisibilityPower(self, t))
	end,
}
