-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org


-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- Demon history & mistranslation
-------------------------------------------------------------------------
-------------------------------------------------------------------------
newLore{
	id = "ashes-urhrok-demon-history-mistranslated",
	category = "Ashes of Urh'Rok",
	name = "history of Mal'Rok (mistranslated)",
	lore = [=[(You see here a pile of strange tablets, all piled up in a nice, orderly stack.  You remove the top one, and study it; your finger slips across a square in one corner, and strange sentences start playing through your mind. You struggle to make sense of the unfamiliar words and concepts in your thoughts.)

Many #{italic}##FIREBRICK#[moon-craters]#{normal}##LAST# after he #{italic}##FIREBRICK#[planted]#{normal}##LAST# us and #{italic}##FIREBRICK#[retired]#{normal}##LAST#, the #{italic}##FIREBRICK#[Father]#{normal}##LAST# awoke from his #{italic}##FIREBRICK#[cocoon]#{normal}##LAST# to see us #{italic}##FIREBRICK#[rattling]#{normal}##LAST#. He was shocked at our #{italic}##FIREBRICK#[wilted]#{normal}##LAST# state, asking us why we #{italic}##FIREBRICK#[rattled]#{normal}##LAST#; we told him about the #{italic}##FIREBRICK#[shaking]#{normal}##LAST# we had to suffer through, the way the planet was #{italic}##FIREBRICK#[jammed up]#{normal}##LAST# and how although our #{italic}##FIREBRICK#[peas in a pod]#{normal}##LAST# had #{italic}##FIREBRICK#[plugged the leaks]#{normal}##LAST# to keep the #{italic}##FIREBRICK#[beads]#{normal}##LAST# from #{italic}##FIREBRICK#[falling out]#{normal}##LAST#, the #{italic}##FIREBRICK#[brooms]#{normal}##LAST# kept sweeping our #{italic}##FIREBRICK#[dust bunnies]#{normal}##LAST# away, and there wasn't enough empty room to keep the #{italic}##FIREBRICK#[beads]#{normal}##LAST# from #{italic}##FIREBRICK#[cracking]#{normal}##LAST#.

(There is a larger square on the tablet here; you press your hand to it, and suddenly you see a desert planet, ravaged by constant dust-storms. You feel the futility of a short, greenish thing as he looks on his ruined crops; you feel the wrath of a red-skinned humanoid as he rushes at a large horde of small, onyx creatures, a sword in one hand and a fireball in the other. The images disappear as you remove your hand.)

#{italic}##FIREBRICK#[Father]#{normal}##LAST# gave us his #{italic}##FIREBRICK#[tools]#{normal}##LAST#, and after we #{italic}##FIREBRICK#[tripped the janitors?]#{normal}##LAST# he had us #{italic}##FIREBRICK#[shake gently?]#{normal}##LAST#, but instead of #{italic}##FIREBRICK#[rattling]#{normal}##LAST# we were #{italic}##FIREBRICK#[making music]#{normal}##LAST#, only #{italic}##FIREBRICK#[cracking]#{normal}##LAST# the #{italic}##FIREBRICK#[beads]#{normal}##LAST# that made us #{italic}##FIREBRICK#[out of tune]#{normal}##LAST#; our #{italic}##FIREBRICK#[beads]#{normal}##LAST# grew stronger, learned how to use #{italic}##FIREBRICK#[tools]#{normal}##LAST# of different #{italic}##FIREBRICK#[colors]#{normal}##LAST# than what the #{italic}##FIREBRICK#[Father]#{normal}##LAST# gave us. The #{italic}##FIREBRICK#[Father]#{normal}##LAST# loved to #{italic}##FIREBRICK#[hear our music]#{normal}##LAST#, and we were grateful he was there to #{italic}##FIREBRICK#[compose]#{normal}##LAST# for us when we needed; soon we were #{italic}##FIREBRICK#[writing our own music]#{normal}##LAST# and didn't need to #{italic}##FIREBRICK#[rattle]#{normal}##LAST# anymore, and the #{italic}##FIREBRICK#[Father]#{normal}##LAST# #{italic}##FIREBRICK#[retired]#{normal}##LAST#.

(Another larger square. You see a wonderful, loving #{italic}##FIREBRICK#[Father]#{normal}##LAST# descending on the planet, desert turning to lush forest with his touch; you worship him with your green and onyx and ruby brethren, all different shapes and sizes, united for the first time in appreciating all the good he's done for you. For the first time in ages, you know where your next meal is coming from, and you need not fear others killing you for your farmland, nor the dust storms. He holds the corpses of some reclusive earth-mages in his hand, the source of the storms; you would be angry at them, but you can only feel happiness for the future to come. You and your brethren start competing in an organized fashion, occasionally in fights again, but even when you die you know it's for the good of the planet; an age later, you and your brethren are smarter, stronger, and far happier than before, living in paradise. You remove your hand an instant later, and the feelings of worship and admiration drain from you.)

Eventually, the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# came. We tried to #{italic}##FIREBRICK#[crack their beads]#{normal}##LAST# but nothing happened; they did not try to #{italic}##FIREBRICK#[crack]#{normal}##LAST# us but instead promised us even more wonderful #{italic}##FIREBRICK#[sheet music]#{normal}##LAST# than what our #{italic}##FIREBRICK#[Father]#{normal}##LAST# had given us, under the condition that we let them #{italic}##FIREBRICK#[shatter]#{normal}##LAST# him. We refused, but we reached a #{italic}##FIREBRICK#[nasty pod]#{normal}##LAST# together; we'd #{italic}##FIREBRICK#[mute? pot?]#{normal}##LAST# the #{italic}##FIREBRICK#[Father]#{normal}##LAST# with the #{italic}##FIREBRICK#[tools]#{normal}##LAST# he gave us, leaving him a #{italic}##FIREBRICK#[lazy carpenter]#{normal}##LAST# and proving our #{italic}##FIREBRICK#[pod was shut]#{normal}##LAST# with the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST#. The #{italic}##FIREBRICK#[Father]#{normal}##LAST# wouldn't be #{italic}##FIREBRICK#[rattled or cracked]#{normal}##LAST# by this; he wouldn't even know. The #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# were pleased, and #{italic}##FIREBRICK#[smeared]#{normal}##LAST# their #{italic}##FIREBRICK#[eggsuckers]#{normal}##LAST# on our planet, letting us trade with #{italic}##FIREBRICK#[pods from other plants]#{normal}##LAST# from all other kinds of #{italic}##FIREBRICK#[gardens]#{normal}##LAST#. We tasted new food, learned new #{italic}##FIREBRICK#[tools]#{normal}##LAST#, and some #{italic}##FIREBRICK#[fancy]#{normal}##LAST# types of new #{italic}##FIREBRICK#[beads]#{normal}##LAST# came to our #{italic}##FIREBRICK#[garden]#{normal}##LAST#. We felt a little #{italic}##FIREBRICK#[noise]#{normal}##LAST# about our #{italic}##FIREBRICK#[Father]#{normal}##LAST#, but he was not #{italic}##FIREBRICK#[noisy]#{normal}##LAST# and wouldn't #{italic}##FIREBRICK#[hear]#{normal}##LAST# any #{italic}##FIREBRICK#[sounds]#{normal}##LAST#. The #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# acted as our #{italic}##FIREBRICK#[pod peas]#{normal}##LAST#, and we treated them with great #{italic}##FIREBRICK#[listening]#{normal}##LAST#, even as they #{italic}##FIREBRICK#[slipped from the pod]#{normal}##LAST# and we could no longer #{italic}##FIREBRICK#[attend each other's concerts]#{normal}##LAST#.

(You touch the panel on the next page. A creature appears before you, stepping out of a massive fortress - it has an egg-shaped body, and limbs like four #{italic}##FIREBRICK#[tendril-weeds]#{normal}##LAST#. You hate this thing with all your being, although you know you did not at the time. They say they want the #{italic}##FIREBRICK#[Father]#{normal}##LAST# dead, and can offer you great magic and technology in return; you loathe to consider the idea, but their fortresses and weapons make you wonder if their offer is truly optional. You consider waking #{italic}##FIREBRICK#[Father]#{normal}##LAST# to ask him for help, but worry that even he could not stand up to the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST#; ultimately you decided to seal him in his sleep, leaving him harmless but unharmed, unconscious until further intervention. The #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# begrudgingly accept this resolution, and keep up their end of the bargain. They give you strange, powerful artifacts, and build portals on your world that let you pass through to strange worlds, more incredible and beautiful than you could possibly imagine, and filled with other races who've been given these gifts and seek to trade. You taste new foods, learn new magic, hear new music, and discover more beauty than you have in your entire history. If not for the pangs of guilt, life could not be better. Only when you remove your hand and the images start clearing from your mind do you recognize the "egg-weeds" as the Sher'Tul.)

Then, there was great #{italic}##FIREBRICK#[noise]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It got #{italic}##FIREBRICK#[louder]#{normal}##LAST#. It was #{italic}##FIREBRICK#[eardrum-bursting]#{normal}##LAST#.

(There is another panel. You dare not touch it, but as you reach to put it away, a finger briefly brushes across it. Starvation, burning, suffocation, misery, fury, and sheer agony rage across your mind for what you know to be a tenth of a second, but feels like half a minute. Your ears are still ringing as you move on to the next square.)

The #{italic}##FIREBRICK#[eggsuckers]#{normal}##LAST# were a trap, a #{italic}##FIREBRICK#[discord]#{normal}##LAST# planted by the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# to #{italic}##FIREBRICK#[crack]#{normal}##LAST# us all, and only cause #{italic}##FIREBRICK#[hairline fracture]#{normal}##LAST# to their own #{italic}##FIREBRICK#[garden]#{normal}##LAST#. Their #{italic}##FIREBRICK#[wrong note]#{normal}##LAST# turned our planet to #{italic}##FIREBRICK#[cacophony]#{normal}##LAST#, and nearly all of us #{italic}##FIREBRICK#[fell out of the pod]#{normal}##LAST#. The #{italic}##FIREBRICK#[apple was peeled]#{normal}##LAST# and a fragment of our #{italic}##FIREBRICK#[shell]#{normal}##LAST# floated in the #{italic}##FIREBRICK#[ocean]#{normal}##LAST#. Our #{italic}##FIREBRICK#[handymen]#{normal}##LAST# acted quickly to give the #{italic}##FIREBRICK#[peel]#{normal}##LAST# and our #{italic}##FIREBRICK#[garden]#{normal}##LAST# #{italic}##FIREBRICK#[tempo]#{normal}##LAST#, and would have failed had the #{italic}##FIREBRICK#[noise]#{normal}##LAST# not woken up #{italic}##FIREBRICK#[Father]#{normal}##LAST#.

We were sorry. We were so sorry. Our #{italic}##FIREBRICK#[pod]#{normal}##LAST# was #{italic}##FIREBRICK#[rotten]#{normal}##LAST# and we knew it; we should never have #{italic}##FIREBRICK#[planted it]#{normal}##LAST#. Father forgave us for our #{italic}##FIREBRICK#[spoiled barrel]#{normal}##LAST# and #{italic}##FIREBRICK#[fertilized our garden]#{normal}##LAST#; it was still burning and #{italic}##FIREBRICK#[salted]#{normal}##LAST#, but by #{italic}##FIREBRICK#[breaking out the toolbox]#{normal}##LAST# we could still #{italic}##FIREBRICK#[plant seeds]#{normal}##LAST# on it. We could not #{italic}##FIREBRICK#[bloom]#{normal}##LAST# but we could #{italic}##FIREBRICK#[hold a note, just one note]#{normal}##LAST#. #{italic}##FIREBRICK#[Father]#{normal}##LAST# is still devoting all his will to #{italic}##FIREBRICK#[nailing our garden together]#{normal}##LAST#; it will #{italic}##FIREBRICK#[splinter and wilt]#{normal}##LAST# if he stopped for even a second. Bless the #{italic}##FIREBRICK#[Father]#{normal}##LAST# in his altruism. Bless the #{italic}##FIREBRICK#[Father]#{normal}##LAST#. We are so sorry.

(You unsteadily touch your palm to the next panel. You stand on a charred, bubbling cliff, and see a black, star-dotted expanse above and below you. Your feet are constantly searing; the mages could give you oxygen and convert ambient magic into caloric energy, but they couldn't undo the terrible magical flames that rage on the blown-off continent, or the eternal pyre of your former planet. Nearly everyone you know is dead, and your scryers tell you the home of the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# has suffered only minor damage; all the others you've contacted through portals were blown apart instantly. Your home only survives from the constant effort and concentration of #{italic}##FIREBRICK#[Father]#{normal}##LAST#, who is exerting every bit of magic he can to keep the shattered fragments from spinning off into the void. There is no part of you that does not feel deep regret; you would commit suicide if you did not hope there was a way you could apologize to #{italic}##FIREBRICK#[Father]#{normal}##LAST#, work as tirelessly and selflessly as he is. The regret drains as your hand leaves the panel.)

We asked #{italic}##FIREBRICK#[Father]#{normal}##LAST# what #{italic}##FIREBRICK#[song to sing]#{normal}##LAST# to #{italic}##FIREBRICK#[make him dance]#{normal}##LAST# again. He told us: #{italic}##FIREBRICK#[rattle]#{normal}##LAST# the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# until their every last #{italic}##FIREBRICK#[bead falls out]#{normal}##LAST#. We know our #{italic}##FIREBRICK#[orchestra hall]#{normal}##LAST#, and we will #{italic}##FIREBRICK#[crash the party]#{normal}##LAST#. For our sake, giving us a new #{italic}##FIREBRICK#[garden]#{normal}##LAST# to replace the one the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# or their #{italic}##FIREBRICK#[sprouts]#{normal}##LAST# stole from us. For #{italic}##FIREBRICK#[Father]#{normal}##LAST#'s sake, to let him #{italic}##FIREBRICK#[retire]#{normal}##LAST# again once we're #{italic}##FIREBRICK#[planted]#{normal}##LAST# once more. For everyone's sake, to avenge the #{italic}##FIREBRICK#[spilled beads]#{normal}##LAST# from the #{italic}##FIREBRICK#[brushfire]#{normal}##LAST# and bring #{italic}##FIREBRICK#[silence]#{normal}##LAST# from the #{italic}##FIREBRICK#[egg-weeds]#{normal}##LAST# and any #{italic}##FIREBRICK#[weeds]#{normal}##LAST# they #{italic}##FIREBRICK#[planted]#{normal}##LAST#.

(There is another panel. You touch it briefly. You hate yourself. You hate Eyal. You hate the Sher'Tul. You hate anything and everything around you. You want to destroy it, letting the souls of trillions know that justice has been done. You want to purge not just the Sher'Tul, but anything that has ever been close to them. Elves. Halflings. Orcs. Humans. All could carry their taint. All survived, while everything else that used a portal burned. If there is even a possibility that a single Sher'Tul remains on Eyal, it must be purged in blighted fire. Justice has to be done to Eyal. You remain angry at nothing in particular for ten minutes after you remove your hand.)

#{italic}##FIREBRICK#[Father]#{normal}##LAST# helped our #{italic}##FIREBRICK#[carpenters]#{normal}##LAST# make #{italic}##FIREBRICK#[power tools]#{normal}##LAST#, forms of his blessed #{italic}##FIREBRICK#[fix-it wrenches]#{normal}##LAST# which could transform us to #{italic}##FIREBRICK#[shake harder]#{normal}##LAST#. The #{italic}##FIREBRICK#[peas]#{normal}##LAST# dripped with acid, the #{italic}##FIREBRICK#[beets]#{normal}##LAST# gained tremendous speed, the #{italic}##FIREBRICK#[peppers]#{normal}##LAST# fused their hands with #{italic}##FIREBRICK#[noisy dirt]#{normal}##LAST# to sling it at those who originally #{italic}##FIREBRICK#[made the racket]#{normal}##LAST#. The #{italic}##FIREBRICK#[blooming]#{normal}##LAST# is a little #{italic}##FIREBRICK#[noisy]#{normal}##LAST#, but nothing compared to the #{italic}##FIREBRICK#[egg-weeds' screech]#{normal}##LAST#. We will either #{italic}##FIREBRICK#[be a handyman]#{normal}##LAST# or #{italic}##FIREBRICK#[wilt in the sun]#{normal}##LAST#. Press the next panel to #{italic}##FIREBRICK#[grab a toolbox]#{normal}##LAST#. Be a #{italic}##FIREBRICK#[handyman]#{normal}##LAST#.

(You know all too well what this next panel does, and memories of being chained and bound while a wretchling presses it to your forehead flash through your mind. Despite a fading compulsion, no force in Eyal could convince you to touch the panel.)
]=]
}

newLore{
	id = "ashes-urhrok-demon-history-1",
	category = "Ashes of Urh'Rok",
	name = "history of Mal'Rok (1)",
	lore = [=[First, we were created by our Father, Urh'Rok. Then, many years later, we were in the desert, struggling and fighting each other for the few meager scraps of usable farmland. We do not know anything between these times; our cities, our culture, everything was wiped out by the dust storms. The storms hated us, toyed with us, subsided just long enough for us to raise armies and fight, then raged again the moment peace came. They wanted us to fight. They wanted us to struggle, suffer, die, leaving a few survivors to repopulate, and repeat the process. Green, onyx, red, all brothers who should have been allies, we fought at first because we had to, then because we could, then because we knew it was the only thing that kept the storms entertained.

Eventually, Urh'Rok appeared and told us he had been sealed away, prevented from helping us by people who had been creating the dust storms. Their cities lay hidden among us, shrouded in powerful magic to remain invisible. With a touch, he wiped the storms clean and turned the desert into lush jungle, filled with food. The storms appeared again, weaker this time; Urh'Rok grew furious and shattered the glass cities, reaching into one and pulling out a fistful of sadistic mages. He fed them to us - it was the best, largest feast any of us had eaten in millennia, and it was truly delicious. He did this to all the dust-mages' cities, then declared that we would never have to fear the storms again. We celebrated and worshiped our returned god - thanks to him, we knew where our next meal was coming from, and we had no reason to fight. All of us brethren dropped our weapons and hugged, forgiving each other for the assaults we knew we'd only done from fear. We loved each other, and we loved our god.

Our father began to fret, however. We were supposed to have grown more as species; our squabbling in the desert had stunted our growth, left us behind the curve. He set up a series of competitions and tournaments in all fields of life - magic, combat, negotiation - on a planetary scale. We were used to fighting by now, and now that we knew it was actually accomplishing something, now that we were pleasing an altruistic god, we did not mind it one bit. Those who died did so with smiles on their faces, knowing they'd contributed another data-point to our Father's plan. The weaker members of our many species willingly died off, and we all grew stronger, smarter, and happier as a result. Soon, we were grown enough to organize our own tournaments, and apply the findings to our societies and species; Father said he was pleased with us, and wanted us to determine our own destiny while he slept, recovering from all the work he'd just done. We continued our process of self-improvement - we wanted Father to be proud of us when he woke up.

Then, the Sher'Tul came.
]=]
}

newLore{
	id = "ashes-urhrok-demon-history-2",
	category = "Ashes of Urh'Rok",
	name = "history of Mal'Rok (2)",
	lore = [=[
They arrived in enormous flying fortresses, bristling with weapons and overflowing with magic. They did not directly threaten us, but they met with our leaders and gave us what was either an offer or an ultimatum: let them kill our Father, or kill him ourselves, and be rewarded with technology and magic as grand as theirs.

They were powerful - very powerful. Although their proposal was phrased as a generous offer, we could not help but notice that their fortresses had positioned themselves over our armories and population centers, and none of their fortresses were unarmed. We did not think we could fight them; we considered waking Father for help, but we weren't sure he could fight them either. In desperation, we met and devised a plan: we would seal Urh'Rok away, prevent him from waking up unless disturbed, and then tell the Sher'Tul what we had done. Father would not be hurt or injured by this - he simply wouldn't know what was going on.

We did this, and came to the Sher'Tul. They begrudgingly accepted our treacherous act as a pledge of loyalty to them, and came through with their end of the bargain, giving us knowledge and artifacts beyond our wildest dreams. They built powerful portals all over our planet, allowing us to travel through them not only within our world, but within every world the Sher'Tul had visited before. We saw wonderful new worlds, met and traded with peaceful species from across the universe, enjoyed all kinds of new, alien food, music, magic, and inventions, and generally could not have been happier with how things turned out - if not for the pangs of guilt we felt for betraying our Father. The Sher'Tul eventually stopped visiting us, but we kept trading with new people we met through the portal, and did not notice their absence.

Then everything broke.
]=]
}

newLore{
	id = "ashes-urhrok-demon-history-3",
	category = "Ashes of Urh'Rok",
	name = "history of Mal'Rok (3)",
	lore = [=[Waves of terrible magic burst forth from the portals, which it's now clear were never intended to help us. They were a deadly trap, a ticking time bomb that would go off when the Sher'Tul wanted it to - and it went off with incredible force. Most of the worlds we had once visited were obliterated completely. Ours was not, but I can barely say we were "spared"; our Father's jungles turned to a cursed pyre instantly, burning with flame that could never be extinguished, and our planet cracked apart, whole continents flying into the void. What little land was left obviously couldn't be used for farming. Most of us died instantly, the survivors being those close enough to a skilled mage who could create enough oxygen to breathe, and convert ambient magic into caloric energy for our bodies. Life for the survivors was - is - endless torment, the burning ground constantly searing our feet, and all the beauty we once knew destroyed.

Fortunately, this woke our Father up. We confessed our treachery, but did not beg forgiveness, as we knew what we had done was unforgivable; he disagreed, and to this day is using nearly every shred of his power to keep the shattered fragments of our planet together. We were not satisfied with this fate, our Father suffering and exhausting himself for the sake of our mistakes. We begged him to give us a command, something we could do to help his situation, or at least make him happier about it.

His command: End the Sher'Tul. End their creations. Never let anything be hurt by Eyal again.

We have taken his words to heart. Our mages have devised new magic from old inspiration, alteration spells to make us warlike and brutal once more - but with our ascended minds and honed bodies, we shall be a force of destruction far greater than the dust-storms ever were. Our green bretheren underwent a process to make their skin drip with acid; not to be outdone, our onyx brethren grew faster and stronger, with a birth-rate high enough to overwhelm whatever Sher'Tul or Sher'Tul-made monsters lay on Eyal. The red ones proclaimed they now existed only to destroy, and fused bits of the burnt earth to their hands, leaving them unable to do anything but sear Eyal with its own fires. The finished results of these alterations have taken up residence on our largest drifting continent, the one drawing ever closer to Eyal.

Once this continent arrives, we shall take revenge on Eyal. Not just for our own sakes, our planet ravaged by their treachery, with a pristine one waiting as our prize. Not just for our Father's sake, condemned to an eternity of suffering for trusting his children too much. But for *everyone's* sake, the untold trillions of souls on planets less fortunate than ours, torn apart in a fiery instant. The Sher'Tul shall never hurt anyone again; we shall make sure of it by cleansing Eyal in blighted fire, and any survivors will be taken back to our planet and chained to the burning earth, kept alive so they can forever feel the flames they created consuming their flesh. Their eternal torture will still not be justice, as they shall feel only a tiny portion of the suffering they inflicted... but it's a start.
]=]
}

newLore{
	id = "ashes-urhrok-training-recall1",
	category = "Ashes of Urh'Rok",
	name = "Lost Memories (1)",
	template = true, always_pop = true,
	lore = [=[#{italic}#You clutch your head.  Entering this next floor, memories of your imprisonment flood back to you...#{normal}#

"All right, bring in the next one," says the ruby-skinned leader.  A few small, green and black things mop up the pile of muck that used to be a dwarf, and you move to the front of the line and stand where he used to be.  On the other side of the room, another <?=player.descriptor.subrace?> stands on an identical platform.  This is exciting - you've been specially chosen as a test subject!  You hope you help them find something effective AND agonizing, and look forward to the pain to come.  A green imp, a little more mutated and knobbly than the rest you've seen, stands on your side of the room and grins at you with anticipation;  on the other side, a more normal imp approaches your counterpart.  "Control group...  go."  The normal wretchling leaps on the <?=player.descriptor.subrace?>'s face, clutching it tight as a torrent of acid oozes from its skin, then lets go; the red imp looks at his melting flesh, jots down some notes, then mutters "and pain blocks off..."  The <?=player.descriptor.subrace?>'s smile vanishes, and he clutches his face, then lets out a howling scream, collapses, and begins writhing on the floor.  The red imp looks down again, gives a bored sigh, and takes some more notes.  "That's enough, pain blocks on, patch him up."  The <?=player.descriptor.subrace?> stops moving, stands up, and smiles again, the acid continuing to eat away at his flesh until a pipe in the floor douses him with some sort of chemical.  Another red imp mutters something and waves his hands before taking his hand and leading him off, and you see his horrible wounds gradually healing.

"Experimental group...  go."  With speed you can't even process until it's already on you, the mutant wretchling leaps onto your face.  You feel no pain as its acid leaks over your torso, although you do feel an odd sensation of your skin layers beginning to dissolve.  The imp leaps off again; apparently it missed your eyes, because you can see the red imp looking somewhat disappointed.  "Structural damage subpar...  okay, pain blocks off."  You know you're not supposed to scream during this next part.

You scream.  You scream harder than you have in your life, to the point where you think you might be tearing your vocal cords apart.  The pain is stronger not just than any pain you've ever felt, but any sensation you've ever felt.  You fall to the ground and claw at your skin, tearing off bits of it as you try to get the acid off.  You struggle and flail, instinctively grabbing at anything that could help you even though you know there's nothing in reach that could.

"All right, nice!  Pain blocks on!"  And just like that, the pain vanishes; your skin still bubbles, but that horrible pain is gone, and even your throat isn't sore.  "Clean him and patch him up.  Pain-amplifying qualities...  significant improvement...  recommend breeding with low-pain high-corrosion specimens."  A shower of unidentifiable goo washes over you, and your skin stops bubbling; your handler takes your arm and leads you away, muttering a healing spell under his breath, and your scars slowly start to fade into smooth skin once again.  You hope they aren't too harsh on you for screaming, but the way that imp spoke...  you must've helped them learn something!  You grin from ear to ear as you leave the room, hearing the red imp yell "Next!" as the door closes behind you.

#{italic}#You shudder.#{normal}#
]=]
}

newLore{
	id = "ashes-urhrok-training-recall2",
	category = "Ashes of Urh'Rok",
	name = "Lost Memories (2)",
	template = true, always_pop = true,
	lore = [=[#{italic}#More memories rush into your mind...#{normal}#

"It's your lucky day, <?=player.name?>," your handler says as he leads you to a large, glowing crystal.  "You're too cooperative to stay in testing any longer.  Today, you're getting promoted to research assistant!"  You're nearly beside yourself with joy!  "Now, we'll need to do a short little process first.  Fireproofing wards here, loyalty reinforcement there, standard-issue alteration, but mostly just linking your consciousness to this," he says, pointing to the crystal.  "With this thing, everything you see, hear, smell, taste, or feel gets fed directly into this little ol' beauty.  Not just that, either - whereever you go, and whatever you think, we'll have it saved for future reference."  You're going to help them learn so much!  "Just step on the plate here, and hold your arms like this so I can get the bindings in place..."

That crystal.  That crystal is how they're keeping track of you, and it has most of what you helped them discover trapped within it.  If you break it, you'll be able to escape their notice for the first time since you arrived here, allowing you to get away without them finding you again, and as an added bonus you'll undo most of what you helped them accomplish.  You need to destroy it, then flee for your life!]=]
}


-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- Re-abduction
-------------------------------------------------------------------------
-------------------------------------------------------------------------
newLore{
	id = "ashes-urhrok-tactics-doombringer",
	category = "Ashes of Urh'Rok",
	name = "orbital base: battle plan (doombringer)",
	template = true,
	lore = [=[Engagement Briefing on <?=player.name?>:

This slippery little <?=player.descriptor.subrace?> has proven to be a thorn in our side so far.  We've reinforced our wards to better protect against the sort of fluke meteor impact that enabled <?=player:his_her()?> escape, but the crystal <?=player:he_she()?> smashed on <?=player:his_her()?> way out prevented us from keeping track of <?=player:his_her()?> location directly.  No matter - the brands and marks we've imbued <?=player:him_her()?> with have nonetheless allowed us to monitor magical energy signals affecting <?=player:him_her()?>, and our scryers have noted that there appears to be a particular pattern that teleports <?=player:him_her()?>, possibly of Sher'Tul origin.  We've sent out a signal of our own to intercept this, and redirect it to our platform, where <?=player:he_she()?> will be safely secured, punished for <?=player:his_her()?> disobedience, then once again exposed to a Tablet of Enlightenment to regain <?=player:his_her()?> servitude.

That said, given that <?=player:he_she()?> has increased dramatically in power since <?=player:his_her()?> escape, it is crucial that we keep proper tactics in mind.  Having been exposed to our alteration magic, <?=player:he_she()?> is very formidable in direct melee combat, and in the event that we cannot procure proper warding against this magic before <?=player:his_her()?> arrival, <?=player:he_she()?> can cause significant damage if not properly handled.  Under no circumstances should we let <?=player:him_her()?> run rampant in our back line; furthermore, if we simply try to lure <?=player:him_her()?> into a narrow corridor, we will not be able to bring enough firepower to bear before <?=player:he_she()?> can break through our obstructions.  Instead, use a small flanking squad backed up by a maulotaur (or whatever high-power direct combatant we can get authorization to deploy) to force <?=player:him_her()?> into an open area, where we'll have caster artillery, protected by a front-line of wretchlings backed by quasits.  We may lose these front-line soldiers, but in the time it takes <?=player:him_her()?> to slash <?=player:his_her()?> way through them, our spells should be able to reduce <?=player:him_her()?> to a flayed, quivering wreck.

Above all else, remember: despite <?=player:his_her()?> brute strength, this is a pitiful, inferior Eyalite who lucked <?=player:his_her()?> way into obtaining some of our superior power.  <?=player:he_she():capitalize()?> does not know how to use it properly, and does not have the countless years of experience with it that we do.  We have numbers, familiarity, tactics, and the blessing of Urh'Rok himself.  Treat this like a drill; if we stay calm and focused, it is unlikely we will see any casualties.
]=]
}

newLore{
	id = "ashes-urhrok-tactics-demonologist",
	category = "Ashes of Urh'Rok",
	name = "orbital base: battle plan (demonologist)",
	template = true,
	lore = [=[Engagement Briefing on <?=player.name?>:

This slippery little <?=player.descriptor.subrace?> has proven to be a thorn in our side so far.  We've reinforced our wards to better protect against the sort of fluke meteor impact that enabled <?=player:his_her()?> escape, but the crystal <?=player:he_she()?> smashed on <?=player:his_her()?> way out prevented us from keeping track of <?=player:his_her()?> location directly.  No matter - the brands and marks we've imbued <?=player:him_her()?> with have nonetheless allowed us to monitor magical energy signals affecting <?=player:him_her()?>, and our scryers have noted that there appears to be a particular pattern that teleports <?=player:him_her()?>, possibly of Sher'Tul origin.  We've sent out a signal of our own to intercept this, and redirect it to our platform, where <?=player:he_she()?> will be safely secured, punished for <?=player:his_her()?> disobedience, then once again exposed to a Tablet of Enlightenment to regain <?=player:his_her()?> servitude.

That said, given that <?=player:he_she()?> has increased dramatically in power since <?=player:his_her()?> escape, it is crucial that we keep proper tactics in mind.  We've heard disturbing reports that some of our species have been spotted fighting alongside <?=player:him_her()?>; we can assume that <?=player:he_she()?> is using a twisted version of the Tablet's power to enslave some of our forces.  Much of <?=player:his_her()?> combat potential comes from these thralls, rather than <?=player:his_her()?> own abilities.  Accordingly, there are three things to keep in mind:

-Prioritize the Eyalite, rather than <?=player:his_her()?> thralls.  We do not yet have a concrete understanding of how <?=player:he_she()?> is controlling our allies, but it seems likely that the mental hold will break once <?=player:he_she()?>'s incapacitated; if <?=player:he_she()?> has managed to take control of a Champion of Urh'Rok or similarly powerful agent, we should focus our firepower on <?=player:him_her()?> instead.  That said, neutralizing <?=player:him_her()?> is more important than saving the time and effort of producing such a creature; in particular, don't worry about catching a few enthralled imps in the crossfire.  No matter what <?=player:he_she()?>'s using, we can make more of it.

-Be ready for anything.  We've never needed to plan out what to do against our own powers, and we have such a diverse set of species that <?=player:he_she()?> could throw all kinds of magic or martial prowess against us.  This might sound hopeless, but remember: you've seen all this in action before, these powers being used alongside yours in training and in combat.  Whatever you've seen your comrades do, expect to see it from <?=player:him_her()?>.

-Do not assume that the onslaught will stop if all of <?=player:his_her()?> thralls are dead.  <?=player:he_she():capitalize()?> has managed to directly imbue <?=player:his_her_self()?> with some of our magic, and may be capable of using our fireballs, acidic bursts, and so forth.  Silencing magic will be helpful here, as will spells that can drain <?=player:his_her()?> energy; furthermore, ripping away <?=player:his_her()?> shield will make <?=player:him_her()?> especially vulnerable to our claws and axes.

Above all else, remember: despite <?=player:his_her()?> enthralled minions, this is a pitiful, inferior Eyalite who lucked <?=player:his_her()?> way into obtaining some of our superior power.  <?=player:he_she():capitalize()?> does not know how to use it properly, and does not have the countless years of experience with it that we do.  We have numbers, familiarity, tactics, and the blessing of Urh'Rok himself.  Treat this like a drill; if we stay calm and focused, it is unlikely we will see any casualties.
]=]
}

newLore{
	id = "ashes-urhrok-tactics-doomelf",
	category = "Ashes of Urh'Rok",
	name = "orbital base: battle plan (doomelf)",
	template = true,
	lore = [=[Engagement Briefing on <?=player.name?>:

This slippery little elf has proven to be a thorn in our side so far.  We've reinforced our wards to better protect against the sort of fluke meteor impact that enabled <?=player:his_her()?> escape, but the crystal <?=player:he_she()?> smashed on <?=player:his_her()?> way out prevented us from keeping track of <?=player:his_her()?> location directly.  No matter - the brands and marks we've imbued <?=player:him_her()?> with have nonetheless allowed us to monitor magical energy signals affecting <?=player:him_her()?>, and our scryers have noted that there appears to be a particular pattern that teleports <?=player:him_her()?>, possibly of Sher'Tul origin.  We've sent out a signal of our own to intercept this, and redirect it to our platform, where <?=player:he_she()?> will be safely secured, punished for <?=player:his_her()?> disobedience, then once again exposed to a Tablet of Enlightenment to regain <?=player:his_her()?> servitude.

That said, given that <?=player:he_she()?> has increased dramatically in power since <?=player:his_her()?> escape, it is crucial that we keep proper tactics in mind.  Our standard alterations have synergized with this Shalore's natural reactive magic, giving <?=player:him_her()?> short-range teleportation to rival Draebor and creating a frustratingly evasive target to hit.  Even <?=player:his_her()?> internal organs are affected, and will slide out of the way in anticipation of a blow that would strike an otherwise-vital area.  Compared to standard Shalore, <?=player:he_she()?> cannot directly turn invisible, but seems to have adopted a form of dúathedlen magic to remain out of sight all the same; if the requisition order for light-based wards goes through, this and the blasts of darkness this form grants should both be a non-issue.  Finally, use of more advanced combat maneuvers will be somewhat impeded by <?=player:his_her()?> ability to interfere with our concentration, and the resilience alterations we gave <?=player:him_her()?> will make <?=player:him_her()?> shrug off poisons, flames, and the like much quicker than usual.

What does all this mean?  Just get <?=player:him_her()?> wounded, wait for <?=player:him_her()?> to try to teleport away, then get <?=player:him_her()?> in a corner and beat <?=player:him_her()?> until <?=player:he_she()?> stops moving.  It's really that simple.  Just work that into our standard methods of dealing with <?=string.a_an(player.descriptor.subclass:lower())?>, remember not to break ranks if <?=player:he_she()?> vanishes into darkness, and we'll have this mess cleaned up in no time.

Above all else, remember: despite <?=player:his_her()?> enhancements, this is a pitiful, inferior Eyalite who lucked <?=player:his_her()?> way into obtaining some of our superior power.  <?=player:he_she():capitalize()?> does not know how to use it properly, and does not have the countless years of experience with it that we do.  We have numbers, familiarity, tactics, and the blessing of Urh'Rok himself.  Treat this like a drill; if we stay calm and focused, it is unlikely we will see any casualties.

]=]
}

newLore{
	id = "ashes-urhrok-tactics-failed",
	category = "Ashes of Urh'Rok",
	name = "orbital base: battle info",
	template = true, bloodstains = 5,
	on_learn = function(player) player:setQuestStatus("ashes-urhrok+re-abducted", engine.Quest.COMPLETED, "ambush") end,
	lore = [=[#{italic}#This note is splattered with the blood of the demon who was carrying it.#{normal}#

#{bold}#URGENT:#{normal}#

Operation to secure <?=player.name?> failure.  Primary defense force routed, secondary team taking heavy casualties.  All is lost.  Highest priority is now containing <?=player.name?> to prevent further damage.  Blow all connectors, break platform off the continent and dispel oxygenation wards befo--

#{italic}#The last O trails off, a line leading from it to the end of the page like the pen was rapidly jerked away.  You must have interrupted this demon's writing.#{normal}#
]=]
}

newLore{
	id = "ashes-urhrok-tactics-failed-badass",
	category = "Ashes of Urh'Rok",
	name = "orbital base: battle info with #{bold}#a badass#{normal}#",
	template = true, bloodstains = 5,
	on_learn = function(player) player:setQuestStatus("ashes-urhrok+re-abducted", engine.Quest.COMPLETED, "ambush") end,
	lore = [=[#{italic}#This note is stained with what appear to be motorcycle tire-tracks.#{normal}#

#{bold}#URGENT:#{normal}#

Operation to secure <?=player.name?> failure.  Primary defense force routed by target's overwhelming badassery, secondary team presumed dead (reports inaudible over sound of face-melting guitar solos).  All is lost.  Totally worth it.  Highest priority is now isolating <?=player.name?>, building a stadium around <?=player:him_her()?>, and selling tickets to spectacle of badassery.  Blow all connectors, break platform off the continent, prepare pyrotechnics, and set up spotlights and speaker systems befo--

#{italic}#The last O trails off, a line leading from it to the end of the page like the pen was rapidly jerked away, then leads to a doodle depicting you, wielding a double-bladed katana and fighting a giant construct labelled "Ninja Atamathon."  Your badassery must have interrupted this demon's writing.#{normal}#
]=]
}


newLore{
	id = "ashes-urhrok-mural-painting-1",
	category = "Ashes of Urh'Rok",
	name = "first mural painting", always_pop = true,
	image = "malrok_lore_01.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}

newLore{
	id = "ashes-urhrok-mural-painting-2",
	category = "Ashes of Urh'Rok",
	name = "second mural painting", always_pop = true,
	image = "malrok_lore_02.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}

newLore{
	id = "ashes-urhrok-mural-painting-3",
	category = "Ashes of Urh'Rok",
	name = "third mural painting", always_pop = true,
	image = "malrok_lore_03.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}

newLore{
	id = "ashes-urhrok-mural-painting-4",
	category = "Ashes of Urh'Rok",
	name = "fourth mural painting", always_pop = true,
	image = "malrok_lore_04.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}

newLore{
	id = "ashes-urhrok-mural-painting-5",
	category = "Ashes of Urh'Rok",
	name = "fifth mural painting", always_pop = true,
	image = "malrok_lore_05.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}

newLore{
	id = "ashes-urhrok-mural-painting-6",
	category = "Ashes of Urh'Rok",
	name = "sixth mural painting", always_pop = true,
	image = "malrok_lore_06.png",
	lore = [[#{italic}#"To honor the Masters" - A thrall#{normal}#]],
}


-------------------------------------------------------------------------
-------------------------------------------------------------------------
-- Statues lore
-------------------------------------------------------------------------
-------------------------------------------------------------------------

-------------------------------------------------------------------------
-- Minor demons
-------------------------------------------------------------------------
newLore{
	id = "ashes-urhrok-demon-statue-wretchling",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: wretchling",
	lore = [=[Behold, the humble wretchling, a testament to our devotion to our Father!  These children of emerald were among the first to alter themselves for our quest for vengeance, and managed an astounding degree of success.  With their bursts of blinding speed, overwhelming numbers, and skin that can release prodigious amounts of corrosive fluid, wretchlings can storm onto the battlefield and pounce on our foes one-by-one, dissolving the ground they walk on while leaving them helpless against our onslaught.  Wretchlings will readily give their lives in combat, serving as obstructions and shields while their acid and our casters do their work, and still remain the most populous of our species thanks to their incredible birth rates.  It is rare to see a wretchling survive to maturity, but make no mistake - every wretchling that fights does an incredible service to our cause.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-fire_imp",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: fire imp",
	lore = [=[If the Wretchling speaks to our worship, the Fire Imp speaks to our commitment and loyalty.  When a child of ruby goes out onto the battlefield, she fuses some of the Eyal-scarred earth from our planet to her hands, having perfected a type of magic that uses the raging magic contained within to blast our foes with the fires they've caused.  Aside from this means of appropriate justice being pleasing to Urh'Rok (as he showed when dealing with the dust-mages), it shows how dedicated we are to our cause: without hands, there's very little a Fire Imp would be able to do if she deserted or became demoralized.  Fighting and destroying is what we live for, and what better way to show it than making onesself unable to do anything but fight and destroy?  Although the bulk of the ruby species do not pursue this path, instead focusing on magical research and furthering our alteration projects, the example that the Fire Imp sets is a shining standard of commitment for all of Urh'Rok's children.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-water_imp",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: water imp",
	lore = [=[Though they retain use of their hands, this altered offshoot of the Fire Imp has made a much more powerful sacrifice: the ability to breathe air.  Most of the dominant species of Eyal reside above the water, making its oceans and lakes a prime location for carrying out covert operations, conducting experiments too dangerous to perform on our own soil, and preparing portals for a full-scale invasion.  As our scouts and servants beneath the seas, water imps forego the fire-slinging abilities shared by their brethren, instead focusing on ice-magic that is similarly effective underwater.  Like a wretchling, a Water Imp does not expect to live to see peacetime, and thus has no need to breathe above the surface.  Remember to pay tribute to the Water Imp whenever you can; since they do not fight alongside our land-based forces, it's all too easy to forget the selfless sacrifices they've made, and their enormous contributions in gathering intelligence and setting up remote bases.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-quasit",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: quasit",
	lore = [=[Clever and tough, the engineers and warriors of our kind, making armor for our forces and holding the front lines against the hordes of Eyal.  While the children of ruby study new magical spells for our arsenal, and the children of emerald study ways to make our own bodies deadlier, the children of onyx focus on making new constructs from scratch, lashing flesh, magic, and steel together into towering creations that strike fear into Eyal.  Those who fight on the front lines have been created to do so rather than born, churned out in a semi-mature state by factories with Forge-Giant-produced armor bolted onto their skin at "birth."  Though they are mostly flesh, the warrior onyx known as Quasits are very much machines, made with bolstered muscles without losing the clever minds they come from.  As eager as they are brilliant, Quasits are well-disciplined and capable in combat, and their armor allows them to easily take blows that would devastate a Wretchling or Fire Imp.  Devotion will get us far on its own, but the Quasit shows how much more we can do when we have fervor and patience working hand-in-hand.]=]
}

-------------------------------------------------------------------------
-- Major demons
-------------------------------------------------------------------------

newLore{
	id = "ashes-urhrok-demon-statue-wretch_titan",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: wretch titan",
	lore = [=[The modified children of emerald, known as the Wretchlings, willingly accept their role as the arrows in Urh'Rok's quiver, and most only live to see a couple of engagements before giving their lives in battle.  Once in a great while, though, one will stand toe-to-toe with the enemy and repeatedly come out on top.  These outstanding fighters, chosen by fate and their own talent, are recalled, then put through a series of tests to ensure that their survival was not due to luck alone.  Roughly 70% of these are then assigned to breeding duties, ensuring that the Wretchling bloodline gets ever stronger as it is forged in the fires of combat; the rest, whether due to sterility, consuming too much resources to sustain their brood, or simply insisting on staying in the fights for which they were created, are nurtured to maturity and once again let loose on the battlefield.  If wretchlings are our arrows, wretch titans are our trebuchet boulders, causing a tremendous amount of damage to the enemy line with their incredible strength and the geysers of acid spurting from their flesh.  Although no less aggressive than their younger counterparts, wretch titans generally have a much higher survival rate, due to not only their formidable power and size, but the sheer terror they cause when charging at the enemy - few Eyalites would stand and fight against such a foe, particularly when it means standing in a rapidly-growing pool of acid.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-dolleg",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: dolleg",
	lore = [=[A walking monument to times of prosperity, the dolleg was once a beast of burden, carrying loads of trade goods through the Sher'Tul portals.  Reliable, friendly, and rather intelligent for a beast, dollegs were often taken in as beloved pets as well - their joyous chirps when seeing their master get home could brighten up anyone's day, and despite their large size they were gentle enough to play with our young.  Their kind temperament and dutiful labor were the pride of our breeding practices, and two-thirds of our population either owned, lived in a home with, or worked with a dolleg.  In the wake of Mal'Rok's destruction, the children of emerald developed an effective process to convert these companions into beasts of war, covered in acidic spines and thick plating, and loyally tearing through our enemies with incredible force.  Unfortunately, their friendly demeanor was lost in order to make them merciless in combat; of all the sacrifices we've had to make for our war, it might be the loss of our gentle companions that troubles us the most.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-uruivellas",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: uruivellas",
	lore = [=[The minotaur is one of Eyal's more interesting creatures, and a good example of the devious designs the Sher'Tul had in mind while creating or altering Eyal's races.  Its instincts draw it toward narrow corridors, twisted passages, magical artifacts, and surges of magical energy, resulting in horned beast-men frequently blundering their way into our bases and encampments.  They also seem to soak up empowering magic very readily, and alter their forms accordingly - a typical minotaur is no match for our forces, but occasionally blight will mutate one into an extremely dangerous horror.  Said blighted forms are too unstable for use among our ranks, but with some effort by the children of emerald and ruby, we can give one the gifts of massively increased strength and the ability to unleash waves of flame on our enemies.  While we currently need to keep most of them enthralled to ensure their loyalty, we've recently begun breeding minotaurs on our continent so we can train them from birth to know our cause of righteous revenge - and already some wandering minotaurs accept our cause and our blessings willingly!  It seems the natives of Eyal are no kinder to their own brethren than they are to us.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-daelach",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: daelach",
	lore = [=[Any one of us who's read up on our history will remember the story of the wicked dust-mages, tormenting us with sentient storms from the safety of their hidden cities.  Although we were tempted at the time to erase all vestiges of their knowledge and culture like they did to us, we knew their magic could come in handy someday, and when their cities lay in ruin, we plundered their libraries for their writings, then dutifully copied down the practical details from these while stripping out the rest.  Once the portals were unleashed on us, the children of ruby (after some controversy) managed to use their old spells to create a new kind of storm, one of swirling flames and coals rather than dust and sand.  Obedient and cheap (if hazardous) to make, these living spells will torment and raze Eyal with their firey onslaught, like their predecessors once did to Mal'Rok.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-champion_of_urh_rok",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: champion of Urh'Rok",
	lore = [=[The Divine Tournament of Combat is the most straightforward of our competitions for the spectator, but those competing have a huge variety of possible divisions to enter.  Most are based on the maximum amount of energy consumed by their entrants since (and including) birth; others include those set in an open field for direct combat, or a difficult-to-navigate forest of pillars to properly evaluate those who use hit-and-run tactics or excel at setting up or detecting ambushes.  In the high-energy divisions, those competing are typically not born in the conventional manner, usually being constructs made by a team performing a collaborative effort.  The constructs we now call Champions of Urh'Rok have utterly devastated most of the high-energy open-field divisions, while performing adequately in the less-direct ones, making them a solid fit for production and deployment in the invasion.  Their development team has earned a place of honor for their ingenious methods of creating such incredible strength with a sustainable amount of energy-input, and once mass-production is in order, these gigantic creatures will become the backbone of our military.  Once they arrive on the surface, Eyal will experience a few fleeting moments of terror before their utter annihilation.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-forge_giant",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: forge giant",
	lore = [=[The power of Urh'Rok cannot be overstated, except by claiming it to be infinite.  Most of his strength and will are occupied at the moment, keeping our shattered home from splintering off into the void; as such, he cannot spend time or effort making equipment for our army.  The children of onyx recognized this, and worked on a way to maximize the amount of benefit they could get from a small portion of his power; Urh'Rok was pleased by their idea, and granted their request in full, giving them a handful of enormous hammers, each one glowing with his magic.  These were then given to modified variants of the Champion of Urh'Rok template, built for raw strength at the expense of speed and energy-efficient creation, and now they work tirelessly, heating raw metal with their magic until it is workable, then pounding it into their shape, automatically imbuing the resulting armor and weaponry with Urh'Rok's blessing.  Thanks to an assortment of detachable heads for these hammers, every single swing produces several pieces of usable equipment.  The constant exposure to the power of Urh'Rok has made these creatures almost absurdly formidable, but as useful as they would be on the front lines, they are even more useful bolstering the rest of our forces with blessed equipment; that said, should our scouting parties encounter a problem that requires drastic and immediate intervention, sending a Forge-Giant down is a reliable emergency option, and would immediately clear up any combat-related difficulties should the situation call for it.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-thaurhereg",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: thaurhereg",
	lore = [=[Thanks to numerous contacts we have on Eyal's surface, ranging from easily-duped natives to our own scouting teams, we've managed to gain a few captive Eyalites.  These prisoners are useful for a variety of tasks, including manual labor, magical research, stress relief, and developing new methods of torture (those last two often being one in the same).  We try to preserve these temporarily-valuable subjects for as long as we can, but invariably, an experiment goes wrong or someone uses too much force, and the captive ends up mortally wounded.  Rather than let these world-breakers escape their eternal fate by simply dying, we put their bodies and life-essence to use, combining several fallen Eyalites into a creature held together by their collective rage and suffering.  You'd think this would be a bad idea to have walking around our base of operations, but as it turns out, it just takes a few simple enchantments to redirect their vengeful instincts towards their former brethren, making them fearsome and sadistic in combat.  Their rampages against their "tormentors" are simply hilarious!]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-duathedlen",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: dúathedlen",
	lore = [=[#{italic}#This plaque is mostly covered in shifting shadows.  You can only make out a little bit of the text.#{normal}#

#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#heregs are not the only way we recycle #927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#arness their fear and suspici#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#outs.  Cautious and yet sadistic, these assassins #927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#markably effective in indirect combat, setting ambus#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#justice.  Additionally, the shadows they produce #927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#spionage, scouting, and #927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#king them a val#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST#tion to our intel-gathering camps. Redee#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST# data they contribute on#927e64#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#LAST# paving the way for our invasion.

#{italic}#As you reach the end, the text goes completely black, and a new message forms.#{normal}#

#{bold}#WE SEE YOU.#{normal}#]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-ruin_banshee",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Ruin Banshee",
	lore = [=[The onslaught of the Sher'Tul portals never truly stopped.  Magic still pours from them, threatening to do even more damage to our home; it would be completely destroyed by now, if not for our Father.  Part of his work to keep Mal'Rok structurally intact is to blow great gusts across the devastated land, forcing the ravenous flames back into the portal network from whence they came.  It would seem, though, that the flames took souvenirs with them; our scouting parties have noted that Sher'Tul portals on Eyal, even those which have been completely deactivated, will occasionally emit a shade of one of our fallen citizens, imbued by some of Urh'Rok's power, smelling of Mal'Rok's ashes, and warped to insanity by its transit through the unstable rifts.  While this is a troubling revalation of the true horror of the Sher'Tul weapons, telling us that even now our fallen cannot rest in peace, the fact that they are arriving on Eyal in defiance of the shield is some consolation, as it means that those most wronged by the betrayal can claim their revenge personally.]=]
}

-------------------------------------------------------------------------
-- Unique demons
-------------------------------------------------------------------------
newLore{
	id = "ashes-urhrok-demon-statue-draebor_the_imp",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Draebor, the Imp",
	lore = [=[Teleportation is one of the most crucial areas of magical research to our cause of revenge; until we break the Sher'Tul-made shield surrounding Eyal, it will remain our only means of reaching the surface.  One of our leading scholars, a child of onyx known as Draebor, has perfected short-range teleportation and has been studying methods to work his skills into a mass-producible artifact to grant this ability to all of our troops.  He's kept his work under wraps as of late, but rumor has it that he's been reverse-engineering the Sher'Tul portals, letting our invasion get through via their own weapons.  Whatever he's up to, keep an eye out - big things are just around the corner, courtesy of his dedicated research!]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-shasshhiy_kaish",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Shasshhiy'Kaish",
	lore = [=[Once a naturalist and explorer, this scholar frequently made trips to Eyal in the period before Mal'Rok's destruction.  Her journals about a wide assortment of curious species living in the shadow of the Sher'Tul were a delightful read for our citizens, and she had a genuine love for these pitiable, uncivilized creatures.  She, along with two of her companions, were trapped on Eyal when the portal network was destroyed; for a long time, she was feared dead, or worse, turned traitor and working with the natives against her old home.  In any case, it was assumed she would have expired of old age by the time we arrived in orbit around the planet.  Once we got there, though, something curious happened: by magic we still haven't been able to reverse-engineer, a handful of Eyalites dressed in strange robes appeared on our continent, proclaiming devotion to Shasshhiy'Kaish and wishing to be subjected to our experiments.  Ever since then, batches of these willing captives have been delivered with great regularity.  Sadly, they have not been as great a boon to our research as this would sound - all of them appear with nearly every shred of their essence drained, leaving them on the edge of death, and that's not counting the frequent cases of internal bleeding and the rare occasion of them appearing with a rewired nervous system that perceives pain as pleasure, frustrating our attempts to create better methods of punishment.  Nonetheless, they are both cooperative and plentiful, and have been quite helpful.  We cannot be sure that Shasshhiy'Kaish herself is still alive, but if she is, we can be sure her allegiances are with our cause.

#{italic}#A short message is etched below the main text.#{normal}#

Cute.  I'll let it stay.  
-S.
]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-walrog",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Walrog",
	lore = [=[#{italic}#The message at the base of this statue has been scratched out, and a new one has been carved in its place.#{normal}#

Walrog, if you're reading this: We're still alive, but keep up the good work.
-S.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-kryl_feijan",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Kryl-Feijan",
	lore = [=[#{italic}#The text at the base of this statue has been scratched out.  A note is attached in its place.#{normal}#

Hello, Eyalite.  The text here wouldn't have meant a whole lot to you; a whole lot of blathering about his accomplishments as a naturalist, and his mysterious disappearance.  Let me tell you what you need to know instead.

Kryl-Feijan was my lover, and along with a friend by the name of Walrog we came to Eyal out of curiosity and thirst for knowledge.  It was an enlightening hobby, and the reports we made of your many, primitive species were read all across our world.  Do not think you deserved this attention; you were not special in any way aside from your inferiority.  How could the planet of the powerful, intelligent Sher'Tul create such savages that had barely escaped feudalism?  Your sins were endearing, and your failures amusing.  And it was knowing this, along with the curious absence of the Sher'Tul, that led us to go out and investigate when a wounded child of onyx came through our portal, deactivated it, and told us of horrible destruction unleashed on Mal'Rok by Eyal.  We knew you were not capable of such feats, so we had to learn the answers for ourselves; Kryl-Feijan and I adopted our usual disguises as human mages, while Walrog arranged to scout the seas for anomalies, then meet us back after a few days.

When we emerged from our underground lodge, we were surprised to see firestorms (although not nearly so fierce) raging across Eyal as well.  What surprised us more, though, was an enraged horde of peasants, provoked by our unfortunate choice of disguises - in your ignorance, you chose to blame spellcasters for the disaster.  We tried to escape, but the mob swarmed us from all directions, and were soon upon us.

Soon, I was tied up and restrained, while they gloated and made threats I couldn't hear over the din of the crowd.  I could have fought back, but I kept telling myself only to lash out once I was sure my life was in danger, reassuring myself that the people of Eyal who were once so fascinating to me surely couldn't be aware of what they were doing.  Judging from the geysers of flame bursting above my head, my lover was not so patient; when the blasts stopped and the crowd started to clear away, I saw why he'd fought so fiercely.  His injuries were horrific, clearly done to make him suffer rather than incapacitate him, and he was on the edge of death.  In a moment of desperation, I muttered a spell to myself to understand what was going through their minds, what could possibly justify such treatment.  That's when I learned what they'd done to him, and what they were planning with me, but neither was as awful as the unthinking hate motivating it...  there are both too many words for it and not enough.  Horrible, barbaric, sadistic, all are accurate but none fully convey the evil of it.  That moment is when I learned the true savagery of Eyal, and realized the fate all Eyalites deserve.  That moment is when my patience broke.

There is a type of magic on Mal'Rok that will allow one to transfer his or her life-essence to another, prolonging the latter's lifespan at the expense of the former.  Voluntary donations to honored figures are popular, but the reverse - draining another to help one's self - was considered the gravest of sins, a statement that you considered your life to be worth more than another's, which is a decision nobody should be allowed to make when they have a vested interest in it.  Walrog had taught this forbidden spell to me, and only now did I use it, withering the horde all at once and forcing their lives into Kryl-Feijan.  The survivors, too weak to stand up against me, suffered greatly, playthings of my brief and furious revenge.  Unfortunately, even all the life I'd drained was not quite enough to restore my lover to health; all it could do was keep him in limbo, in incredible pain and unable to act, but still alive.

I took his surviving essence and fled to safety, then started picking the natives off one by one, extending my lifespan and getting ever closer to restoring him to health.  I can only assume Walrog is doing the same, preying on sailors first and then naga; I've lost contact with him, but the stories of terrors from the sea tell me he's still alive.  Keeping Kryl-Feijan in limbo consumes a great deal of energy, though, and soon lone travellers were not enough to keep him stable; I needed others to work for me, gathering victims and willingly sacrificing themselves once they'd outlived their usefulness.  And that is when I learned of the approach of the Fearscape, and came up with an offer I could make to the residents of Eyal.

When the legions of Urh'Rok manage to get an invasion force to Eyal's surface - not if, but when - you will all suffer, more than you can possibly imagine.  Many of you will die; some will not be so lucky, and will be an ever-living target of their rage, tortured until the end of time.  Their reasons are somewhat inaccurate, but make no mistake: you deserve the fate they have lined up for you.  Even if I wanted to, neither I nor anything else in the universe could stop their invasion, save the word of Urh'Rok himself - and that seems rather unlikely.  If you assist me and follow my orders to my satisfaction, I can guarantee you two things.  One, your inevitable agonizing fate WILL end in death, after a maximum of a couple of weeks; even the armies of Mal'Rok can't undo the effects of having your life-essence drained.  And two, before you feel the pain, you will feel nearly-equal pleasure.  With my magical skills, I can alter myself into any form, create all manner of illusions, and manipulate all your senses to your liking.  Your wildest, most unrealistic fantasies will become true; the time before the pain starts will be so enjoyable as to eclipse every moment of your pathetic lives that came before.  And if you think yourself above such hedonism, consider the psionically-gifted servitors I've recently acquired, and the way they could change your memories - when the "demons" are dripping acid into your eyes, then growing them back with more nerve endings than before so you can feel the pain more acutely, won't it be much more bearable if you're under the delusion that you've made a selfless sacrifice to save Eyal, and that your children and loved ones aren't suffering the same fate?

Countless others have agreed to this deal in the millenia before you were even born, and I have amassed enough essence to contain Kryl-Feijan in a stable "seed."  Once it is planted in a suitable victim and allowed to grow, he will once again walk Eyal, far more powerful than he was before, and the two of us will do everything we can to speed up your miserable world's much-deserved death.  Technically, any sentient and fleshy body would work, but I'd like someone who'll be missed, whose death will allow my lover's first act in rebirth to cause great misery to Eyal.  If you'd like to accept my deal, come unarmed and alone to the Crypt of Kryl-Feijan, and join your fellow Eyalites in servitude to me.  And if you were to bring a suitable host for my lover...  well, that'd be deserving of some special, one-on-one attention, wouldn't it?

Eyal is doomed to perish in screaming agony.  Wouldn't you at least like a good-bye kiss first?

-S.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-general_of_urh_rok",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Khulmanar, General of Urh'Rok",
	lore = [=[Our tournaments, run ever since our salvation from the dust mages under the command and inspiration of Urh'Rok, are not simply tests of direct combat, as many may think.  We have those, yes, but we also have competitions for scholarly work, attentiveness, physical endurance, philosophy, and countless other fields.  Perhaps the most prestigious of these, though, is the Divine Tournament of Tactics, by which our military leaders are selected.  Through a series of trials, we are compared in our abilities to assess a combat scenario and swiftly handle it, rated on speed, casualties, deployment efficiency, and a variety of other factors.  Khulmanar, a child of onyx, is the reigning champion of these, and has been for most of the time that we've spent waiting for our continent to reach Eyal.  Chosen by our process as the wisest tactical mind among our people, he was selected to meet with Urh'Rok himself to gain his approval to lead our forces in the invasion.  Urh'Rok was so impressed by Khulmanar that he used a significant portion of the little energy he's not using to hold our world together to build Khulmanar a new body, one strong enough to let him direct battles from the front-line without fear.  With a form and weapons granted by our Father, and a mind given his direct, enthusiastic approval, Khulmanar is considered to be the avatar of Urh'Rok, and his commands in battle are to be treated with the same reverence we would give to the words of Father himself.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-lithfengel",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Lithfengel",
	lore = [=[Lithfengel, mentor of Draebor and child of emerald, was one of our finest scholars.  When most of us were still too afraid to go near a portal, he recovered an intact one and began to pry apart its secrets, in hopes of reaching Eyal.  His data showed that although this portal was still technically connected to Eyal, the link between the two worlds was still fluctuating far too much to make it safe for travel, the still-raging flames threatening to tear any prospective passengers apart before they reached their destination.  Rather than try to repair the link directly, he went into his lab and didn't emerge for a few days; when he came out, he glowed with a strange new enchantment, proclaiming it would adaptively mutate him to endure whatever damage the portal would otherwise inflict.  Saying that the consequences of failure were too awful to risk inflicting on other test subjects, he entered the portal himself, promising to return immediately after he arrived; he has not been seen since.  May he rest in peace for his selfless devotion.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-rogroth",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Rogroth, Eater of Souls",
	lore = [=[Recently, the cultists of Shasshhiy'Kaish have begun speaking of a "demon seed," a sort of magical cluster of life-essence which can be implanted in a sentient being, allowing it to grow inside of them and eventually become one of our citizens.  Inspired by this idea, the children of emerald have developed a prototype of this form of magic, and the children of onyx have made a chassis to carry it into combat.  Rogroth generates countless essence-less seeds from within its frame, then embeds them in nearby living beings, so when they expire, their life-essence goes directly into the seed and allows it to grow.  We have not yet perfected its production capabilities, so currently the seeds will only become degenerate husks when they grow, but fear not!  As we get data from the tests of this design, we'll improve on it, and soon the slaughter of our foes will cause wretchlings, quasits, and even thaurheregs to spring up from their corpses.  With a little bit of luck and some decisive early skirmishes, we could even bypass the problem of getting an invasion force to the surface entirely, growing it there instead.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-corrupted_daelach",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Corrupted Daelach",
	lore = [=[One of the problems with making daelach is the inherent instability that comes from creating something that is almost entirely made of magic.  If ambient levels of blight are even slightly too high, it can set off a chain reaction that at best destroys the daelach, and at worst destroys most of the mages who were building it.  Daelach production is thus theoretically cheap, but in practice involves great expense, and usually a blighted daelach has to be immediately put down lest it cause tremendous damage.  One specimen, though, adapted to the blight in a very interesting way, sprouting wings and bolstering its usual firestorms with blight, but otherwise remaining perfectly balanced and controllable.  We'll try to recreate this happy accident however we can, but in the meantime, it will prove effective on the surface of Eyal.]=]
}

newLore{
	id = "ashes-urhrok-demon-statue-harkor_zun",
	category = "Ashes of Urh'Rok", always_pop = true,
	name = "demon statue: Harkor'Zun",
	lore = [=[Of the anomalies and phenomena we've noticed in our studies of the shield protecting Eyal, none have frustrated us so much as meteors.  Certain powerful Eyalite spellcasters can pull a large meteor into low orbit, passing it through the shield relatively unharmed, aside from being split into predictably-sized chunks, which are then called to the surface one-by-one in a series of devastating meteoric crashes.  While we have not yet found a way to reverse-engineer these spells to protect our standard troops from disintegration, we have had some limited success in making a construct that closely resembles a meteor in composition and appearance.  Harkor'Zun, a being made mostly of stone, was simply dropped from our platform; the shield shattered him as expected, but we had designed him to survive this, the fragments merging back into their completed form once he reached the surface.  It would seem, though, that either we made him to be too sturdy, or the shield envelops incoming objects in a sort of anti-magic coating, as he has been unable to start the second stage of this process, wherein he merges these fragments back into a completed form.  Should an Eyalite stumble upon him and attempt to destroy the fragments, Harkor'Zun will be able to re-combine and "thank" whoever granted him his ascension.]=]
}
