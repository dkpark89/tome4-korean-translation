-- ToME - Tales of Maj'Eyal:
-- Copyright (C) 2009 - 2015 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

getBirthDescriptor("class", "Wilder").descriptor_choices.subclass["Stone Warden"] = "allow"
getBirthDescriptor("class", "Wilder").locked = nil

newBirthDescriptor{
	type = "subclass",
	name = "Stone Warden",
	desc = {
		"Stone Wardens are dwarves trained in both the eldritch arts and the worship of nature.",
		"While other races are stuck in their belief that arcane forces and natural forces are meant to oppose, dwarves have found a way to combine them in harmony.",
		"Stone Wardens are armoured fighters, dual wielding shields to channel many of their powers.",
		"#GOLD#Stat modifiers:",
		"#LIGHT_BLUE# * +2 Strength, +0 Dexterity, +0 Constitution",
		"#LIGHT_BLUE# * +4 Magic, +3 Willpower, +0 Cunning",
		"#GOLD#Life per level:#LIGHT_BLUE# +2",
	},
	special_check = function(birth)
		if birth.descriptors_by_type.race ~= "Dwarf" then return false end
		return true
	end,
	power_source = {nature=true, arcane=true},
	not_on_random_boss = true,
	stats = { str=2, wil=3, mag=4, },
	talents_types = {
		["wild-gift/call"]={true, 0.2},
		["wild-gift/earthen-power"]={true, 0.3},
		["wild-gift/earthen-vines"]={true, 0.3},
		["wild-gift/dwarven-nature"]={true, 0.3},
		["spell/stone-alchemy"]={false, 0.3},
		["spell/eldritch-stone"]={false, 0.3},
		["spell/eldritch-shield"]={true, 0.3},
		["spell/deeprock"]={false, 0.3},
		["spell/earth"]={true, 0.2},
		["spell/stone"]={false, 0.2},
		["cunning/survival"]={true, 0},
		["technique/combat-training"]={true, 0},
	},
	talents = {
		[ActorTalents.T_STONE_VINES] = 1,
		[ActorTalents.T_STONESHIELD] = 1,
		[ActorTalents.T_ELDRITCH_BLOW] = 1,
		[ActorTalents.T_ARMOUR_TRAINING] = 3,
		[ActorTalents.T_WEAPON_COMBAT] = 1,
	},
	copy = {
		max_life = 110,
		resolvers.equipbirth{ id=true,
			{type="armor", subtype="shield", name="iron shield", autoreq=true, ego_chance=-1000, ego_chance=-1000},
			{type="armor", subtype="shield", name="iron shield", autoreq=true, ego_chance=-1000, ego_chance=-1000},
			{type="armor", subtype="heavy", name="iron mail armour", autoreq=true, ego_chance=-1000, ego_chance=-1000}
		},
	},
	copy_add = {
		life_rating = 2,
	},
}
