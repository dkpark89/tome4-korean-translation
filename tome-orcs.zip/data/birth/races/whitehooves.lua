-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newBirthDescriptor{
	type = "race",
	name = "MinotaurUndead",
	display_name = "Undead",
	locked = function() return profile.mod.allow_build.race_whitehooves end,
	locked_desc = "Grave strength, dread will, this flesh cannot stay still. Kings die, masters fall, we will outlast them all.",
	desc = {
		"Undead are humanoids (Humans, Elves, Dwarves, ...) that have been brought back to life by the corruption of dark magics.",
		"Undead can take many forms, from ghouls to vampires and liches.",
	},
	descriptor_choices =
	{
		subrace =
		{
			__ALL__ = "disallow",
			Whitehoof = "allow",
		},
		class =
		{
			Wilder = "disallow",
		},
	},
	talents = {
		[ActorTalents.T_UNDEAD_ID]=1,
	},
	copy = {
		type = "undead",
		undead = 1,
		forbid_nature = 1,
		inscription_forbids = { ["inscriptions/infusions"] = true, },
		resolvers.inscription("RUNE:_SHIELDING", {cooldown=14, dur=5, power=130}),
		--resolvers.inscription("RUNE:_PHASE_DOOR", {cooldown=7, range=10, dur=5, power=15}),
		resolvers.inscription("RUNE:_HEAT_BEAM", {cooldown=18, range=8, power=40}), -- yeek and undead starts are unfun to the point of absurdity
		resolvers.inventory({id=true, transmo=false, alter=function(o) o.inscription_data.cooldown=7 o.inscription_data.dur=5 o.inscription_data.power=15 o.inscription_data.range=10 end, {type="scroll", subtype="rune", name="phase door rune", ego_chance=-1000, ego_chance=-1000}}), -- keep this in inventory incase people actually want it, can't add it baseline because some classes start with 3 inscribed
	},

	cosmetic_unlock = {
		--------------------------------------------------------
		-- Ashes support
		--------------------------------------------------------
		cosmetic_red_skin = {
			{priority=2, name="Red Skin [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_base_alter = function(actor, base) return base:gsub('^base_', 'demonic_') end end end, reset=function(actor) actor.moddable_tile_base_alter = nil end},
		},
		--------------------------------------------------------
		race_whitehooves = {
			{name="Horns 2 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_base = "base_02.png" end end},
			{name="Horns 3 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_base = "base_03.png" end end},
			{name="Horns 4 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_base = "base_04.png" end end},
		},
		cosmetic_bikini =  {
			{name="Bikini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Bikini if not o then print("No bikini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_BIKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Female" end},
			{name="Mankini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Mankini if not o then print("No mankini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_MANKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Male" end},
		},
	},
}

---------------------------------------------------------
--                 Unread Minotaurs                    --
---------------------------------------------------------
newBirthDescriptor
{
	type = "subrace",
	name = "Whitehoof",
	locked = function() return profile.mod.allow_build.race_whitehooves end,
	locked_desc = "Grave strength, dread will, this flesh cannot stay still. Kings die, masters fall, we will outlast them all.",
	desc = {
		"A clan of minotaurs turned to necromancy when faced with imminent destruction.",
		"Whitehooves are resilient and magic imbued undead, hardened by their trials and made stronger by their undeath.",
		"They now seek to help their orc allies, in hope they will help them back.",
		"They have access to #GOLD#special talents#WHITE# and a wide range of undead abilities:",
		"- silence resistance",
		"- bleeding immunity",
		"- fear immunity",
		"- no need to breathe",
		"- special ghoul talents: dead hide, lifeless rush, essence drain",
		"#GOLD#Stat modifiers:",
		"#LIGHT_BLUE# * +3 Strength, -1 Dexterity, +2 Constitution",
		"#LIGHT_BLUE# * +2 Magic, -3 Willpower, +1 Cunning",
		"#GOLD#Life per level:#LIGHT_BLUE# 14",
		"#GOLD#Experience penalty:#LIGHT_BLUE# 30%",
	},
	inc_stats = { str=3, con=2, dex=-1, mag=2, wil=-3, cun=1 },
	talents_types = { ["race/whitehooves"]={true, 0} },
	talents = {
		[ActorTalents.T_WHITEHOOVES]=1,
	},
	copy = {
		auto_id = 100,
		faction = "free-whitehooves",
		subtype="minotaur",
		default_wilderness = {"playerpop", "yeti"},
		starting_zone = "orcs+vaporous-emporium",
		starting_quest = "orcs+start-orc",
		starting_intro = "orc-whitehooves",
		moddable_tile = "whitehoof",
		moddable_tile_base = "base_01.png",
		moddable_tile_nude = 1,
		no_breath = 1,
		poison_immune = 1,
		cut_immune = 1,
		silence_immune = 0.5,
		life_rating=14,
	},
	moddable_attachement_spots = "race_whitehoof", moddable_attachement_spots_sexless = true,
	experience = 1.3,
}
