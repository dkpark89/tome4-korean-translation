-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

-- getBirthDescriptor("race", "Giant").descriptor_choices.subrace["Kruk Yeti"] = "allow"
newBirthDescriptor{
	type = "race",
	name = "Yeti",
	locked = function() return profile.mod.allow_build.race_yeti end,
	locked_desc = "Infuse the mind, sacrifice the body but the Pride remains.",
	desc = {
		[[Yetis are a towering mass of muscle.]],
	},
	descriptor_choices =
	{
		subrace =
		{
			['Kruk Yeti'] = "allow",
			__ALL__ = "disallow",
		},
	},
	copy = {
		type = "giant", subtype="yeti",
		resolvers.inscription("INFUSION:_REGENERATION", {cooldown=10, dur=5, heal=60}),
		resolvers.inscription("INFUSION:_WILD", {cooldown=12, what={physical=true}, dur=4, power=14}),
	},

	moddable_attachement_spots = "race_yeti", moddable_attachement_spots_sexless=true,
	cosmetic_unlock = {
		cosmetic_race_human_redhead = {
			{priority=1, name="Red tint", donator=true, on_actor=function(actor) if actor.moddable_tile then
				actor.is_redhead = true
				actor.moddable_tile_base = "base_redhead_01.png"
			end end},
		},
		cosmetic_bikini =  {
			{name="Bikini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Bikini if not o then print("No bikini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_BIKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Female" end},
			{name="Mankini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Mankini if not o then print("No mankini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_MANKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Male" end},
		},
	},
}

---------------------------------------------------------
--                       Yetis                         --
---------------------------------------------------------
newBirthDescriptor
{
	type = "subrace",
	name = "Kruk Yeti",
	locked = function() return profile.mod.allow_build.race_yeti end,
	locked_desc = "Infuse the mind, sacrifice the body but the Pride remains.",
	desc = {
		"Yetis are a towering mass of muscle. While normal yetis are non-sentient beasts this kind is special.",
		"A few orcs of the Kurk pride have mastered techno-psionics, allowing them to literally hijack a yeti's mind and transfer their own mind inside.",
		"Doing so drains their old knowledge and they need to start afresh, gaining considerable strength in the process; for the good of the Prides.",
		"They possess the #GOLDAlgid Rage##WHITE# talent which allows them to encase their foes in blocks of ice.",
		"#GOLD#Stat modifiers:",
		"#LIGHT_BLUE# * +5 Strength, -3 Dexterity, +4 Constitution",
		"#LIGHT_BLUE# * +0 Magic, +1 Willpower, -1 Cunning",
		"#GOLD#Life per level:#LIGHT_BLUE# 13",
		"#GOLD#Experience penalty:#LIGHT_BLUE# 25%",
	},
	inc_stats = { str=5, con=4, dex=-3, wil=1, cun=-1 },
	talents_types = { ["race/yeti"]={true, 0} },
	talents = {
		[ActorTalents.T_ALGID_RAGE]=1,
	},
	copy = {
		auto_id = 100,
		faction = "kruk-pride",
		subtype="yeti",
		default_wilderness = {"playerpop", "yeti"},
		starting_zone = "orcs+vaporous-emporium",
		starting_quest = "orcs+start-orc",
		starting_intro = "orc-yeti",
		moddable_tile = "yeti",
		moddable_tile_head_underwear = "fur_head.png",
		moddable_tile_higher_underwear = "fur_body.png",
		moddable_tile_lower_underwear = "fur_legs.png",
		life_rating=13,
	},
	experience = 1.25,
}
