-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

---------------------------------------------------------
--                        Orcs                         --
---------------------------------------------------------
newBirthDescriptor{
	type = "race",
	name = "Orc",
	desc = {
		"Orcs have a long and sad history. They are seen, and are, as an aggressive race that more than one time managed to imperil all of Maj'Eyal.",
		"But one year ago the Scourge from the West came and wiped four of the five Prides. And a hundred years ago King Toknor wiped all traces of orcs from Maj'Eyal.",
		"The orc race is dangerously on the brink of destruction. One wrong move is all that is needed.",
		"But they are strong and will face whatever is needed to ensure a future of their own!",
	},
	descriptor_choices =
	{
		subrace =
		{
			__ALL__ = "disallow",
			Orc = "allow",
		},
	},
	copy = {
		auto_id = 100,
		faction = "kruk-pride",
		type = "humanoid", subtype="orc",
		default_wilderness = {"playerpop", "orc"},
		starting_zone = "orcs+town-kruk",
		starting_quest = "orcs+kruk-invasion",
		starting_intro = "orc",
		resolvers.inscription("INFUSION:_REGENERATION", {cooldown=10, dur=5, heal=60}),
		resolvers.inscription("INFUSION:_WILD", {cooldown=12, what={physical=true}, dur=4, power=14}),
	},
--	random_escort_possibilities = { {"trollmire", 2, 3}, {"ruins-kor-pul", 1, 2}, {"daikara", 1, 2}, {"old-forest", 1, 4}, {"dreadfell", 1, 8}, {"reknor", 1, 2}, },

	moddable_attachement_spots = "race_orc", moddable_attachement_spots_sexless=true,

	cosmetic_unlock = {
		--------------------------------------------------------
		-- Ashes support
		--------------------------------------------------------
		cosmetic_red_skin = {
			{name="Red Skin [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_base_alter = function(actor, base) return base:gsub('^base_', 'demonic_') end end end, reset=function(actor) actor.moddable_tile_base_alter = nil end},
		},
		cosmetic_doomhorns = {
			{priority=2, name="Demonic Horns 1 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_01", male="horns_01"} end end},
			{priority=2, name="Demonic Horns 2 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_02", male="horns_02"} end end},
			{priority=2, name="Demonic Horns 3 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_03", male="horns_03"} end end},
			{priority=2, name="Demonic Horns 4 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_04", male="horns_04"} end end},
			{priority=2, name="Demonic Horns 5 [donator only]", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="horns_05", male="horns_05"} end end},
		},
		--------------------------------------------------------
		cosmetic_race_orc = {
			{priority=2, name="Goggles", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="goggles_01", male="goggles_01"} end end},
			{priority=2, name="Monocle Left", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="monocle_left_01", male="monocle_left_01"} end end},
			{priority=2, name="Monocle Right", donator=true, on_actor=function(actor) if actor.moddable_tile then actor.moddable_tile_ornament={female="monocle_right_01", male="monocle_right_01"} end end},
		},
		cosmetic_bikini =  {
			{name="Bikini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Bikini if not o then print("No bikini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_BIKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Female" end},
			{name="Mankini [donator only]", donator=true, on_actor=function(actor, birther, last)
				if not last then local o = birther.obj_list_by_name.Mankini if not o then print("No mankini found!") return end actor:getInven(actor.INVEN_BODY)[1] = o:cloneFull()
				else actor:registerOnBirthForceWear("FUN_MANKINI") end
			end, check=function(birth) return birth.descriptors_by_type.sex == "Male" end},
		},
	},
}

---------------------------------------------------------
--                        Orcs                         --
---------------------------------------------------------
newBirthDescriptor
{
	type = "subrace",
	name = "Orc",
	desc = {
		"Orcs have a long and sad history. They are seen, and are, as an aggressive race that more than one time managed to imperil all of Maj'Eyal.",
		"But one year ago the Scourge from the West came and wiped four of the five Prides. And a hundred years ago King Toknor wiped all traces of orcs from Maj'Eyal.",
		"The orc race is dangerously on the brink of destruction. One wrong move is all that is needed.",
		"But they are strong and will face whatever is needed to ensure a future of their own!",
		"They possess the #GOLD#Orcish Fury#WHITE# which allows them to increase all their damage for a few turns.",
		"#GOLD#Stat modifiers:",
		"#LIGHT_BLUE# * +2 Strength, +1 Dexterity, +1 Constitution",
		"#LIGHT_BLUE# * -1 Magic, +1 Willpower, +1 Cunning",
		"#GOLD#Life per level:#LIGHT_BLUE# 12",
		"#GOLD#Experience penalty:#LIGHT_BLUE# 25%",
	},
	inc_stats = { str=2, con=1, dex=1, wil=1, cun=1, mag=-1 },
	talents_types = { ["race/orc"]={true, 0} },
	talents = {
		[ActorTalents.T_ORC_FURY]=1,
	},
	copy = {
		moddable_tile = "orc_#sex#",
		life_rating=12,
	},
	experience = 1.25,
}
