-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newLore{
	id = "yeti-cave-1",
	category = "yeti's cave",
	name = "crude cave painting (1)",
	image = "orcs/yeti_carving_01.png",
	lore = [[You see here a crude cave painting, depicting a drake attacking a group of yetis, as an indistinct figure watches over them.  To the right, you see a drawing of the figure attacking the drake, and the yetis cheering.]],
}

newLore{
	id = "yeti-cave-2",
	category = "yeti's cave",
	name = "crude cave painting (2)",
	image = "orcs/yeti_carving_02.png",
	lore = [[You see here a cave painting, depicting a giant attempting to lead some yetis away in chains, but being pulled down and mauled by other yetis.]],
}

newLore{
	id = "yeti-cave-3",
	category = "yeti's cave",
	name = "crude cave painting (3)",
	image = "orcs/yeti_carving_03.png",
	lore = [[You see here a cave painting, depicting a giant holding an object, which is projecting some sort of beam at a yeti.  The affected yeti is walking toward the giant, while other yetis are looking on in horror.]],
}
