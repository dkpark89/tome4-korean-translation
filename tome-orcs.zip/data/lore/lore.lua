-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

load("/data-orcs/lore/orcs.lua")
load("/data-orcs/lore/sunwall.lua")
load("/data-orcs/lore/emporium.lua")
load("/data-orcs/lore/quarry.lua")
load("/data-orcs/lore/gem.lua")
load("/data-orcs/lore/palace-fumes.lua")
load("/data-orcs/lore/destructicus.lua")
load("/data-orcs/lore/internment-camp.lua")
load("/data-orcs/lore/yeti.lua")
load("/data-orcs/lore/weissi.lua")
load("/data-orcs/lore/dominion-port.lua")
load("/data-orcs/lore/primal-forest.lua")
load("/data-orcs/lore/pocket-time.lua")
load("/data-orcs/lore/krimbul.lua")
load("/data-orcs/lore/misc.lua")
load("/data-orcs/lore/slumbering-caves.lua")
