-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

--------------------------------------------------------------------------
-- vaporous emporium
--------------------------------------------------------------------------

newLore{
	id = "vaporous-emporium-1",
	category = "vaporous emporium",
	name = "a large poster",
	lore = [[#{bold}#CLOGGING NO MORE!#{normal}#
If steam-vent congestion ails you, avail yourself of:
 
#{italic}#[An illustration depicts a rectangular glass bottle, labelled "DR. RAGLUK's DECLOGGING DRAUGHT".]#{normal}#
 
MADE WITH LOVE, CARE, AND THE PUREST MINERALS FROM THE STEAM QUARRY
 
Just one capful will cleanse your pores, flushing toxins out with the steam!
 
ALSO EFFECTIVE FOR: Headaches, nausea, ennui, fatigue, aches and pains, and general malaise!
 
#{italic}#[A disclaimer occupies the bottom margin of the poster, in print so small you doubt the giants would be able to read it.]#{normal}#
 
WARNING: This product has been determined by the Council of Health Authority to be correlated with the following conditions: Inverse vertigo, increased hair flammability, non-vaporous sweating, night terrors, liver dysphoria, headaches, miner's lung, brainlock, day terrors, mitosis, visions of a great butchered being, miner's elbow, skeletal emancipation, gastrointestinal infamy, brittle kidney, pinaciphobia, decreased global speed, teleportitis, miner's tongue, merged nostrils, an ancient and foul curse, lowered steam pressure, fat burning (literal), ocular feathering, Orcish body odor, arcane disruption, gravity loss, bloodlock, malfeasance, rectal carpeting, nihilism, mid-evening terrors, knee rust, and minor clogging of the pores.]],
}

newLore{
	id = "vaporous-emporium-2",
	category = "vaporous emporium",
	name = "tattered poster",
	lore = [[CLOSING SALE
for
KALTOR's FIREARMS, ARMOR, AND OTHER MARTIAL SUNDRIES
 
It is with a heavy heart that I must announce our closing.  After over twenty years of service, I am shutting my doors - the people of the Atmos Tribe apparently wish to trust the Guard with their well-being, and the Guard chooses to maintain the weapons it already has rather than purchase things like the #{italic}#BRILLIANT AUTO-LOADING ORC EXPELLER#{normal}# (only 30 gold!), or the #{italic}#PRESSURE-ENHANCED SLASHPROOF COMBAT SUIT#{normal}# (only 450 gold!).  I even offered discount options such as the #{italic}#LIL SURPRISE#{normal}# (now only 15 gold!), and yet the city would have none of it.  It would seem my services, and my talents, are simply not wanted.
 
Even if you have no fear of the orcish tribes, ritch swarms, and other assorted threats that lurk just outside our city walls, please consider purchasing some of my wares.  They are truly beautiful displays of craftsmanship, and would do well as a desk sculpture or (if properly disarmed) a child's toy.  If nothing else, you will be ensuring that a once-proud artisan with great love and respect for his craft need not resort to begging on the streets.]],
}

newLore{
	id = "vaporous-emporium-3",
	category = "vaporous emporium",
	name = "ornately-painted poster",
	lore = [[Stylish.  Elegant.  Exclusive.

#{bold}#EXTINCTION#{normal}#, a new line from Faerlhing's Weavings, the finest name in fashion.

Steel drakes can no longer be found in the wild - our pens contain the ONLY living ones in Var'Eyal, and possibly the last generation to not be marred by inbreeding-induced deformities.  When you wear our wonderful coats, dresses, boots, or corsets to a party, meeting, or other get-together, the others won't just notice the unique, metallic sheen matched with unparalleled flexibility unique to their scales.  They'll know that they CANNOT imitate your look.  That it's a look their children will NEVER have.  That YOU have made your mark on ecological history, and reaped the fashionable, comfortable benefits.  And steel drake scales are not known to decay naturally, so proof of your impeccable taste will live far longer than the species they were taken from.

Place your orders now.  Open bidding will run for 30 days, after which point orders will be handled on a first-come, first-serve basis.

Other fashions come and go.  #{bold}#EXTINCTION#{normal}# is forever.
]],
}

newLore{
	id = "vaporous-emporium-4",
	category = "vaporous emporium",
	name = "official-looking poster",
	lore = [[#{bold}#KEEP THE PRESSURE UP!#{normal}#
#{italic}#An announcement on power consumption, paid for by the Council of Geothermal Authority#{normal}#

As per our previous announcements, the geothermal vents of the Steam Quarry have begun to taper off in output.  While our geologists and military consider all available options for finding new vents (or alternative sources of steam power), we need YOUR cooperation to keep the pipes from running dry!  Here's how you can help make sure we have enough steam for everyone:

-Cook the old-fashioned way - with flame magic, or a firewood stove.  Flash-steamers, although certainly a convenient way of preparing food, are VERY inefficient.  For a free handbook on delicious and easy-to-learn recipes for a conventional or pyromancy-based stove, simply come to the Council of Geothermal Authority offices and take one from the lobby.

-Remember to shut off your appliances when you're done with them!  A full 5% of our power usage is estimated to be from washing machines, mills, carousels, generator-powered lighting, and other such devices left plugged in when not in use.  When you are done using an appliance, make sure it has been deactivated; to be completely sure, our experts recommend shutting off the valve entirely, then disconnecting the appliance and placing a standard cap over the output pipe.

-Have your pipes checked regularly.  Leaking valves and loose fittings can consume tremendous amounts of steam pressure; you are only required to have your home steam-pipes inspected every three years, but additional inspections are available at no charge (once every six months).  Volunteering for these inspections can reduce your geothermal consumption, and fees, dramatically.

-Use your own steam!  With regular exercise and a good diet, you can create your own power by wearing a collection suit, and plug the pressurized reserve tanks into your home intake valves to reduce the amount of power drawn from the geothermal system by over 40% (depending on personal production).  Short-term use of declogging tonics may help, but long-term use is generally ill-advised.

-Do NOT pressurize tanks from the tap and sell them to others!  This is a violation of Council law, punishable by a fine of up to 3,000 gold and up to four years in prison, per tank.

Thank you for helping ensure we ALL have power, while we work on curing this shortage!]],
}

newLore{
	id = "vaporous-emporium-5",
	category = "vaporous emporium",
	name = "hastily-written poster",
	lore = [[KALTOR's FIREARMS, ARMOR, AND OTHER MARTIAL SUNDRIES
is
OPEN FOR BUSINESS AGAIN!
 
The orcish hordes are upon us!  Although I am not normally one for gloating, I feel I must take this opportunity to say:
 
#{bold}#I TOLD YOU SO, YOU INGRATES#{normal}#
 
Do you see the need for my wonderful devices of self-defense NOW?  Do you see why I toiled so thoughtfully and tirelessly to make such exquisite contraptions that could've saved so many lives, if you'd only been willing to pay what I was asking for them, only a tiny fraction of what they were worth?  Does the USELESS City Guard see why they should have been purchasing my newest, improved models, such as the #{italic}#BRILLIANT AUTO-LOADING ORC EXPELLER#{normal}# (only 600 gold!  Get yours now!  Protect your family!) instead of abusing my built-to-last craftsmanship to keep my original production run around for over a decade?
 
Don't make the same mistake twice!  Purchase the #{italic}#LIL SURPRISE#{normal}# for merely 150 gold!  What's that?  You can't afford that entry-level price?  I guess you should've bought it while I was still making them!  Don't want to get your guts torn out by a little green-skinned savage?  My old price for the #{italic}#PRESSURE-ENHANCED SLASHPROOF COMBAT SUIT#{normal}# was a steal at 700 gold - if you want one now, I'm sure your life is worth at least 3800 gold to you.  It utilizes your own vents to power tiny motors hidden in its joints, granting an unparalleled combination of fortitude and mobility; guaranteed to protect you from ANY sort of harm those savages can dish out, without slowing you down!  Notice all those dead guardsmen around?  Notice how they AREN'T wearing a #{italic}#PRESSURE-ENHANCED SLASHPROOF COMBAT SUIT#{normal}#, despite my desperate recommendations?  Don't let that be you or your loved ones!
 
I'm sure you have your doubts as to the efficacy of my lovingly-made armaments; for a free demonstration of the quality and effectiveness of my goods, you are invited to try to take them by force.  I dare you - and that includes the City Guard, should they have any delusions about confiscating them for the public good.  The public has dug their own grave, and I will not pull them up simply out of charity; after all, they have offered me no such charity in the past.
 
#{italic}#[An address is listed at the bottom of this poster.  You could attempt to raid this store, if you wanted, but the owner's armed to the teeth - it's unlikely it'll be worth the risk.]#{normal}#
]],
	on_learn = function(who)
		if not game:isCampaign("Orcs") then return end
		local p = game:getPlayer(true)
		if not p:hasQuest("orcs+kaltor-shop") then p:grantQuest("orcs+kaltor-shop") end
	end,
}
