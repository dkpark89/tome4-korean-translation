-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newLore{
	id = "gem-1",
	category = "G.E.M",
	name = "strange black disk (1)",
	lore = [["...thing on? Okay, good. This is Haze Commander Parmor of the Geothermal Exploratory Mole, on a mission to..."  She sighs. " 'Find the Loyalist and arrange for our safe transport to his refuge, offering him his previous terms of agreement.' Which is Council-speak for 'flee in terror to the only thing that could bail us out of this mess, and bring the Eye with us.' Personally, I'm not keen on putting our fates in the hands of some nutter who lives underground and..." Indistinct grumbling. "...not even my damn job, I didn't sign up to be some politician's valet--"

#{italic}#(You hear a door opening, and another voice speaks.)#{normal}#

"Captain, the tea-maker isn't working!  Get someone on that, post-haste!"

#{italic}#(The door closes.)#{normal}#

"...Yeah, Councillor Tantalos is getting his tea as soon as he can un-kick the hornet's nest that got us into this chaos.  Moving on...  departure was on time, projected journey to the Loyalist's last known position is underway, making a tunnel there from right under the palace.  All systems functioning, except for the tea-maker, and I can't give a slag about that.  End log."]],
}

newLore{
	id = "gem-2",
	category = "G.E.M",
	name = "strange black disk (2)",
	lore = [["...for posterity!  Let's make sure future generations can hear the moments of history being made!" You hear the voice of Councillor Tantalos again... and then you hear a very strange voice, one that's all too clear. Even with the device playing it, it sounds like it's coming from inside your own head.#{normal}#

"Yes, yes, good idea. This is an important day, for both of us - no, for Eyal...  You've brought what I asked for so long ago, then?"

"Of course!  It's just--  bring the cart around here!"  (Clanking and grinding.)  "Open it up, if you wish."

"No need.  I can feel its power, it's so familiar and yet so new...  This could only be the Eye of Amakthel Himself!  It's beautiful, and all will know its beauty..."

"Er...  splendid, I assume!  This is the beginning of a long and beautiful partnership between the Atmos and...  your people!  Shall I go back up and tell them we're ready for them, and you're ready to handle the Orc situation? They're, ah, rather eager to come down here--"

"GO FORTH, MY HERALD. TELL THEM ALL ARE WELCOME."

"Wh-what are you--"  #{italic}#Screams in the background.  Gurgling.  Crashing.  A distant, bestial roar.#{normal}#

"AMAKTHEL WILL REWARD YOU FOR YOUR SERVICE AS YOU DESERVE." More crashing.  "YOU SHALL BE BLESSED WITH A BETTER NEW FORM.  A BETTER NEW MIND.  ALL YOUR PEOPLE ARE WELCOME TO..."

#{italic}#(You hear Parmor's voice again.)#{normal}#  "Slag it, RUN!  Grab everything and--"  (The recording ends.)
]],
}

newLore{
	id = "gem-3",
	category = "G.E.M",
	name = "strange black disk (3)",
	lore = [[#{italic}#(You hear loud, mechanical rumbling; in the distance, you hear sounds of struggling and bludgeoning, swords slicing through flesh, steamguns being fired, and shouts of pain from giant and horror alike.  Parmor sounds panicked.)#{normal}#

"Mayday, mayday, we are bailing out!  Tantalos is gone, and we are NOT going back for him!  Scrap the tunnel to the Palace of Fumes, scrap the entire damn council, we're getting as far away from here as we can--"  Loud hissing.  "MOTHER OF--!"  Grunts, squishing, slashing.  "Flooring it all the way to the damn Sunwall, we're taking the first farportal off this continent whether those tinies like it or not!  Guess this technically counts as treason, mutiny, whatever, but if the Council's hearing this, BLOW IT OUT YOUR STEAM-HOLES, WE'D RATHER LIVE!  Altitude rising, surface approaching, this is H.C. Parmor signing off--"]],
}



newLore{
	id = "gem-erratic-1",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[why is it down there why is it ANYWHERE]],
}

newLore{
	id = "gem-erratic-2",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[If anyone finds this, tell the Jarsovi brothers their father lov]],
}

newLore{
	id = "gem-erratic-3",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[Too many of them.  Couldn't pull more Atmos back in, wasn't safe, couldn't tell them from the others.  Hope we've got enough fuel to get us to the surface.]],
}

newLore{
	id = "gem-erratic-4",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[What have we done...  why didn't I stop it?]],
}

newLore{
	id = "gem-erratic-5",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[nothing living should have that many]],
}

newLore{
	id = "gem-erratic-6",
	category = "G.E.M",
	name = "erratic scribblings",
	lore = [[so that's what it looks like.  what THEY look like.  now I see why so many depictions were destroyed]],
}
