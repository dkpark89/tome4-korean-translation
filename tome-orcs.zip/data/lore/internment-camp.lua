-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

--------------------------------------------------------------------------
-- vaporous emporium
--------------------------------------------------------------------------

newLore{
	id = "internment-camp-1",
	category = "internment camp",
	name = "internment camp correspondence (1)",
	lore = [[#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

It's good to see that you and your followers have arrived safely! Hopefully you're settling in all right; thank you for coming, and pass my thanks on to the Elvala diplomats for getting you here on such short notice. I hope this is the first step in your kind - you Ogres, of course, but also the Shaloren who sent you here - joining forces with the Allied Kingdoms.

There are no Ziguranth here in the Far East, and the orcs in this camp have been compliant so far, on account of Mindwall's elaborate illusions. It's the most humane way to deal with them that we've found so far - we hope that his influence will have a permanent calming effect on them over time, but until then, they're happy and docile in their little dream-world. All you have to do is protect against any stragglers outside the walls looking to break their kin out of here, and patrol the halls to make sure any orcs who've managed to shake off the illusions are swiftly apprehended and dealt with. This should be a pretty easy job - if you need any particular help or provisions, though, let me know and I'll do what I can!

Sincerely,
Administrator Quellop

#{bold}#---#{normal}#

#{italic}#To: Administrator Quellop
From: Guard Captain Galsamae#{normal}#

We need four more chairs in the break room.

-Galsamae

#{bold}#---#{normal}#

#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

I'm sorry, but we can't really afford that, as the budget for amenities and luxuries is stretched pretty thin here as-is. Please try to keep your requests limited to necessities - even with Last Hope's merchants competing on price, the security over by the farportal means it's still not cheap to get things here.

Regretfully,
Administrator Quellop]],
}

newLore{
	id = "internment-camp-2",
	category = "internment camp",
	name = "internment camp correspondence (2)",
	lore = [[#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

I'm disappointed. I went around the camp for my first inspection today, and the hallways are filthy! Haven't you mopped them once since you got here? Not only that, but there was a guard sleeping on the job by the northwest corner! I thought you guys making a good impression was the entire point of this - if things keep going this poorly, I've got half a mind to ship you lot out and bring in some dwarves instead! They might not be cheap, but at least they're reliable!

Get your act together,
Administrator Quellop

#{bold}#---#{normal}#

#{italic}#To: Administrator Quellop
From: Guard Captain Galsamae#{normal}#

We need four more chairs in the break room. If you want the floors mopped, we'll need five chairs.

-Galsamae

#{bold}#---#{normal}#

#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

Do you have #{italic}#any#{normal}# idea how much it costs to transport an ogre-sized chair #{italic}#all the way out here?#{normal}# No.

With growing impatience,
Administrator Quellop]],
}

newLore{
	id = "internment-camp-3",
	category = "internment camp",
	name = "internment camp correspondence (3)",
	lore = [[#{italic}#To: Condescending Little Cretin
From: Guard Captain Galsamae#{normal}#

Listen here, you little cretin.

When we agreed to this, we requested 60 mind-caging helmets, properly sized, alongside 60 sets of mail armor, a minimum of 30 beds, and shifts of no more than eight hours a day. We GOT 35 helmets, and had to send 25 of our guards back lest they get sucked into Mindwall's illusions like these orcs - furthermore, the helmets were crudely modified, and wound up weighing about twice as much as they needed to. We got plate armor instead of mail, further increasing the burden each of us has to carry, and our reduced numbers mean we have to take 12-hour shifts. (Obviously, such a schedule leaves no time for mopping.) Combined with all that, we don't even have enough beds for everyone - depending on the day, 5 to 10 of us are stuck without a place to sleep.

With anyone else, this would be a recipe for a workforce that would quickly get exhausted. Our runes buy us a lot of time before that happens, but that saturation still builds up over time, and we need to rest. We can't just sleep on the floor, we're too big to not get sores from our weight pressing into a hard surface, so each shift, a few of us are stuck without sleep or rest. What you saw in the northwest corner was someone who'd collapsed from exhaustion, who has the longest patrol route and (due to my personal oversight, and I apologize for that) wound up being one of the few who couldn't sleep the previous night.

We know that getting more mind-caging helmets would cost a lot, as would more beds, so we've come up with the cheapest available option to fix this: more chairs. We can get almost as good a rest sleeping in a chair as we can in a bed, provided we throw in the couple of pillows we've managed to make from spare grain sacks. If we don't get this, though, my estimate is that within the next three months, we'll have another guard collapse on a main patrol route, not just that way-out-there one the last guy collapsed on. As in, close enough to the prisoners where his or her helmet might just roll off and into their grasp. And the moment some Orc puts that helmet on, it's all over.

We're fine with these miserable conditions. All things considered, it's still some of the best interpersonal interaction we've gotten outside of Elvala. We'd even be fine with a few of us dying from overwork, if that was the only consequence of such an awful work schedule - but it'd lead to a breakout. And we will NOT be blamed for ANOTHER catastrophe that WASN'T OUR FAULT.

I've said it before, and I'm saying it for the last time: #{bold}#WE NEED MORE CHAIRS IN THE BREAK ROOM.#{normal}# If you think it's too expensive, I will #{italic}#personally#{normal}# come down to your quarters and restrain you while my men confiscate your fancy little bed, desk, and dresser, then repurpose them as scrap lumber and padding to build ourselves some new chairs. I'm not any more comfortable with insubordination than you are, but this is quite literally a matter of life and death, and not just for my people.

-Galsamae

PS: If any mention of this is made to your superiors, I'll make sure they also know about the Atmos absinthe you had smuggled in here last week.]],
}

newLore{
	id = "internment-camp-4",
	category = "internment camp",
	name = "internment camp correspondence (4)",
	lore = [[#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

I've requested an increase to our budget. Ten beds and eight chairs are on their way. Is there anything else you need?

With my sincerest apologies,
Administrator Quellop

#{bold}#---#{normal}#

#{italic}#To: Administrator Quellop
From: Guard Captain Galsamae#{normal}#

A steel hand-rail on the south staircase would be nice.

-Galsamae

#{bold}#---#{normal}#

#{italic}#To: Guard Captain Galsamae
From: Administrator Quellop#{normal}#

Done.

-Quellop]],
}
