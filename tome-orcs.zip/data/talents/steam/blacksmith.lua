-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newTalent{
	name = "Massive Physique",
	type = {"steamtech/blacksmith",1},
	require = str_steamreq1,
	points = 5,
	mode = "passive",
	passives = function(self, t, p)
		self:talentTemporaryValue(p, "inc_stats", {
			[self.STAT_STR] = math.floor(2 * self:getTalentLevel(t)),
			[self.STAT_CON] = math.floor(2 * self:getTalentLevel(t)),
		})
	end,
	on_learn = function(self, t)
		if self:getTalentLevelRaw(t) == 5 then self:attr("size_category", 1) end
	end,
	on_unlearn = function(self, t)
		if self:getTalentLevelRaw(t) == 4 then self:attr("size_category", -1) end
	end,
	info = function(self, t)
		return ([[Working iron has honed your body into an amazing shape, granting %d strength and constitution.
		At talent level 5, you are so incredibly built that you gain one size category.]])
		:format(math.floor(2 * self:getTalentLevel(t)))
	end,
}

newTalent{
	name = "Endless Endurance",
	type = {"steamtech/blacksmith",2},
	require = str_steamreq2,
	points = 5,
	mode = "passive",
	passives = function(self, t, p)
		self:talentTemporaryValue(p, "healing_factor", self:getTalentLevel(t) * 0.02)
		self:talentTemporaryValue(p, "life_regen", self:getTalentLevel(t))
		self:talentTemporaryValue(p, "pin_immune", self:getTalentLevel(t) * 0.15)
	end,
	info = function(self, t)
		return ([[Working long hours at a forge has made you incredibly slow to tire and given you endless vitality.
		Your healing factor is increased by %d%% and your life regeneration by %0.2f.
		Stopping you is nearly impossible; your pinning resistance is increased by %d%%.]])
		:format(self:getTalentLevel(t) * 2, self:getTalentLevel(t), self:getTalentLevel(t) * 15)
	end,
}

newTalent{
	name = "Life in the Flames",
	type = {"steamtech/blacksmith",3},
	require = str_steamreq3,
	points = 5,
	mode = "passive",
	on_learn = function(self, t)
		if self:getTalentLevelRaw(t) == 5 then self:attr("ignore_fireburn", 1) end
	end,
	on_unlearn = function(self, t)
		if self:getTalentLevelRaw(t) == 4 then self:attr("ignore_fireburn", -1) end
	end,
	passives = function(self, t, p)
		self:talentTemporaryValue(p, "resists", {
			[DamageType.FIRE] = self:getTalentLevel(t) * 5,
			[DamageType.PHYSICAL] = self:getTalentLevel(t) * 3,
		})
	end,
	info = function(self, t)
		return ([[Slaving for many years at the forge has made you more resilient to physical pain and fire burns.
		Your fire resistance is increased by %d%% and your physical resistance by %d%%.
		At talent level 5, you are so accustomed to the flames that you become immune to the fireburn effect.]])
		:format(self:getTalentLevel(t) * 5, self:getTalentLevel(t) * 3)
	end,
}

newTalent{
	name = "Craftsman's Eye", short_name = "CRAFTS_EYE",
	type = {"steamtech/blacksmith",4},
	require = str_steamreq4,
	no_npc_use = true,
	points = 5,
	mode = "passive",
	passives = function(self, t, p)
		self:talentTemporaryValue(p, "combat_apr", self:getTalentLevel(t) * 4)
		self:talentTemporaryValue(p, "combat_critical_power", self:getTalentLevel(t) * 5)
	end,
	info = function(self, t)
		return ([[You can easily see the weak points in your enemy's defenses. After all, you know to look for the same flaws in your own work.
		This grants %d armour penetration and %d%% critical strike multiplier.
		At talent level 5, you can also fight stealthed and invisible creatures without penalty.]])
		:format(self:getTalentLevel(t) * 4, self:getTalentLevel(t) * 5)
	end,
}
