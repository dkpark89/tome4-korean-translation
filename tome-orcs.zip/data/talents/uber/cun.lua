-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

uberTalent{
	name = "Rak'Shor's Cunning", short_name = "RAKSHOR_CUNNING",
	mode = "passive",
	no_npc_use = true,
	require = { special={desc="Skeleton and Ghoul unlocked and not already undead.", fct=function(self)
		return profile.mod.allow_build.undead_ghoul and profile.mod.allow_build.undead_skeleton and not self:attr("undead")
	end} },
	callbackOnDeathbox = function(self, t, dialog, list)
		if self.rakshor_resurrected then return end
		list[#list+1] = {name="Rak'Shor's Cunning", action=function()
			self.rakshor_resurrected = true
			dialog:cleanActor(self)
			dialog:resurrectBasic(self)
			dialog:restoreResources(self)

			local tids = {}
			local types = {}
			for id, lvl in pairs(self.talents) do
				local t = self.talents_def[id]
				if t.type[1] and t.type[1]:find("^race/") then
					types[t.type[1]] = true
					tids[id] = lvl
				end
			end
			local unlearnt = 0
			for id, lvl in pairs(tids) do self:unlearnTalent(id, lvl, nil, {no_unlearn=true}) unlearnt = unlearnt + lvl end
			for tt, _ in pairs(types) do self.talents_types[tt] = nil end
			self.unused_generics = self.unused_generics + math.ceil(unlearnt / 2)

			self.descriptor.race = "Undead"
			if rng.percent(50) then
				self.descriptor.subrace = "Skeleton"
				if not self.has_custom_tile then
					self.moddable_tile = "skeleton"
					self.moddable_tile_nude = 1
					self.moddable_tile_base = "base_01.png"
					self.moddable_tile_ornament = nil
					self.attachement_spots = "race_skeleton"
				end
				self.blood_color = colors.GREY
				self.life_rating = 12
				self:attr("poison_immune", 1)
				self:attr("cut_immune", 1)
				self:attr("fear_immune", 1)
				self:attr("no_breath", 1)
				self:attr("undead", 1)
				self.inscription_forbids = self.inscription_forbids or {}
				self.inscription_forbids["inscriptions/infusions"] = true

				self:learnTalentType("undead/skeleton", true)
				self:setTalentTypeMastery("undead/skeleton", self:getTalentTypeMastery("undead/skeleton") - 0.3)
			else
				self.descriptor.subrace = "Ghoul"
				if not self.has_custom_tile then
					self.moddable_tile = "ghoul"
					self.moddable_tile_nude = 1
					self.moddable_tile_base = "base_01.png"
					self.moddable_tile_ornament = nil
					self.attachement_spots = "race_ghoul"
				end
				self.life_rating = 14

				self:attr("poison_immune", 0.8)
				self:attr("cut_immune", 1)
				self:attr("stun_immune", 0.5)
				self:attr("fear_immune", 1)
				self:attr("undead", 1)
				self:attr("global_speed_base", -0.2)
				self:recomputeGlobalSpeed()
				self.inscription_forbids = self.inscription_forbids or {}
				self.inscription_forbids["inscriptions/infusions"] = true

				self:learnTalentType("undead/ghoul", true)
				self:setTalentTypeMastery("undead/ghoul", self:getTalentTypeMastery("undead/ghoul") - 0.3)
			end

			game.level.map:particleEmitter(self.x, self.y, 1, "demon_teleport")

			self:updateModdableTile()
			self:check("on_resurrect", "rakshor_cunning")
			game:saveGame()
		end}
	end,
	info = function(self, t)
		return ([[Set up some cunning contingency plans in case of death.
		If you die you will have the option to raise back from the dead once, but at the cost of becoming a ghoul or a skeleton, at random.
		When rising this way you will lose access to your racial tree, if any, get refunded for half the points you spent in it and gain access to the ghoul or skeleton racial tree.
		As undead are not able to use infusions you will lose any that you may have upon turning.]])
		:format()
	end,
}
