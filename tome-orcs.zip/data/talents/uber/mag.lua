-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

newTalent{
	name = "Arcane Amplification Drone Effect", image = "talents/arcane_amplification_drone.png",
	type = {"spell/other", 1},
	mode = "passive",
	points = 1,
	callbackOnTakeDamage = function(self, t, src, x, y, type, dam, tmp)
		if dam <= 0 or src ~= self.summoner then return end

		local source_talent = src.__projecting_for and src.__projecting_for.project_type and (src.__projecting_for.project_type.talent_id or src.__projecting_for.project_type.talent) and src.getTalentFromId and src:getTalentFromId(src.__projecting_for.project_type.talent or src.__projecting_for.project_type.talent_id)
		if not source_talent or not source_talent.is_spell then return end

		self:project({type="ball", range=0, radius=4}, self.x, self.y, DamageType.ARCANE, dam * 1.6)
		game.level.map:particleEmitter(self.x, self.y, 4, "generic_sploom", {rm=150, rM=180, gm=20, gM=60, bm=180, bM=200, am=80, aM=150, radius=2, basenb=120})
		return {dam=0}
	end,
	info = function(self, t)
		return ([[Spell damage done to it ripples in radius 4 doing 160% arcane damage.]])
	end,
}

uberTalent{
	name = "Arcane Amplification Drone",
	require = { special={desc="Have gained the #{italic}#Tales of the Spellblaze#{normal}# achievement with this or any previous character for the current difficulty & permadeath settings.", fct=function(self)
		local id = world:getCurrentAchievementDifficultyId(game, "SPELLBLAZE_LORE")
		return world:hasAchievement(id)
	end} },
	cooldown = 10,
	no_npc_use = true,
	no_energy = true,
	range = 7,
	action = function(self, t)
		local tg = {type="bolt", nowarning=true, range=self:getTalentRange(t), nolock=true, simple_dir_request=true, talent=t}
		local tx, ty, target = self:getTarget(tg)
		if not tx or not ty then return nil end
		local _ _, _, _, tx, ty = self:canProject(tg, tx, ty)
		target = game.level.map(tx, ty, Map.ACTOR)
		if target == self then target = nil end

		-- Find space
		local x, y = util.findFreeGrid(tx, ty, 5, true, {[Map.ACTOR]=true})
		if not x then
			game.logPlayer(self, "Not enough space to summon!")
			return
		end

		local NPC = require "mod.class.NPC"
		local m = NPC.new{
			type = "construct", subtype = "mechanical",
			display = "*", color=colors.UMBER,
			name = "arcane amplification drone", faction = self.faction, image = "npc/construct_mechanical_arcane_amplification_drone.png",
			resolvers.nice_tile{tall=1},
			desc = [[Any spell damage you deal to it will ripple around in radius 4 as 160% arcane damage.]],
			autolevel = "none",
			ai = "summoned", ai_real = "dumb_talented", ai_state = { talent_in=1, },
			level_range = {1, 1}, exp_worth = 0,

			max_life = 1000000,
			life_rating = 0,
			never_move = 1,
			combat_armor = 0, combat_def = 0,

			resolvers.talents{
				[self.T_ARCANE_AMPLIFICATION_DRONE_EFFECT] = 1,
			},

			summoner = self, summoner_gain_exp=true,
			summon_time = 3,
		}

		m:resolve() m:resolve(nil, true)
		m:forceLevelup(self.level)
		-- if core.shader.active(4) then m:addParticles(Particles.new("shader_ring_rotating", 1, {toback=true, rotation=0, radius=2, img="arcanegeneric", a=0.7}, {type="sunaura", time_factor=5000}))
		-- else m:addParticles(Particles.new("ultrashield", 1, {rm=180, rM=220, gm=10, gM=50, bm=190, bM=220, am=120, aM=200, radius=0.4, density=100, life=8, instop=20}))
		-- end

		game.zone:addEntity(game.level, m, "actor", x, y)
		game.level.map:particleEmitter(x, y, 1, "summon")
		return true
	end,
	info = function(self, t)
		return ([[You create an Arcane Amplification Drone at the selected location for 3 turns.
		When you cast a spell that damages the drone it will ripple the damage as 160%% arcane damage of the initial hit in radius 4.]])
		:format()
	end,
}
