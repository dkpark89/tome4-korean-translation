-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

-------------------------------------------------------------------
-- For tinkers
-------------------------------------------------------------------

newIngredient{ id = "LUMP_ORE1",
	type = "metal", material_level = 1,
	icon = "object/lump_of_iron.png",
	name = "lump of iron",
	desc = [[A lump of iron.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "LUMP_ORE2",
	type = "metal", material_level = 2,
	icon = "object/lump_of_steel.png",
	name = "lump of steel",
	desc = [[A lump of steel.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "LUMP_ORE3",
	type = "metal", material_level = 3,
	icon = "object/lump_of_dwarven_steel.png",
	name = "lump of dwarven steel",
	desc = [[A lump of dwarven steel.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "LUMP_ORE4",
	type = "metal", material_level = 4,
	icon = "object/lump_of_stralite.png",
	name = "lump of stralite",
	desc = [[A lump of stralite.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "LUMP_ORE5",
	type = "metal", material_level = 5,
	icon = "object/lump_of_voratun.png",
	name = "lump of voratun",
	desc = [[A lump of voratun.]],
	min = 0, max = INFINITY,
	tinker = true,
}

newIngredient{ id = "HERBS1",
	type = "herbs", material_level = 1,
	icon = "object/herb_vipersweed.png",
	name = "stack of herbs (viperweed)",
	desc = [[A stack of herbs.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "HERBS2",
	type = "herbs", material_level = 2,
	icon = "object/herb_sessali.png",
	name = "stack of herbs (sessali)",
	desc = [[A stack of herbs.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "HERBS3",
	type = "herbs", material_level = 3,
	icon = "object/herb_bilberry.png",
	name = "stack of herbs (bilberry)",
	desc = [[A stack of herbs.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "HERBS4",
	type = "herbs", material_level = 4,
	icon = "object/herbs_burdock.png",
	name = "stack of herbs (burdock)",
	desc = [[A stack of herbs.]],
	min = 0, max = INFINITY,
	tinker = true,
}
newIngredient{ id = "HERBS5",
	type = "herbs", material_level = 5,
	icon = "object/herbs_goldleaf.png",
	name = "stack of herbs (goldleaf)",
	desc = [[A stack of herbs.]],
	min = 0, max = INFINITY,
	tinker = true,
}

newIngredient{ id = "BRAIN_JAR",
	type = "misc",
	icon = "object/brain_in_jar.png",
	name = "brain in a jar",
	desc = [[A still living brain of a powerful psionic creature.]],
	min = 0, max = INFINITY,
}

newIngredient{ id = "MECHANICAL_CORE",
	type = "misc",
	icon = "object/mechanical_core.png",
	name = "mechanical core",
	desc = [[The core unit of the Automated Defense System.]],
	min = 0, max = INFINITY,
}

newIngredient{ id = "PRIMAL_CORE",
	type = "misc",
	icon = "object/primal_core.png",
	name = "primal core",
	desc = [[The core wood of a great tree.]],
	min = 0, max = INFINITY,
}
