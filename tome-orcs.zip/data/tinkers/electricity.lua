-- ToME - Tales of Maj'Eyal
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org
local DamageType = require "engine.DamageType"

newRecipe{ id = "LIGHTNING_COIL",
	name = "Lightning Coil", icon = "shockbolt/object/tinkers_lightning_coil_t5.png",
	desc = "Lightning coils can be attached to melee weapons to generate a short range beam of electricity on melee crits.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=20, rarity=50, cost=80},
	talents = {
		T_ELECTRICITY = 3,
	},
	ingredients = {
		LUMP_ORE = 3,
	},
}

newRecipe{ id = "MANA_COIL",
	name = "Mana Coil", icon = "shockbolt/object/tinkers_mana_coil_t5.png",
	desc = "Mana coils can be attached to staves to improve mana regeneration and cast a lightning spell on spell hits.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=15, rarity=70, cost=110},
	talents = {
		T_ELECTRICITY = 2,
		T_SMITH = 1,
	},
	ingredients = {
		LUMP_ORE = 5,
	},
	items = {
		GEM_SAPPHIRE = "sapphire",
	},
}

newRecipe{ id = "SHOCKING_TOUCH",
	name = "Shocking Touch", icon = "shockbolt/object/tinkers_shocking_touch_t5.png",
	desc = "Gives you the Electric Touch. Higher tiers will chain.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=18, rarity=50, cost=150},
	talents = {
		T_ELECTRICITY = 3,
	},
	ingredients = {
		LUMP_ORE = 2,
	},
}

newRecipe{ id = "DEFLECTION_FIELD",
	name = "Deflection Field", icon = "shockbolt/object/tinkers_deflection_field_t5.png",
	desc = "Protect yourself with the Power of Magnetism! Attach this device to your belt and watch those bullets miss every time! (not guaranteed to work every time)",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=10, rarity=50, cost=80},
	talents = {
		T_ELECTRICITY = 2,
	},
	ingredients = {
		LUMP_ORE = 2,
	},
}

newRecipe{ id = "GALVANIC_RETRIBUTOR",
	name = "Galvanic Retributor", icon = "shockbolt/object/tinkers_galvanic_retribution_t5.png",
	desc = "Fortify your shield with electricity and prepare to unleash GALVANIC RETRIBUTION against your attackers!",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=30, rarity=100, cost=160},
	talents = {
		T_ELECTRICITY = 4,
	},
	ingredients = {
		LUMP_ORE = 4,
	},
}

-- newRecipe{ id = "GAUSS_ACCELERATOR",
-- 	name = "Gauss Accelerator", icon = "shockbolt/object/tinkers_lightning_coil_t5.png",
-- 	desc = "Use the amazing Power of Electricity to give your Steamgun some extra punch!",
-- 	base_ml = 1, max_ml = 5,
-- 	random_schematic = {level=1, rarity=100, cost=160},
-- 	talents = {
-- 		T_ELECTRICITY = 2,
-- 	},
-- 	ingredients = {
-- 		LUMP_ORE = 2,
-- 	},
-- }

newRecipe{ id = "SHOCKING_EDGE",
	name = "Shocking Edge", icon = "shockbolt/object/tinkers_shocking_edge_t5.png",
	desc = "Attaching a capacitor to your weapon in just the right way is a great way to shock your enemies.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=10, rarity=100, cost=160},
	talents = {
		T_ELECTRICITY = 2,
		T_SMITH = 1,
	},
	ingredients = {
		LUMP_ORE = 3,
	},
}

newRecipe{ id = "SAW_STORM",
	name = "Steamsaw: Stormcutter", icon = "shockbolt/object/artifact/stormcutter.png",
	desc = "The pinnacle of steamsaws technology. Every one of your hits will unleash the power of the storm onto your foes, chaining between them and stunning them!",
	base_ml = 5, max_ml = 5,
	unique = true,
	talents = {
		T_SMITH = 4,
		T_ELECTRICITY = 5,
		T_MECHANICAL = 3,
	},
	ingredients = {
		LUMP_ORE = 40,
		MECHANICAL_CORE = 1,
	},
	items = {
		TINKER_SHOCKING_EDGE5 = "shocking edge",
		GEM_FIRE_OPAL = "fire opal",
		GEM_PEARL = "pearl",
		GEM_DIAMOND = "diamond",
		GEM_BLOODSTONE = "bloodstone",
	},
}

newRecipe{ id = "VOLTAIC_SENTRY",
	name = "Voltaic Sentry", icon = "shockbolt/object/tinkers_voltaic_sentry_t5.png",
	desc = "Just drop it down and watch the sparks fly when your enemies get near.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=20, rarity=100, cost=160},
	talents = {
		T_ELECTRICITY = 4,
		T_MECHANICAL = 1,
	},
	ingredients = {
		LUMP_ORE = 3,
	},
}

newRecipe{ id = "MENTAL_STIMULATOR",
	name = "Mental Stimulator", icon = "shockbolt/object/tinkers_mental_stimulator_t5.png",
	desc = "Supercharge your thinking and give your brain a boost with the Mental Stimulator!",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=10, rarity=50, cost=80},
	talents = {
		T_ELECTRICITY = 1,
	},
	ingredients = {
		LUMP_ORE = 2,
	},
}

newRecipe{ id = "POWER_DISTRIBUTOR",
	name = "Power Distributor", icon = "shockbolt/object/tinkers_power_distributor_t5.png",
	desc = "The Power Distributor V2 ensures you have the energy where and when you need it, without any of the side effects like V1 had.",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=20, rarity=100, cost=160},
	talents = {
		T_ELECTRICITY = 2,
		T_THERAPEUTICS = 1,
	},
	ingredients = {
		LUMP_ORE = 2,
		HERBS = 2,
	},
}

newRecipe{ id = "WHITE_LIGHT_EMITTER",
	name = "White Light Emitter", icon = "shockbolt/object/tinkers_white_light_emitter_t5.png",
	desc = "Add more light to your light!",
	base_ml = 1, max_ml = 5,
	random_schematic = {level=20, rarity=100, cost=160},
	talents = {
		T_ELECTRICITY = 2,
		T_CHEMISTRY = 1,
	},
	ingredients = {
		LUMP_ORE = 3,
		HERBS = 1,
	},
}
