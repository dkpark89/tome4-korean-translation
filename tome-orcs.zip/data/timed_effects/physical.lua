-- ToME - Tales of Maj'Eyal:
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

local Stats = require "engine.interface.ActorStats"
local Particles = require "engine.Particles"
local Entity = require "engine.Entity"
local Chat = require "engine.Chat"
local Map = require "engine.Map"
local Level = require "engine.Level"

newEffect{
	name = "STRAFING", image = "talents/strafe.png",
	desc = "Strafing",
	long_desc = function(self, eff) return ("The target is moving while shooting, and will reload %sammo when finished strafing."):format(self.player and self:callTalent(self.T_STRAFE, "getReload", eff.turns).." " or "") end,
	type = "physical",
	subtype = { technique=true },
	status = "beneficial",
	parameters = {turns = 0},
	charges = function(self, eff) return self.player and self:callTalent(self.T_STRAFE, "getReload", eff.turns) or "--" end,
	deactivate = function(self, eff)
		self:startTalentCooldown(self.T_STRAFE)

		local weapon, ammo, offweapon = self:hasArcheryWeapon()
		if weapon and ammo and not ammo.infinite then
			local t = self:getTalentFromId(self.T_STRAFE)
			ammo.combat.shots_left = math.min(ammo.combat.shots_left + t.getReload(self, t, eff.turns), ammo.combat.capacity)
			game.logSeen(self, "%s reloads.", self.name:capitalize())
		end
	end,
}

newEffect{
	name = "STARTLING_SHOT", image = "talents/startling_shot.png",
	desc = "Startled",
	long_desc = function(self, eff) return ("The target is startled after being strangely missed by a shot. The next shot it takes will deal %d%% more damage."):format(eff.power*100) end,
	type = "physical",
	subtype = { technique=true },
	status = "detrimental",
	parameters = {power=1.2},
}

newEffect{
	name = "IRON_GRIP", image = "talents/iron_grip.png",
	desc = "Iron Grip",
	long_desc = function(self, eff) return ("The target has been crushed, pinning it and reducing defense and armour by %d."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "detrimental",
	on_gain = function(self, err) return "#Target# is crushed by the iron grip.", "+Iron Grip" end,
	on_lose = function(self, err) return "#Target# is free from the iron grip.", "-Iron Grip" end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "never_move", 1)
		self:effectTemporaryValue(eff, "combat_def", -eff.power)
		self:effectTemporaryValue(eff, "combat_armor", -eff.power)
	end,
}

newEffect{
	name = "ENHANCED_BULLETS_OVERHEAT", image = "talents/overheat_bullets.png",
	desc = "Bullet Mastery: Overheated",
	long_desc = function(self, eff) return ("Bullets shot are overheated:  When striking their target, they set it on fire for %d fire damage over 5 turns"):format(self:damDesc(DamageType.FIRE, eff.power)) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# tweaks some of "..string.his_her(self).." bullets.", "+Bullet Mastery" end,
	parameters = {power = 10},
}
newEffect{
	name = "ENHANCED_BULLETS_SUPERCHARGE", image = "talents/supercharge_bullets.png",
	desc = "Bullet Mastery: Supercharged",
	long_desc = function(self, eff) return ("Bullets shot are supercharged:  They can pass through multiple targets and have %d additional armour penetration."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# tweaks some of "..string.his_her(self).." bullets.", "+Bullet Mastery" end,
	parameters = {power = 5},
}
newEffect{
	name = "ENHANCED_BULLETS_PERCUSIVE", image = "talents/percussive_bullets.png",
	desc = "Bullet Mastery: Percussive",
	long_desc = function(self, eff) return ("Bullets shot are percussive:  When striking, they have a %d%% chance to knock back and a %d%% chance to stun."):format(eff.power, eff.stunpower) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# tweaks some of "..string.his_her(self).." bullets.", "+Bullet Mastery" end,
	parameters = {power=10, stunpower=10},
}
newEffect{
	name = "ENHANCED_BULLETS_COMBUSTIVE", image = "talents/combustive_bullets.png",
	desc = "Bullet Mastery: Combustive",
	long_desc = function(self, eff) return ("Bullets shot are combustive:  When striking their target, they explode (radius 2) for %d fire damage."):format(self:damDesc(DamageType.FIRE, eff.power)) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# tweaks some of "..string.his_her(self).." bullets.", "+Bullet Mastery" end,
	parameters = {power = 10},
}

newEffect{
	name = "UNCANNY_RELOAD", image = "talents/uncanny_reload.png",
	desc = "Uncanny Reload",
	long_desc = function(self, eff) return ("Firing steamguns does not consume shots."):format() end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# is focuses on firing.", "+Uncanny Reload" end,
	on_lose = function(self, err) return "#Target# is less focused.", "-Uncanny Reload" end,
	parameters = {},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "infinite_ammo", 1)
	end,
}

newEffect{
	name = "CLOAK", image = "talents/cloak.png",
	desc = "Cloak",
	long_desc = function(self, eff) return ("The target is wrapped in a cloak of shadow, granting sealth.") end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# disappears from sight.", "+Cloak" end,
	on_lose = function(self, err) return "#Target# re-appears.", "-Cloak" end,
	parameters = {},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "stealth", eff.power)
	end,
}

newEffect{
	name = "PAIN_SUPPRESSOR_SALVE", image = "talents/pain_suppressor_salve.png",
	desc = "Pain Suppressor Salve",
	long_desc = function(self, eff) return ("Fight to the brink of death, can not die before going under -%d life (but life under 0 is not shown) and increases all resistances by %d%%."):format(eff.die_at, eff.resists) end,
	type = "physical",
	subtype = { nature=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# uses a pain suppressor salve.", "+Pain Suppressor" end,
	on_lose = function(self, err) return "#Target# is not affected anymore by the salve.", "-Pain Suppressor" end,
	parameters = { power=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "die_at", -eff.die_at)
		self:effectTemporaryValue(eff, "resists", {all=eff.resists})
	end,
}

newEffect{
	name = "FROST_SALVE", image = "talents/frost_salve.png",
	desc = "Frost Salve",
	long_desc = function(self, eff) return ("Provides a frost aura, giving you +%d%% cold, nature and darkness affinity."):format(eff.power) end,
	type = "physical",
	subtype = { frost=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# uses a frost salve.", "+Frost Salve" end,
	on_lose = function(self, err) return "#Target# is not affected anymore by the salve.", "-Frost Salve" end,
	parameters = { power=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "damage_affinity", {
			[DamageType.COLD] = eff.power,
			[DamageType.NATURE] = eff.power,
			[DamageType.DARKNESS] = eff.power,
		})
	end,
}

newEffect{
	name = "FIERY_SALVE", image = "talents/fiery_salve.png",
	desc = "Fiery Salve",
	long_desc = function(self, eff) return ("Provides a frost aura, giving you +%d%% fire, light, and lightning affinity."):format(eff.power) end,
	type = "physical",
	subtype = { fire=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# uses a fiery salve.", "+Fiery Salve" end,
	on_lose = function(self, err) return "#Target# is not affected anymore by the salve.", "-Fiery Salve" end,
	parameters = { power=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "damage_affinity", {
			[DamageType.FIRE] = eff.power,
			[DamageType.LIGHT] = eff.power,
			[DamageType.LIGHTNING] = eff.power,
		})

		local zones = { ["orcs+sunwall-observatory"]=true, ["orcs+sunwall-outpost"]=true, ["orcs+gates-of-morning"]=true }
		if game.zone and zones[game.zone.short_name or ""] and self.player and eff.power >= 66 then
			world:gainAchievement("ORCS_FIERY_MOCKERY", game.player)
		end
	end,
}

newEffect{
	name = "WATER_SALVE", image = "talents/water_salve.png",
	desc = "Water Salve",
	long_desc = function(self, eff) return ("Provides a frost aura, giving you +%d%% blight, mind and acid affinity."):format(eff.power) end,
	type = "physical",
	subtype = { water=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# uses a water salve.", "+Water Salve" end,
	on_lose = function(self, err) return "#Target# is not affected anymore by the salve.", "-Water Salve" end,
	parameters = { power=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "damage_affinity", {
			[DamageType.BLIGHT] = eff.power,
			[DamageType.MIND] = eff.power,
			[DamageType.ACID] = eff.power,
		})
	end,
}

newEffect{
	name = "UNSTOPPABLE_FORCE_SALVE", image = "talents/unstoppable_force_salve.png",
	desc = "Unstoppable Force Salve",
	long_desc = function(self, eff) return ("Increases all saves by %d and healing factor by %d%%."):format(eff.power, eff.power / 2) end,
	type = "physical",
	subtype = { tech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# uses an unstoppable force salve.", "+Unstoppable Force" end,
	on_lose = function(self, err) return "#Target# is not affected anymore by the salve.", "-Unstoppable Force" end,
	parameters = { power=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "combat_physresist", eff.power)
		self:effectTemporaryValue(eff, "combat_spellresist", eff.power)
		self:effectTemporaryValue(eff, "combat_mentalresist", eff.power)
		self:effectTemporaryValue(eff, "healing_factor", eff.power / 2)
	end,
}

newEffect{
	name = "SLOW_TALENT", image = "talents/slow.png",
	desc = "Slow Talents",
	long_desc = function(self, eff) return ("Attacking, casting and mind speed have been reduced by %d%%."):format(eff.power * 100) end,
	type = "physical",
	subtype = { slow=true },
	status = "detrimental",
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "combat_physspeed", -eff.power)
		self:effectTemporaryValue(eff, "combat_mindspeed", -eff.power)
		self:effectTemporaryValue(eff, "combat_spellspeed", -eff.power)
	end,
}

newEffect{
	name = "SUPERCHARGE_TINKERS", image = "talents/supercharge_tinkers.png",
	desc = "Supercharge Tinkers",
	long_desc = function(self, eff) return ("Increases steampower by %d and steam crit by %d%%."):format(eff.power, eff.crit) end,
	type = "physical",
	subtype = { tech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# supercharges all tinkers.", "+Supercharge Tinkers" end,
	on_lose = function(self, err) return "#Target#'s supercharge is fading.", "-Supercharge Tinkers" end,
	parameters = { power=10, crit=1 },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "combat_steampower", eff.power)
		self:effectTemporaryValue(eff, "combat_steamcrit", eff.crit)
	end,
}

newEffect{
	name = "OVERCHARGE_SAWS", image = "talents/overcharge_saws.png",
	desc = "Overcharge Saws",
	long_desc = function(self, eff) return ("Increases all saws talent levels by %d%%."):format(eff.power) end,
	type = "physical",
	subtype = { tech=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# overcharges saw motors.", "+Overcharge Saws" end,
	on_lose = function(self, err) return "#Target#'s saw motors are back to normal.", "-Overcharge Saws" end,
	parameters = { power=20 },
	activate = function(self, eff)
		local tts = {
			["steamtech/butchery"] = eff.power / 100,
			["steamtech/sawmaiming"] = eff.power / 100,
			["steamtech/battlefield-management"] = eff.power / 100,
			["steamtech/automated-butchery"] = eff.power / 100,
		}
		eff.tts = tts
		eff.tmpid = self:addTemporaryValue("talents_types_mastery", tts)

		local list = {}
		for tid, _ in pairs(self.sustain_talents) do
			local t = self:getTalentFromId(tid)
			if tts[t.type[1]] then list[#list+1] = tid end
		end
		for _, tid in ipairs(list) do
			self:forceUseTalent(tid, {silent=true, ignore_energy=true, ignore_cd=true, no_equilibrium_fail=true, no_paradox_fail=true})
			self:forceUseTalent(tid, {silent=true, ignore_energy=true, ignore_cd=true, no_equilibrium_fail=true, no_paradox_fail=true})
		end
	end,
	deactivate = function(self, eff)
		self:removeTemporaryValue("talents_types_mastery", eff.tmpid)

		local list = {}
		for tid, _ in pairs(self.sustain_talents) do
			local t = self:getTalentFromId(tid)
			if eff.tts[t.type[1]] then list[#list+1] = tid end
		end
		for _, tid in ipairs(list) do
			self:forceUseTalent(tid, {silent=true, ignore_energy=true, ignore_cd=true, no_equilibrium_fail=true, no_paradox_fail=true})
			self:forceUseTalent(tid, {silent=true, ignore_energy=true, ignore_cd=true, no_equilibrium_fail=true, no_paradox_fail=true})
		end
	end,
}

newEffect{
	name = "ALGID_RAGE", image = "talents/algid_rage.png",
	desc = "Algid Rage",
	long_desc = function(self, eff) return ("You have %d%% chances to encase your foes in iceblocks."):format(eff.power) end,
	type = "physical",
	subtype = { ice=true },
	status = "beneficial",
	callbackOnDealDamage = function(self, eff, value, target, dead, death_node)
		if dead then return end
		if not rng.percent(eff.power) then return end
		target:setEffect(target.EFF_FROZEN, 3, {hp=util.bound(value * 0.7, 30, 300)})
	end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "iceblock_pierce", 50)
	end,
}

local ritchlarva = nil
newEffect{
	name = "RITCH_LARVA_EGGS", image = "talents/ritch_larva_infect.png",
	desc = "Larvae Infestation",
	long_desc = function(self, eff)
		local source = eff.src or self
		return ("The target has been impregnated with %d developing ritch larvae which are feeding on it%s.  After a %d turn gestation period, each will burst out violently, dealing %0.2f physical and %0.2f fire damage to its host."):format(eff.nb,
		eff.turns < eff.gestation and (" for %0.2f physical damage (increasing) each turn"):format(
		source:damDesc("PHYSICAL", TemporaryEffects.tempeffect_def.EFF_RITCH_LARVA_EGGS.gestation_damage(self, eff, eff.turns + 1))) or "",
		eff.gestation, source:damDesc("PHYSICAL", eff.dam/2), source:damDesc("FIRE", eff.dam/2))
	end,
	type = "physical",
	subtype = { disease=true },
	status = "detrimental",
	activate = function(self, eff)
	end,
	parameters = {dam=10, nb=2, gestation=5, turns=0 },
	on_gain = function(self, err) return "#Target# is #ORANGE#INFESTED#LAST# with ritch larvae!", "+Larvae Infestation" end,
	gestation_damage = function(self, eff, turn)
		return eff.nb*eff.dam*(turn * 0.05)
	end,
	on_timeout = function(self, eff)
		eff.turns = eff.turns + 1
		-- Creepy, so the player tries to get rid of it as soon as possible...
		local source = eff.src or self
		source:project({}, self.x, self.y, DamageType.PHYSICAL, TemporaryEffects.tempeffect_def.EFF_RITCH_LARVA_EGGS.gestation_damage(self, eff, eff.turns))
	end,
	deactivate = function(self, eff)
		local chance, strength = 100, 0
		if eff.dur >= 0 then -- prematurely removed: hatch chance < 100% and larva may be weaker
			chance = math.ceil(self:combatLimit(util.bound(1-eff.turns/eff.gestation, 0, 1), 0, 100, 0, 35, 0.6))
			strength = util.bound(self:combatLimit(util.bound(1-eff.turns/eff.gestation, 0, 1), -1, 0, 0, -.5, 0.6), -1, 0)
		end
		if not ritchlarva then
			local list = mod.class.NPC:loadList("/data-orcs/general/npcs/ritch-extended.lua")
			ritchlarva = list.RITCH_LARVA
		end
		local larva_name = (strength < 0 and "developing " or "")..ritchlarva.name
		local source = eff.src or self
		for i = 1, eff.nb do
			if rng.percent(chance) then
				local larva
				source.__project_source = eff
				DamageType:get(DamageType.MOLTENROCK).projector(source, self.x, self.y, DamageType.MOLTENROCK, eff.dam*(1 + strength))
				source.__project_source = nil
				game.level.map:particleEmitter(self.x, self.y, 1, "slime")
				game:playSoundNear(self, "talents/slime")
				local x, y = util.findFreeGrid(self.x, self.y, 2, true, {[Map.ACTOR]=true})
				if x then
					larva = ritchlarva:clone()
					larva.inc_damage.all = (larva.inc_damage.all or 0) + strength*100
					larva.life_rating = larva.life_rating * (1 + strength)
					larva.name = larva_name
					larva.exp_worth = 1 + strength -- The Ritch mothers are annoying enough that this shouldn't be farming issue.
					if game.party:hasMember(eff.src) then
						larva.exp_worth = 0 --For if player has this
					end
					larva.faction = eff.src.faction or "enemies"
					larva:resolve()
					larva:resolve(nil, true)
					game.zone:addEntity(game.level, larva, "actor", x, y)
				end
				game.logSeen(self, "A %s #ORANGE#BURSTS OUT#LAST# of %s%s!", larva_name, self.name:capitalize(), x and "" or " but is crushed")
			end
		end
	end,
}

newEffect{
	name = "TECH_OVERLOAD", image = "talents/tech_overload.png",
	desc = "Tech Overload",
	long_desc = function(self, eff) return ("Doubles your maximum steam and stops steam regeneration."):format() end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	activate = function(self, eff)
		self:incSteam(self:getMaxSteam() * eff.regen)
		self:effectTemporaryValue(eff, "max_steam", self:getMaxSteam())
		self:effectTemporaryValue(eff, "steam_regen", -self.steam_regen / 2)
	end,
}

newEffect{
	name = "CONTINUOUS_BUTCHERY", image = "talents/continuous_butchery.png",
	desc = "Continuous Butchery",
	long_desc = function(self, eff) return ("Increases steamsaw damage multiplier by %d%%."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	parameters = {power=20, power_inc=20},
	charges = function(self, eff) return eff.power end,
	callbackOnMeleeAttack = function(self, eff, target, hitted, crit, weapon, damtype, mult, dam)
		if self.turn_procs.continuous_butchery then return end
		if not target or not hitted then return end
		if eff.target ~= target then self:removeEffect(self.EFF_CONTINUOUS_BUTCHERY) return end

		self.turn_procs.continuous_butchery = true

		eff.power = eff.power + eff.power_inc

		self:removeTemporaryValue("steamsaw_dam_mult", eff.tmpid)
		eff.tmpid = self:addTemporaryValue("steamsaw_dam_mult", eff.power)
	end,
	activate = function(self, eff)
		eff.tmpid = self:addTemporaryValue("steamsaw_dam_mult", eff.power)
	end,
	deactivate = function(self, eff)
		self:removeTemporaryValue("steamsaw_dam_mult", eff.tmpid)
	end,
}

newEffect{
	name = "EXPLOSIVE_WOUND", --image = "talents/.png",
	image = "talents/explosive_saw.png",
	desc = "Explosive Saw",
	long_desc = function(self, eff) return ("Target is being assailed by an automated saw blade that cuts its flesh for %0.2f physical damage each turn%s. When the effect expires, the saw will explode for %0.2f fire damage and fly back to its source, pulling the target with it (up to %d tiles)."):format(eff.power, eff.silence and " and silences it" or "", eff.src:damDesc(DamageType.FIRE, eff.power_final), eff.range) end,
	type = "physical",
	subtype = { wound=true, cut=true, bleed=true },
	status = "detrimental",
	parameters = {power=10, range =4},
	charges = function(self, eff) return eff.silence and "sil" or "" end,
	on_gain = function(self, eff) return "#Target# is assailed by an automated saw blade.", "+Explosive Wounds" end,
	on_lose = function(self, eff) return "The saw embedded in #Target# flies back its source.", "-Explosive Wounds" end,
	activate = function(self, eff)
		if eff.silence then
			self:effectTemporaryValue(eff, "silence", 1)
		end
	end,
	on_timeout = function(self, eff)
		DamageType:get(DamageType.PHYSICAL).projector(eff.src or self, self.x, self.y, DamageType.PHYSICAL, eff.power)
	end,
	deactivate = function(self, eff) -- if it ticked all the way down, apply special removal effects
		if eff.dur >= 0 or not eff.src or eff.src.dead or not eff.src.x or not eff.src.y then return end
		DamageType:get(DamageType.FIRE).projector(eff.src or self, self.x, self.y, DamageType.FIRE, eff.power_final)
		if self:canBe("knockback") then
			self:logCombat(eff.src, "The saw drags #Source# towards #Target#!")
			self:pull(eff.src.x, eff.src.y, eff.range)
		end
	end,
}

newEffect{
	name = "SUBCUTANEOUS_METALLISATION", image = "talents/subcutaneous_metallisation.png",
	desc = "Subcutaneous Metallisation",
	long_desc = function(self, eff) return ("All damage reduced by %d."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true, resistance=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# internal structure metallises.", "+Subcutaneous Metallisation" end,
	on_lose = function(self, err) return "#Target# internal structure returns to normal.", "-Subcutaneous Metallisation" end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "flat_damage_armor", {all=eff.power})
	end,
}

newEffect{
	name = "PAIN_ENHANCEMENT_SYSTEM", image = "talents/pain_enhancement_system.png",
	desc = "Pain Enhancement System",
	long_desc = function(self, eff) return ("All stats increased by %d."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true, power=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# revels in the pain.", "+Pain Enhancement System" end,
	on_lose = function(self, err) return "#Target# no longer feels strong.", "-Pain Enhancement System" end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "inc_stats", {
			[Stats.STAT_DEX] = math.floor(eff.power),
			[Stats.STAT_MAG] = math.floor(eff.power),
			[Stats.STAT_WIL] = math.floor(eff.power),
			[Stats.STAT_CUN] = math.floor(eff.power),
			[Stats.STAT_CON] = math.floor(eff.power),
		})
	end,
}

newEffect{
	name = "NET_PROJECTOR", image = "talents/net_projector.png",
	desc = "Net Projector",
	long_desc = function(self, eff) return ("The target has been pinned by an electrified net, reducing all resistances by %d%%."):format(eff.power) end,
	type = "physical",
	subtype = { steamtech=true, pin=true },
	status = "detrimental",
	on_gain = function(self, err) return "#Target# is trapped by the net.", "+Net Projector" end,
	on_lose = function(self, err) return "#Target# is free from the net.", "-Net Projector" end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "never_move", 1)
		self:effectTemporaryValue(eff, "resists", {all=-eff.power})
	end,
}

newEffect{
	name = "FURNACE_MOLTEN_POINT", image = "talents/molten_metal.png",
	desc = "Molten Point",
	long_desc = function(self, eff) return ("You have %d charges."):format(eff.stacks) end,
	type = "other",
	decrease = 0,
	subtype = { fire=true },
	status = "beneficial",
	parameters = { stacks=1, max_stacks=10 },
	charges = function(self, eff) return eff.stacks end,
	on_merge = function(self, old_eff, new_eff)
		old_eff.dur = new_eff.dur
		old_eff.stacks = util.bound(old_eff.stacks + 1, 1, new_eff.max_stacks)
		return old_eff
	end,
	activate = function(self, eff)
	end,
	deactivate = function(self, eff)
	end,
}

newEffect{
	name = "PRESSURE_SUIT", image = "talents/elemental_surge.png",
	desc = "Pressure-enhanced Slashproof Combat Suit",
	long_desc = function(self, eff) return ("When hit the suit's motors displace you quickly, ignoring the blow.") end,
	type = "physical",
	subtype = { steam=true },
	status = "beneficial",
	parameters = { },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "phase_shift", 1)
	end,
}

newEffect{
	name = "MOLTEN_IRON_BLOOD", image = "talents/molten_iron_blood.png",
	desc = "Molten Iron Blood",
	long_desc = function(self, eff) return ("All resistances increased by %d%%, all new detrimental effects reduced by %d%%, %0.2f fire splash damage."):format(eff.resists, eff.reduction, eff.dam) end,
	type = "physical",
	subtype = { steamtech=true, psionic=true, fire=true, resistance=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target#'s blood turn into molten iron.", true end,
	on_lose = function(self, err) return "#Target# no longer has molten iron blood.", true end,
	parameters = {dam=10, resists=10, reduction=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "on_melee_hit", {[DamageType.FIRE] = eff.dam})
		self:effectTemporaryValue(eff, "resists", {all=eff.resists})
		self:effectTemporaryValue(eff, "reduce_detrimental_status_effects_time", eff.reduction)
	end,
}

newEffect{
	name = "SEARED",
	desc = "Seared",
	long_desc = function(self, eff) return ("Fire resistance decreased by %d%% and mind save by %d."):format(eff.power, eff.power) end,
	type = "physical",
	subtype = { psionic=true, fire=true },
	status = "detrimental",
	on_gain = function(self, err) return "#Target# is seared.", true end,
	on_lose = function(self, err) return "#Target# is no longer seared.", true end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "resists", {[DamageType.FIRE] = -eff.power})
		self:effectTemporaryValue(eff, "combat_mentalresist", -eff.power)
	end,
}

newEffect{
	name = "AWESOME_TOSS", image = "talents/awesome_toss.png",
	desc = "Awesome Toss",
	long_desc = function(self, eff) return ("All resistances increased by %d%%, randomly attacks two foes each turn at random."):format(eff.resist, eff.dam) end,
	type = "physical",
	cancel_on_level_change = true,
	subtype = { steamtech=true, awesome=true, resistance=true },
	status = "beneficial",
	on_gain = function(self, err) return "#Target# tosses steamguns in the air, awesome!", true end,
	on_lose = function(self, err) return "#Target# somehow catches the falling steamguns.", true end,
	parameters = {dam=10, resist=10},
	callbackOnAct = function(self, eff)
		self.disarmed = self.disarmed - 1
		local weapon, ammo, offweapon = self:hasDualArcheryWeapon("steamgun")
		self.disarmed = self.disarmed + 1
		local realweapon = weapon
		weapon = weapon and weapon.combat
		local realoffweapon = offweapon
		offweapon = offweapon and offweapon.combat
		if not weapon or not offweapon then return end

		self.disarmed = self.disarmed - 1

		local targets = {main={}, off={}, dual=true}
		local function run(weapon, where)
			local range = weapon.range or 6
			local tgts = {}
			self:project({type="ball", radius=range, start_x=eff.x, start_y=eff.y}, eff.x, eff.y, function(px, py)
				local target = game.level.map(px, py, Map.ACTOR)
				if not target or self:reactionToward(target) >= 0 then return end
				tgts[#tgts+1] = target
			end)
			if #tgts == 0 then return end

			local target = rng.table(tgts)
			where[#where+1] = {x=target.x, y=target.y, ammo=ammo.combat}
		end
		run(weapon, targets.main)
		run(offweapon, targets.off)

		if #targets.main > 0 or #targets.off > 0 then
			local sound = weapon.sound
			if sound then game:playSoundNear(self, sound) end
			self:archeryShoot(targets, self:getTalentFromId(self.T_AWESOME_TOSS), {start_x=eff.x, start_y=eff.y}, {mult=eff.dam})
		end

		self.disarmed = self.disarmed + 1
	end,
	activate = function(self, eff)
		eff.x, eff.y = self.x, self.y
		self:effectTemporaryValue(eff, "resists", {all=eff.resist})
		self:effectTemporaryValue(eff, "disarmed", 1)
	
		eff.p1 = game.level.map:particleEmitter(eff.x, eff.y, 2, "vapour_spin", {radius=1, smoke="particles_images/smoke_whispery_bright"})
		eff.p2 = game.level.map:particleEmitter(eff.x, eff.y, 2, "vapour_spin", {radius=1, smoke="particles_images/smoke_heavy_bright"})
		eff.p3 = game.level.map:particleEmitter(eff.x, eff.y, 2, "vapour_spin", {radius=1, smoke="particles_images/smoke_dark"})
		eff.p4 = game.level.map:particleEmitter(eff.x, eff.y, 2, "steamgun_spin", {})
	end,
	deactivate = function(self, eff)
		if eff.p1 then game.level.map:removeParticleEmitter(eff.p1) end
		if eff.p2 then game.level.map:removeParticleEmitter(eff.p2) end
		if eff.p3 then game.level.map:removeParticleEmitter(eff.p3) end
		if eff.p4 then game.level.map:removeParticleEmitter(eff.p4) end
	end,
}

newEffect{
	name = "MARKED_LONGARM", image = "talents/snap.png",
	desc = "Marked for Death",
	long_desc = function(self, eff) return ("Ranged defense reduced by %d, takes %d%% extra damage from all sources."):format(eff.def, eff.dam) end,
	type = "physical",
	subtype = { steam=true },
	status = "detrimental",
	parameters = { def=10, dam = 10 },
	on_gain = function(self, err) return "#Target# is marked!", "+Marked for Death" end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "combat_def_ranged", -eff.def)
		self:effectTemporaryValue(eff, "resists", {all = -eff.dam})
	end,
}

newEffect{
	name = "ITCHING_POWDER", image = "talents/slippery_moss.png",
	desc = "Itching Powder",
	long_desc = function(self, eff) return ("The target is very itchy, causing their actions to fail."):format() end,
	type = "physical",
	subtype = { powder=true },
	status = "detrimental",
	parameters = {},
	on_gain = function(self, err) return "#Target# is very itching!", "+Itching Powder" end,
	on_lose = function(self, err) return "#Target# regains their concentration.", "-Itching Powder" end,
	activate = function(self, eff)
		eff.tmpid = self:addTemporaryValue("talent_fail_chance", eff.chance)
	end,
	deactivate = function(self, eff)
		self:removeTemporaryValue("talent_fail_chance", eff.tmpid)
	end,
}

newEffect{
	name = "SMOKE_COVER", image = "talents/blinding_ink.png",
	desc = "Smoke Cover",
	long_desc = function(self, eff) return ("%d%% chance to fully absorb any damaging actions, %d stealth value."):format(eff.power, eff.stealth) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	parameters = { power=10, stealth=10 },
	on_gain = function(self, err) return "#Target# is hiding in smoke.", "+Smoke Cover" end,
	on_lose = function(self, err) return "#Target# is no longer hiding in smoke.", "-Smoke Cover" end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "cancel_damage_chance", eff.power)
		self:effectTemporaryValue(eff, "stealth", eff.stealth)
	end,
}

newEffect{
	name = "MAGNETISED", image = "talents/tinker_magnetic_shell.png",
	desc = "Magnetised",
	long_desc = function(self, eff) return ("The target has been magnetised, reducing defense by %d and increasing fatigue by %d."):format(eff.power, eff.power) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "detrimental",
	on_gain = function(self, err) return "#Target# is magnetised.", "+Magnetised" end,
	on_lose = function(self, err) return "#Target# is free from the magnetism.", "-Magnetised" end,
	parameters = {power=10},
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "combat_def", -eff.power)
		self:effectTemporaryValue(eff, "fatigue", eff.power)
		-- Worth adding projectile evasion/normal evasion reduction to this?
	end,
}

newEffect{
	name = "BLOODSTAR", image = "talents/bloodstar.png",
	desc = "Bloodstar",
	long_desc = function(self, eff) return ("Continuously drain blood, dealing %0.2f physical damage per turn and healing the caster for half of it."):format(eff.dam) end,
	type = "physical",
	subtype = { blood=true, drain=true, heal=true },
	status = "detrimental",
	parameters = { dam=10 },
	on_gain = function(self, err) return "#Target# is caught in the bloodstar.", true end,
	on_lose = function(self, err) return "#Target# is free from the bloodstar.", true end,
	activate = function(self, eff)
		eff.particle = self:addParticles(Particles.new("bloodstar_tendrils", 1, {tx=eff.src.x-self.x, ty=eff.src.y-self.y}))
	end,
	deactivate = function(self, eff)
		self:removeParticles(eff.particle)
	end,
	on_timeout = function(self, eff)
		local severed = false
		local src = eff.src or self
		if core.fov.distance(self.x, self.y, src.x, src.y) >= eff.free or src.dead or not game.level:hasEntity(src) then severed = true end

		self:removeParticles(eff.particle)
		eff.particle = self:addParticles(Particles.new("bloodstar_tendrils", 1, {tx=eff.src.x-self.x, ty=eff.src.y-self.y}))

		if severed then
			return true
		else
			self:attr("damage_dont_undaze", 1)
			if eff.steamstar then
				if DamageType:get(DamageType.FIRE).projector(src, self.x, self.y, DamageType.FIRE, eff.steamstar.dam) > 0 then
					local nb_done = eff.src.turn_procs.steamstar_steam or 0
					eff.src:incSteam(eff.steamstar.steam * 0.3 ^ nb_done)
					eff.src.turn_procs.steamstar_steam = nb_done + 1
				end
			end
			local realdam = DamageType:get(DamageType.PHYSICAL).projector(src, self.x, self.y, DamageType.PHYSICAL, eff.dam)
			self:attr("damage_dont_undaze", -1)
			if realdam > 0 then
				local nb_done = eff.src.turn_procs.bloodstar_heals or 1
				eff.src:heal(realdam * 0.5 ^ nb_done, self)
				eff.src.turn_procs.bloodstar_heals = nb_done + 1
			end
		end
	end,
}

newEffect{
	name = "HEART_CUT", image = "effects/cut.png",
	desc = "Heartrended",
	long_desc = function(self, eff) return ("Vicious cut that bleeds, doing %0.2f physical damage per turn."):format(eff.power) end,
	type = "physical",
	subtype = { wound=true, cut=true, bleed=true },
	status = "detrimental",
	parameters = { power=1 },
	on_gain = function(self, err) return "#Target# starts to bleed.", "+Bleeds" end,
	on_lose = function(self, err) return "#Target# stops bleeding.", "-Bleeds" end,
	on_merge = function(self, old_eff, new_eff)
		-- Merge the flames!
		local olddam = old_eff.power * old_eff.dur
		local newdam = new_eff.power * new_eff.dur
		local dur = math.ceil((old_eff.dur + new_eff.dur) / 2)
		old_eff.dur = dur
		old_eff.power = (olddam + newdam) / dur
		return old_eff
	end,
	on_timeout = function(self, eff)
		self.ignore_heartrend = true
		local storedam = eff.src.inc_damage
		eff.src.inc_damage = {}
		DamageType:get(DamageType.PHYSICAL).projector(eff.src or self, self.x, self.y, DamageType.PHYSICAL, eff.power)
		eff.src_inc_damage=storedam
		self.ignore_heartrend = false
	end,
}

newEffect{
	name = "METAL_POISONING", image = "talents/tinker_toxic_shell.png",
	desc = "Metal Poisoning",
	long_desc = function(self, eff) return ("The target is poisoned with heavy metals, taking %0.2f blight damage per turn and decreasing their global speed by %d%%."):format(eff.power, eff.speed) end,
	type = "physical",
	subtype = { poison=true, blight=true }, no_ct_effect = true,
	status = "detrimental",
	parameters = {power=10, speed=30},
	on_gain = function(self, err) return "#Target# is poisoned!", "+Metal Poisoning" end,
	on_lose = function(self, err) return "#Target# is no longer poisoned.", "-Metal Poisoning" end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "global_speed_add", -eff.speed/100)
	end,
	-- There are situations this matters, such as copyEffect
	on_merge = function(self, old_eff, new_eff)
		old_eff.dur = math.max(old_eff.dur, new_eff.dur)
		return old_eff
	end,
	on_timeout = function(self, eff)
		if self:attr("purify_poison") then self:heal(eff.power, eff.src)
		else DamageType:get(DamageType.BLIGHT).projector(eff.src, self.x, self.y, DamageType.BLIGHT, eff.power)
		end
	end,
	deactivate = function(self, eff)
	end,
}

newEffect{
	name = "MOSS_TREAD", image = "talents/mucus.png",
	desc = "Moss Tread",
	long_desc = function(self, eff) return ("You lay moss where you walk."):format() end,
	type = "physical",
	subtype = { moss=true },
	status = "beneficial",
	parameters = {},
	on_gain = function(self, err) return nil, "+Moss" end,
	on_lose = function(self, err) return nil, "-Moss" end,
	callbackOnMove = function(self, eff, moved, force, ox, oy)
		if not moved or force or (ox == self.x and oy == self.y) then return end
		self:callTalent(self.T_TINKER_MOSS_TREAD, nil, self.x, self.y, eff.dam)
	end,
}

newEffect{
	name = "STIMPAK", image = "effects/cut.png",
	desc = "Stimulus",
	long_desc = function(self, eff) return ("Resisting pain, reducing all incoming damage by %0.2f. When the effect ends, take %d un-resistable damage."):format(eff.power, (eff.power/3)*0.05 * self.max_life) end,
	type = "physical",
	subtype = { steamtech=true },
	status = "beneficial",
	parameters = { power=3, capped = 0 },
	on_gain = function(self, err) return "#Target# starts to bleed.", "+Bleeds" end,
	on_lose = function(self, err) return "#Target# stops bleeding.", "-Bleeds" end,
	on_merge = function(self, old_eff, new_eff)
		old_eff.power = math.min(old_eff.power + 3, 15)
		old_eff.dur = 6
		if old_eff.power == 15 then
		old_eff.capped = 1
		end
		return old_eff
	end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "flat_damage_armor", {all = eff.power})
		self:effectTemporaryValue(eff, "stimpak_capped", eff.capped)
	end,
	deactivate = function(self, eff)
		local dam = ((eff.power/3 * 0.05) * self.max_life)
		self.life = (self.life - dam)
	end,
}

newEffect{
	name = "TO_THE_ARMS", image = "talents/to_the_arms.png",
	desc = "To The Arms",
	long_desc = function(self, eff) return ("Damage reduced by %d%%."):format(eff.power) end,
	type = "physical",
	subtype = { maimed=true },
	status = "detrimental",
	parameters = { power=10 },
	on_gain = function(self, err) return "#Target# is suffering and fails to concentrate on dealing damage.", true end,
	on_lose = function(self, err) return "#Target# is suffering less.", true end,
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "generic_damage_penalty", eff.power)
	end,
	deactivate = function(self, eff)
	end,
}
