-- ToME - Tales of Maj'Eyal:
-- Copyright (C) 2009 - 2016 Nicolas Casalini
--
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
--
-- Nicolas Casalini "DarkGod"
-- darkgod@te4.org

local Stats = require "engine.interface.ActorStats"
local Particles = require "engine.Particles"
local Shader = require "engine.Shader"
local Entity = require "engine.Entity"
local Chat = require "engine.Chat"
local Map = require "engine.Map"
local Level = require "engine.Level"

newEffect{
	name = "CELESTIAL_ACCELERATION", image = "talents/celestial_acceleration.png",
	desc = "Celestial Acceleration",
	long_desc = function(self, eff)
		local strings = {}
		if eff.move then
			strings[#strings + 1] = ("Your movement speed is increased by %d%%."):format(eff.move * 100)
		end 
		if eff.cast then
			strings[#strings + 1] = ("Your casting speed is increased by %d%%."):format(eff.cast * 100)
		end 
		if eff.attack then
			strings[#strings + 1] = ("Your attack speed is increased by %d%%."):format(eff.attack * 100)
		end 
		if eff.mind then
			strings[#strings + 1] = ("Your mind speed is increased by %d%%."):format(eff.mind * 100)
		end 
		if eff.power then
			strings[#strings + 1] = ("Your global speed is increased by %d%%."):format(eff.power * 100)
		end
		
		return table.concat(strings, " ")
	end,
	type = "other",
	subtype = { speed=true },
	status = "beneficial", 
	decrease = 0, no_remove = true,
	parameters = { },
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "movement_speed", eff.move)
		self:effectTemporaryValue(eff, "combat_spellspeed", eff.cast)
	end,
}

newEffect{
	name = "OUTSIDE_THE_STARSCAPE", image = "talents/starscape.png",
	desc = "Outside the Starscape",
	long_desc = function(self, eff) return ("This unit is outside of the starscape and cannot be harmed from within it,") end,
	type = "other",
	subtype = {spacetime=true},
	status = "neutral",
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "invulnerable", 1)
		self:effectTemporaryValue(eff, "time_prison", 1)
		self:effectTemporaryValue(eff, "no_timeflow", 1)
		self:effectTemporaryValue(eff, "status_effect_immune", 1)
	end
}

newEffect{
	name = "MINDWALL_CONFUSED", image = "effects/confused.png",
	desc = "Mindblasted",
	long_desc = function(self, eff) return ("The target is confused, acting randomly (chance %d%%) and unable to perform complex actions."):format(eff.power) end,
	type = "other",
	subtype = { confusion=true },
	status = "detrimental", no_ct_effect = true,
	parameters = { power=100 },
	on_gain = function(self, err) return "#Target# wanders around!.", "+Confused" end,
	on_lose = function(self, err) return "#Target# seems more focused.", "-Confused" end,
	activate = function(self, eff)
		eff.tmpid = self:addTemporaryValue("confused", eff.power)
		if eff.power <= 0 then eff.dur = 0 end
		if self == game.player and self.updateMainShader then self:updateMainShader() end
	end,
	deactivate = function(self, eff)
		self:removeTemporaryValue("confused", eff.tmpid)
		if self == game.player and self.updateMainShader then self:updateMainShader() end
	end,
}

newEffect{
	name = "AERYN_SUN_SHIELD", image = "talents/barrier.png",
	desc = "Shield of the Sun",
	long_desc = function(self, eff) return ("The power of the Sun itself shields the target.") end,
	type = "other", decrease = 0, no_remove = true,
	subtype = {sun=true},
	status = "beneficial",
	activate = function(self, eff)
		eff.particle = self:addParticles(Particles.new("shader_shield", 1, {size_factor=1.6, img="runicshield"}, {type="runicshield", shieldIntensity=0.14, ellipsoidalFactor=1.2, time_factor=5000, bubbleColor=colors.hex1alpha"ebf400ff", auraColor=colors.hex1alpha"eca700ff"}))
		self:effectTemporaryValue(eff, "movement_speed", 1)
		self:effectTemporaryValue(eff, "invulnerable", 1)
		self:effectTemporaryValue(eff, "status_effect_immune", 1)
		self:removeEffectsFilter{status="detrimental"}
		self.ai = "orcs+move_aeryn_sun_flee"
		self:doEmote("TO THE MOUNTAINS!", 120)
	end,
	deactivate = function(self, eff)
		self.ai = "tactical"
		self:removeParticles(eff.particle)
		self:setEffect(self.EFF_AERYN_SUN_REZ, 1, {})
	end,
}

newEffect{
	name = "AERYN_SUN_REZ", image = "talents/barrier.png",
	desc = "A Light in the Darkness",
	long_desc = function(self, eff) return ("The power of the Sun imbues the target.") end,
	type = "other", decrease = 0, no_remove = true,
	subtype = {sun=true},
	status = "beneficial",
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "inc_damage", {all=35})
		self:effectTemporaryValue(eff, "max_life", self.max_life * 0.35)
		self:heal(self.max_life, self)
	end,
	deactivate = function(self, eff)
	end,
}

newEffect{
	name = "X_RAY", image = "talents/total_thuggery.png",
	desc = "X-Ray Vision",
	long_desc = function(self, eff) return ("Can see EVERYTHING.") end,
	type = "other",
	subtype = {other=true},
	status = "beneficial",
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "detect_range", 10)
		self:effectTemporaryValue(eff, "detect_actor", 1)
		self:effectTemporaryValue(eff, "detect_object", 10)
		self:effectTemporaryValue(eff, "detect_trap", 10)
	end,
	deactivate = function(self, eff)
	end,
	callbackOnMove = function(self, eff, moved, force, ox, oy)
		self:magicMap(10)
	end,
}

newEffect{
	name = "NEKTOSH_WAND", image = "talents/barrier.png",
	desc = "Aiming!",
	long_desc = function(self, eff) return ("Aiming a powerful beam. MOVE OUT!") end,
	type = "other",
	subtype = {other=true},
	status = "beneficial",
	activate = function(self, eff)
		self:effectTemporaryValue(eff, "never_act", 1)
		self:effectParticles(eff, {type="sun_path", args={tx=eff.x-self.x, ty=eff.y-self.y}})
		game.bignews:saySimple(120, "#PURPLE#NEKTOSH AIMS A POWERFUL BEAM! #{bold}#MOVE!!#{normal}#")
	end,
	deactivate = function(self, eff)
		local tg = {type="beam", range=10, selffire=false}
		if eff.dig then
			for i = 1, tg.range do self:project(tg, eff.x, eff.y, DamageType.DIG, 1) end
		end
		self.big_boom = true
		self.tmp[self.EFF_NEKTOSH_WAND] = eff -- This is a nasty hack, made under the control of a professional. Do not try this at home!
		self:project(tg, eff.x, eff.y, DamageType.ARCANE, eff.power)
		self.tmp[self.EFF_NEKTOSH_WAND] = nil
		self.big_boom = false
		game.level.map:particleEmitter(self.x, self.y, math.max(math.abs(eff.x-self.x), math.abs(eff.y-self.y)), "mana_beam", {tx=eff.x-self.x, ty=eff.y-self.y})

		game.logSeen(self, "%s blinks away and summons some help!", self.name:capitalize())

		self:forceUseTalent(self.T_SUMMON, {ignore_energy=true, ignore_ressources=true})

		game.level.map:particleEmitter(self.x, self.y, 1, "teleport")
		self:teleportRandom(self.x, self.y, 4)
		game.level.map:particleEmitter(self.x, self.y, 1, "teleport")
	end,
	callbackOnKill = function(self, eff, who)
		if not self.big_boom then return end
		if not who then return end
		if who.faction == self.faction then
			world:gainAchievement("ORCS_NEKTOSH_SELF", game.player)
		end
		if who == game:getPlayer(true) and not (
			who:attr("stunned") or
			who:attr("never_move") or
			who:attr("confused") or
			who:attr("dazed") or
			who:attr("sleep")
		) then
			world:gainAchievement("ORCS_DIE_NEKTOSH", game.player)
		end
	end,
}
